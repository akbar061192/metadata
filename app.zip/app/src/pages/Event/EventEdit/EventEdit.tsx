import React, { useState, useCallback, useRef, useMemo } from 'react';
import { createStyles, makeStyles, Theme } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import Grid from '@material-ui/core/Grid';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import IconButton from '@material-ui/core/IconButton';
import Typography from '@material-ui/core/Typography';
import CloseIcon from '@material-ui/icons/Close';
import Slide from '@material-ui/core/Slide';
import { TransitionProps } from '@material-ui/core/transitions';
import { TextField } from '@material-ui/core';
import HelpOutlineSharpIcon from '@material-ui/icons/HelpOutlineSharp';
import { IUpsertEvents, IUpsertEventsDetails } from '../../../global/services/apistypes';
import { globalApis } from '../../../global/services/apis';
import {
  DataGrid,
  GridColDef,
  GridRowData,
  GridValueFormatterParams,
  GridSelectionModel,
} from '@material-ui/data-grid';
import AddIcon from '@material-ui/icons/Add';

interface EventEditProps {
  openEditDialog: boolean;
  closeEditDialog: () => void;
  eventDetails: any;
  mdelId: number;
  newEvent: boolean;
  setRefreshList: any;
  refreshList: boolean;
  isoCountryCd: string;
}

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    appBar: {
      position: 'relative',
    },
    title: {
      marginLeft: theme.spacing(2),
      flex: 1,
    },
    textFieldFlex: {
      display: 'flex',
      alignItems: 'center',
      marginBottom: '2.5rem',
    },
    gridContainer: {
      margin: '0 1.5rem',
    },
    fieldSize: {
      width: '20.5rem',
    },
    toggle: {
      display: 'flex',
      alignItems: 'center',
      width: '20.5rem',
      justifyContent: 'space-between',
    },
    icon: {
      marginLeft: '1rem',
      color: 'gray',
    },
    rightInfoContainer: {
      backgroundColor: ' rgba(0, 0, 0, 0.05)',
      height: '100%',
    },
    sideContent: {
      display: 'flex',
      flexDirection: 'column',
    },
    textField: {
      marginBottom: '1.5rem',
    },
    parameterContainer: {
      width: '70%',
      margin: '20px 0 40px',
    },
    paramTitle: {
      fontSize: '1rem',
      fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
      fontWeight: 400,
      lineHeight: 1.5,
      letterSpacing: '0.00938em',
      margin: '20px 0',
    },
    gridColHeader: {
      borderTop: 'none',
      border: 'none',
      '& .MuiDataGrid-columnHeaderTitle': {
        fontWeight: 550,
      },
      '& svg.MuiSvgIcon-root.MuiDataGrid-sortIcon.MuiSvgIcon-fontSizeSmall': {
        opacity: 1,
      },
      '& .MuiDataGrid-columnHeaderTitleContainer': {
        justifyContent: 'center',
      },
      '& .MuiDataGrid-columnSeparator': {
        display: 'none',
      },
      '& .MuiDataGrid-cell--editing input': {
        textAlign: 'center',
      },
      width: '100%',
      marginTop: '2rem',
    },
    btnFlex: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
    },
  })
);

const Transition = React.forwardRef(function Transition(
  props: TransitionProps & { children?: React.ReactElement },
  ref: React.Ref<unknown>
) {
  return <Slide direction='up' ref={ref} {...props} />;
});

// CONVERTING INCOMING DATE TO UTC WITH PROPER FORMATTING
const dateFormat = (date: string) => {
  const inputDate = new Date(date).toUTCString().slice(5, 22);
  let char = ',';
  let position = 11;
  let output = [inputDate.slice(0, position), char, inputDate.slice(position)].join('');
  return output;
};

// COLUMNS DEFINITION FOR DATA GRID
const columns: GridColDef[] = [
  {
    field: 'name',
    headerName: 'Parameter',
    type: 'string',
    flex: 1,
    editable: true,
    disableColumnMenu: true,
    align: 'center',
    headerAlign: 'right',
  },
  {
    field: 'values',
    headerName: 'Parameter Value',
    type: 'string',
    flex: 1,
    editable: true,
    disableColumnMenu: true,
    align: 'center',
    headerAlign: 'right',
  },
];

// FUNCTION TO GET ALL THE UPDATED ROWS FROM DATA GRID
const useApiRef = () => {
  const apiRef: any = useRef();
  const _columns = useMemo(
    () =>
      columns.concat({
        field: '',
        headerName: '',
        editable: true,
        width: 0,
        disableColumnMenu: true,
        hideSortIcons: true,
        renderCell: (params: GridValueFormatterParams) => {
          apiRef.current = params.api;
          return null;
        },
      }),
    []
  );

  return { apiRef, columns: _columns };
};

// START OF THE COMPONENT
const EventEdit: React.FC<EventEditProps> = props => {
  // DE-STRUCTURING useApiRef() FUNCTION
  const { apiRef, columns } = useApiRef();

  // DESTRUCTING INCOMING PROPS
  const {
    openEditDialog,
    closeEditDialog,
    eventDetails,
    mdelId: model,
    newEvent,
    refreshList,
    setRefreshList,
    isoCountryCd,
  } = props;

  const classes = useStyles();

  // LOCAL STATE TO STORE THE ROWS WHICH USER DELETES IN THE DATA GRID
  const [selectionModel, setSelectionModel] = useState<GridSelectionModel>([]);

  // DESTRUCTING EVENT DETAILS FOR A SINGLE EVENT
  const {
    eventId,
    eventCd,
    eventDesc,
    modelId,
    isrtdDt,
    isrtdByUsrNm,
    lstUpdtDt,
    lstUpdtByUsrNm,
    filterJson,
    topicName,
    groupName,
    maxMessage,
  } = eventDetails;

  // PARSING STRING TO JSON FOR filterJson VALUE
  const jSonFilter = filterJson && JSON.parse(filterJson);

  // EXISTING PARAMETER ROW VALUES FROM API DATA
  const existingParameterValues =
    jSonFilter &&
    jSonFilter?.parameters?.map((item: any) => {
      const parameterValues = {
        name: item.name,
        values: [item.values[0]],
        id: +(Math.random() * 1000).toFixed(5),
      };
      return parameterValues;
    });

  // STATE FOR HANDLING USER CHANGES TO FORM AND DISPLAYING IT
  const [eventEdit, setEventEdit] = useState({
    eDesc: eventDesc,
    eCode: eventCd,
    eCycleType: jSonFilter && jSonFilter.cycleType,
    eSubjectArea: jSonFilter && jSonFilter.subjectArea,
    eTopicName: topicName,
    eGroupName: groupName,
    eMaxMessage: maxMessage,
    eMdelName: jSonFilter && jSonFilter.mdelName,
    eExtractTimestamp: jSonFilter && jSonFilter.extractTimestamp,
    eCycleId: jSonFilter && jSonFilter.cycleId,
    eParameters: existingParameterValues || [],
    modelId,
  });

  // FUNCTION TO CHECK/UN-CHECK THE CHECKBOX
  const handleEditCheckBox = useCallback((newSelectionModel: any) => {
    setSelectionModel(newSelectionModel);
  }, []);

  // VALIDATING REQUIRED FIELDS
  const isRequired =
    eventEdit.eCode &&
    eventEdit.eDesc &&
    eventEdit.eCycleType &&
    eventEdit.eSubjectArea &&
    eventEdit.eTopicName &&
    eventEdit.eGroupName &&
    [...eventEdit.eParameters].length
      ? true
      : false;

  // CREATE/UPDATE BUTTON CLICK - FUNCTION TO CREATE A NEW EVENTS AND ALSO TO UPDATE AN EXISTING ONE
  const eventUpsert = () => {
    // EDITING PARAMETER ROW CELL VALUES FROM EXISTING VALUES
    const rowsDataMapUpdated = apiRef?.current?.getRowModels();
    const selectedRowsUpdate = Array.from(rowsDataMapUpdated, ([key, value]) => {
      const editedParamValue: any = Array.isArray(value?.values) ? value.values[0] : value.values;
      return {
        name: value.name,
        values: [editedParamValue],
        id: value.id,
      };
    });
    setEventEdit({ ...eventEdit, eParameters: selectedRowsUpdate });
    const eventFinalParameters = selectedRowsUpdate.map(param => {
      return { name: param.name, values: param.values };
    });

    const input: IUpsertEvents = {
      eventId: eventId,
      eventCd: eventEdit.eCode,
      eventDesc: eventEdit.eDesc,
      isrtdByUsrNm: isrtdByUsrNm,
      lastUpdtByUserNm: lstUpdtByUsrNm,
      topicName: eventEdit.eTopicName,
      groupName: eventEdit.eGroupName,
      maxMessage: eventEdit.eMaxMessage,
      filterJson: {
        extractTimestamp: eventEdit.eExtractTimestamp ? eventEdit.eExtractTimestamp : null,
        ISOCountryCode: isoCountryCd,
        subjectArea: eventEdit.eSubjectArea,
        cycleId: eventEdit.eCycleId ? eventEdit.eCycleId : null,
        cycleType: eventEdit.eCycleType,
        mdelName: eventEdit.eMdelName ? eventEdit.eMdelName : null,
        parameters: eventFinalParameters,
      },
    };

    const upsertInput: IUpsertEventsDetails = {
      mdelId: model,
      insert: newEvent ? [input] : null,
      update: !newEvent ? [input] : null,
      delete: null,
    };

    globalApis
      .upsertEventsDetails(upsertInput)
      .then(response => {
        closeEditDialog();
        setRefreshList(!refreshList);
      })
      .catch(error => error);
  };

  // + PARAMETER BUTTON CLICK - ADDING A NEW PARAMETER VALUE ROW WHEN USER CLICK +PARAMETER BUTTON.
  const addNewParameterValue = () => {
    const rowsDataMapUpdated = apiRef?.current?.getRowModels();
    const selectedRowsUpdate = rowsDataMapUpdated && Array.from(rowsDataMapUpdated, ([key, value]) => value);
    const maxId = selectedRowsUpdate && Math.max(...selectedRowsUpdate.map((id: any) => id.id));
    selectedRowsUpdate
      ? setEventEdit({
          ...eventEdit,
          eParameters: [
            ...eventEdit.eParameters,
            ...selectedRowsUpdate,
            {
              name: '',
              values: [],
              id: maxId ? maxId + 100 : 100,
              key: 'insert',
            },
          ],
        })
      : setEventEdit({
          ...eventEdit,
          eParameters: [
            ...eventEdit.eParameters,
            {
              name: '',
              values: [],
              key: 'insert',
              id: maxId ? maxId + 100 : 100,
            },
          ],
        });
  };

  // DELETE BUTTON CLICK - FUNCTION TO SET THE ROWS WHICH USER WANTS TO DELETE AFTER CLICKING DELETE BUTTON
  const deleteParameterRows = () => {
    // IF EDITING PARAMETER ROW CELL VALUES FROM EXISTING VALUES
    const rowsDataMapUpdated = apiRef?.current?.getRowModels();
    const selectedRowsUpdate = Array.from(rowsDataMapUpdated, ([key, value]) => {
      const editedParamValue = Array.isArray(value?.values) ? value.values[0] : value.values;
      return {
        name: value.name,
        values: [editedParamValue],
        id: value.id,
      };
    });
    // SELECTED ROWS WHICH WE GOING TO DELETE
    const selectedRowsData = apiRef?.current?.getSelectedRows();
    const selectedRowsArrData = Array.from(selectedRowsData, ([key, value]) => {
      const updatedParamValue = Array.isArray(value?.values) ? value.values[0] : value.values;
      return {
        name: value.name,
        values: [updatedParamValue],
        id: value.id,
      };
    });
    // UPDATE THE STATE AFTER DELETING THE ROWS
    const rowsAfterDelete = selectedRowsUpdate.filter(
      (existItem: any) => !selectedRowsArrData.some(deleteItem => existItem.id === deleteItem.id)
    );
    setEventEdit({ ...eventEdit, eParameters: rowsAfterDelete });
  };

  return (
    <Dialog fullScreen open={openEditDialog} onClose={closeEditDialog} TransitionComponent={Transition}>
      <AppBar className={classes.appBar} color='transparent'>
        <Toolbar>
          <IconButton edge='start' color='inherit' onClick={closeEditDialog} aria-label='close'>
            <CloseIcon />
          </IconButton>
          <Typography variant='h6' className={classes.title}>
            {eventDesc}
          </Typography>
          <Button
            variant='contained'
            style={{ marginLeft: '1rem' }}
            color='primary'
            disabled={!isRequired}
            onClick={eventUpsert}
          >
            {newEvent ? 'CREATE' : 'UPDATE'}
          </Button>
        </Toolbar>
      </AppBar>
      <section style={{ padding: '1.5rem' }}>
        <Typography>Event Definition</Typography>
        <Typography style={{ marginTop: '0.8rem' }} variant='subtitle1' color='textSecondary'>
          These settings configure an Event that will trigger an active request to run once the event has been
          scheduled.
        </Typography>
      </section>

      <form className={classes.gridContainer}>
        <Grid container>
          <Grid item xs={12} sm={12} md={6}>
            <div className={classes.textFieldFlex}>
              <TextField
                className={classes.fieldSize}
                label='Event Code*'
                type='text'
                variant='outlined'
                value={eventEdit.eCode}
                onChange={event => setEventEdit(prev => ({ ...prev, eCode: event.target.value }))}
              />
              <HelpOutlineSharpIcon className={classes.icon} />
            </div>
            <div className={classes.textFieldFlex}>
              <TextField
                className={classes.fieldSize}
                label='Event Description*'
                variant='outlined'
                value={eventEdit.eDesc}
                onChange={event => setEventEdit(prev => ({ ...prev, eDesc: event.target.value }))}
              />
              <HelpOutlineSharpIcon className={classes.icon} />
            </div>
            <div className={classes.textFieldFlex}>
              <TextField
                className={classes.fieldSize}
                label='Cycle Type*'
                variant='outlined'
                value={eventEdit.eCycleType}
                onChange={event => setEventEdit(prev => ({ ...prev, eCycleType: event.target.value }))}
                helperText='Example: "Monthly", "Weekly", "Quarterly"'
              />
              <HelpOutlineSharpIcon className={classes.icon} />
            </div>
            <div className={classes.textFieldFlex}>
              <TextField
                className={classes.fieldSize}
                label='Event Subject Area*'
                value={eventEdit.eSubjectArea}
                onChange={event => setEventEdit(prev => ({ ...prev, eSubjectArea: event.target.value }))}
                variant='outlined'
                helperText='We recommend that you do not to change this value'
              />
              <HelpOutlineSharpIcon className={classes.icon} />
            </div>
            <div className={classes.textFieldFlex}>
              <TextField
                className={classes.fieldSize}
                label='Topic Name*'
                value={eventEdit.eTopicName}
                onChange={event => setEventEdit(prev => ({ ...prev, eTopicName: event.target.value }))}
                variant='outlined'
              />
              <HelpOutlineSharpIcon className={classes.icon} />
            </div>
            <div className={classes.textFieldFlex}>
              <TextField
                className={classes.fieldSize}
                label='Group Name*'
                value={eventEdit.eGroupName}
                onChange={event => setEventEdit(prev => ({ ...prev, eGroupName: event.target.value }))}
                variant='outlined'
              />
              <HelpOutlineSharpIcon className={classes.icon} />
            </div>
            <div className={classes.textFieldFlex}>
              <TextField
                className={classes.fieldSize}
                label='Max Message*'
                value={eventEdit.eMaxMessage}
                onChange={event => setEventEdit(prev => ({ ...prev, eMaxMessage: Number(event.target.value) }))}
                variant='outlined'
                type='number'
                InputProps={{ inputProps: { min: 1 } }}
              />
              <HelpOutlineSharpIcon className={classes.icon} />
            </div>
            <div className={classes.textFieldFlex}>
              <TextField
                className={classes.fieldSize}
                label='Model Name'
                value={eventEdit.eMdelName}
                onChange={event => setEventEdit(prev => ({ ...prev, eMdelName: event.target.value }))}
                variant='outlined'
              />
              <HelpOutlineSharpIcon className={classes.icon} />
            </div>
            <div className={classes.textFieldFlex}>
              <TextField
                className={classes.fieldSize}
                label='Extract Time Stamp'
                value={eventEdit.eExtractTimestamp}
                onChange={event => setEventEdit(prev => ({ ...prev, eExtractTimestamp: event.target.value }))}
                variant='outlined'
              />
              <HelpOutlineSharpIcon className={classes.icon} />
            </div>
            <div className={classes.textFieldFlex}>
              <TextField
                type='number'
                className={classes.fieldSize}
                label='Cycle ID'
                value={eventEdit.eCycleId}
                onChange={event => setEventEdit(prev => ({ ...prev, eCycleId: Number(event.target.value) }))}
                variant='outlined'
                helperText='We recommend to enter only the numbers'
              />
              <HelpOutlineSharpIcon className={classes.icon} />
            </div>
            <div className={classes.parameterContainer}>
              <div className={classes.paramTitle}>Parameters</div>
              <section className={classes.btnFlex}>
                <Button color='primary' variant='outlined' startIcon={<AddIcon />} onClick={addNewParameterValue}>
                  PARAMETER
                </Button>
                <Button color='primary' onClick={deleteParameterRows} disabled={selectionModel.length === 0 && true}>
                  DELETE
                </Button>
              </section>
              {/* LISTING ALL THE PARAMETER VALUES FOR A GIVEN PARAMETER ID */}
              <DataGrid
                autoHeight
                className={classes.gridColHeader}
                rows={eventEdit.eParameters as GridRowData[]}
                columns={columns}
                checkboxSelection
                disableSelectionOnClick
                onSelectionModelChange={handleEditCheckBox}
                selectionModel={selectionModel}
                hideFooter
                hideFooterPagination
                hideFooterRowCount
                hideFooterSelectedRowCount
                pageSize={Array.from(new Set([...eventEdit.eParameters].map(data => data.id))).length}
              />
            </div>
          </Grid>
          <Grid item xs={12} sm={12} md={6} className={classes.rightInfoContainer}>
            <aside style={{ display: 'flex', margin: '1rem' }}>
              <div style={{ marginRight: '3rem' }} className={classes.sideContent}>
                <Typography className={classes.textField}>Last update:</Typography>
                <Typography className={classes.textField}>Created:</Typography>
                <Typography className={classes.textField}>Model ID:</Typography>
                <Typography className={classes.textField}>Event ID:</Typography>
                <Typography className={classes.textField}>Country Code:</Typography>
              </div>
              <div className={classes.sideContent}>
                <Typography className={classes.textField} color='textSecondary'>
                  {lstUpdtDt ? (dateFormat(lstUpdtDt), lstUpdtByUsrNm) : '-'}
                </Typography>
                <Typography className={classes.textField} color='textSecondary'>
                  {isrtdDt ? (dateFormat(isrtdDt), isrtdByUsrNm) : '-'}
                </Typography>
                <Typography color='textSecondary' className={classes.textField}>
                  {model}
                </Typography>
                <Typography color='textSecondary' className={classes.textField}>
                  {eventId ? eventId : '-'}
                </Typography>
                <Typography color='textSecondary' className={classes.textField}>
                  {isoCountryCd ? isoCountryCd : '-'}
                </Typography>
              </div>
            </aside>
          </Grid>
        </Grid>
      </form>
    </Dialog>
  );
};

export default EventEdit;
