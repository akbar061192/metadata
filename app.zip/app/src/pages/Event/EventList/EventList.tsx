import React, { useState, useEffect } from 'react';
import { createStyles, makeStyles, Theme } from '@material-ui/core/styles';
import { TransitionProps } from '@material-ui/core/transitions';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import AddIcon from '@material-ui/icons/Add';
import SearchIcon from '@material-ui/icons/Search';
import { FormControl, InputAdornment, OutlinedInput, Slide, Dialog, AppBar, Button } from '@material-ui/core';
import { Typography, Avatar, Toolbar, IconButton } from '@material-ui/core';
import EventMenuItem from './EventMenuItem';
import { DataGrid, GridColDef, GridRowData, GridValueFormatterParams } from '@material-ui/data-grid';
import { globalApis } from '../../../global/services/apis';
import { IGetEventsByModelId } from '../../../global/services/apistypes';
import EventEdit from '../EventEdit/EventEdit';
import { EventDetails } from './EventMenuItem';

interface EventListProps {
  openListDialog: boolean;
  closeListDialog: () => void;
  modelId: number;
  isoCountryCd: string;
}

// LIST OF EVENT's INTIAL STATE AND WILL BE USED WHILE CALLING API.
const ScheduleEvent: IGetEventsByModelId[] | [] = [];

/**
 *
 * Component for listing the Event for a given MODEL ID and also for performing Edit actions.
 *
 * @param openEditDialog - boolean state to open the EventList dialog.
 * @param closeEditDialog - boolean state to close the EventList dialog.
 * @param modelId - model id of currently editing subject area.
 *
 **/

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    appBar: {
      position: 'relative',
    },
    title: {
      marginLeft: theme.spacing(2),
      flex: 1,
    },
    addSection: {
      padding: '1rem',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '1rem',
    },
    gridContainer: {
      alignItems: 'center',
    },
    gridColHeader: {
      borderTop: 'none',
      cursor: 'pointer',
      '& .MuiDataGrid-columnHeaderTitle': {
        color: 'gray',
      },
      '& .MuiDataGrid-columnSeparator': {
        color: 'white',
      },
      '& .MuiDataGrid-columnHeaderTitleContainer': {
        padding: 0,
      },
    },
  })
);

// CONVERTING INCOMING DATE TO UTC WITH PROPER FORMATTING
const dateFormat = (date: string) => {
  const inputDate = new Date(date).toUTCString().slice(5, 22);
  let char = ',';
  let position = 11;
  let output = [inputDate.slice(0, position), char, inputDate.slice(position)].join('');
  return output;
};

// DIALOG TRANSISTION EFFECT
const Transition = React.forwardRef(function Transition(
  props: TransitionProps & { children?: React.ReactElement },
  ref: React.Ref<unknown>
) {
  return <Slide direction='up' ref={ref} {...props} />;
});

// START OF COMPONENT
const EventList: React.FC<EventListProps> = props => {
  // DE-STRUCTURING THE INCOMING PROPS
  const { openListDialog, closeListDialog, modelId, isoCountryCd } = props;
  const classes = useStyles();

  // STATE FOR OPENING EDIT EVENT DIALOG
  const [openEvent, setOpenEvent] = useState(false);

  // STATE FOR STORING TRUE/FALSE VALUE WHEN +EVENT BUTTON IS CLICKED
  const [newEvent, setNewEvent] = useState(false);

  // STATE FOR REFRESHING THE EVENT LIST AFTER UPSERT
  const [refreshList, setRefreshList] = useState(false);

  //STATE FOR CLICKING A SPECIFIC LIST ROW AND OPENING EDIT PAGE
  const [onCellClick, setOnCellClick] = useState(false);

  //STATE FOR SAVING TARGET OBJECT ON WHICH USER HAS CLICKED
  const [onCellClickEvent, setOnCellClickEvent] = useState<IGetEventsByModelId | {}>({});

  // CLOSE NEW EVENT DIALOG ON CLICKING CANCEL BUTTON
  const closeEventDialog = (event?: React.SyntheticEvent, reason?: string) => {
    if (reason === 'backdropClick') {
      return;
    }
    setOpenEvent(false);
    setNewEvent(false);
    setOnCellClickEvent(EventDetails);
  };

  // LOCAL STATE TO STORE USER INPUT ENTERED UNDER SEARCH BOX
  const [searchInput, setSearchInput] = useState<string>('');

  // LOCAL STATE TO STORE EVENTS FOR A GIVEN MODEL ID
  const [events, setEvents] = useState<IGetEventsByModelId[]>(ScheduleEvent);

  // LOCAL STATE TO STORE SEARCHED RESULTS WHEN USER ENTER'S VALUES IN SEARCH BOX
  const [searchResults, setSearchResults] = useState<IGetEventsByModelId[]>(ScheduleEvent);

  // TRANSFORMING INCOMING EVENT VALUES TO HAVE 'ID' AS KEY SINCE DATA GRID EXPECTS.
  useEffect(() => {
    globalApis
      .getEventsByModelId(modelId)
      .then(response => {
        const updatedEvents: IGetEventsByModelId[] = response.data.map((events: IGetEventsByModelId) => ({
          ...events,
          lstUpdtDt: dateFormat(events.lstUpdtDt),
          id: events.eventId,
        }));
        setEvents(updatedEvents);
      })
      .catch(err => err);
  }, [modelId, refreshList]);

  // COLUMNS DEFINITION FOR DATA GRID
  const columns: GridColDef[] = [
    {
      field: 'modelId',
      headerName: 'Type',
      type: 'string',
      width: 82,
      editable: false,
      disableColumnMenu: true,
      align: 'center',
      headerAlign: 'center',
      sortable: true,
      renderCell: (params: GridValueFormatterParams) => {
        return <ListType data={params} />;
      },
    },
    {
      field: 'eventId',
      headerName: 'ID',
      type: 'number',
      flex: 0,
      editable: false,
      disableColumnMenu: true,
      align: 'center',
      headerAlign: 'center',
      valueFormatter: (params: GridValueFormatterParams) => {
        const valueFormatted = Number(params.value).toString().replace(',', '');
        return valueFormatted;
      },
    },
    {
      field: 'eventDesc',
      headerName: 'Event Description',
      type: 'string',
      flex: 1,
      editable: false,
      disableColumnMenu: true,
      align: 'left',
      headerAlign: 'left',
      renderCell: (params: GridValueFormatterParams) => {
        return <ListNameGroup data={params} />;
      },
    },
    {
      field: 'lstUpdtByUsrNm',
      headerName: 'Last Edit',
      type: 'string',
      flex: 0.2,
      minWidth: 200,
      editable: false,
      disableColumnMenu: true,
      align: 'left',
      headerAlign: 'left',
      renderCell: (params: GridValueFormatterParams) => {
        return <LastEdit data={params} />;
      },
    },
    {
      field: '',
      headerName: '',
      type: 'string',
      editable: false,
      disableColumnMenu: true,
      width: 48,
      align: 'center',
      headerAlign: 'center',
      sortable: false,
      renderCell: (params: GridValueFormatterParams) => {
        return (
          <MenuCol
            data={params}
            setRefreshList={setRefreshList}
            refreshList={refreshList}
            isoCountryCd={isoCountryCd}
            modelId={modelId}
          />
        );
      },
    },
  ];

  // LOGIC TO FILTER THE LIST OF EVENT's WITH USER ENTERED DATA IN SEARCH BOX.
  useEffect(() => {
    if (searchInput !== '') {
      const filteredOutput = events.filter((event: IGetEventsByModelId) => {
        return Object.values(event).join(' ').toLowerCase().includes(searchInput.toLowerCase());
      });
      setSearchResults(filteredOutput);
    } else {
      setSearchResults(events);
    }
  }, [searchInput, events]);

  // CHECK FOR DISPLAYING ROW DATA IN DATA GRID.
  const rowData: GridRowData[] = searchInput.length < 1 ? events : searchResults;

  return (
    <>
      {/* USED TO OPEN EDIT DIALOG FOR CREATING NEW EVENT WHEN +EVENT IS CLICKED */}
      {openEvent && newEvent ? (
        <EventEdit
          mdelId={modelId}
          openEditDialog={openEvent}
          closeEditDialog={closeEventDialog}
          eventDetails={EventDetails}
          newEvent={newEvent}
          setRefreshList={setRefreshList}
          refreshList={refreshList}
          isoCountryCd={isoCountryCd}
        />
      ) : null}

      {/* USED TO OPEN EDIT DIALOG FOR EDITING EVENT WHEN EXISTING EVENT IS CLICKED */}

      {openEvent && onCellClick ? (
        <EventEdit
          mdelId={modelId}
          openEditDialog={openEvent}
          closeEditDialog={closeEventDialog}
          eventDetails={onCellClickEvent}
          newEvent={newEvent}
          setRefreshList={setRefreshList}
          refreshList={refreshList}
          isoCountryCd={isoCountryCd}
        />
      ) : null}

      <Dialog fullScreen open={openListDialog} onClose={closeListDialog} TransitionComponent={Transition}>
        <AppBar className={classes.appBar} color='transparent'>
          <Toolbar>
            <IconButton edge='start' color='inherit' onClick={closeListDialog} aria-label='close'>
              <ArrowBackIcon />
            </IconButton>
            <Typography variant='h6' className={classes.title}>
              Schedule Events
            </Typography>
          </Toolbar>
        </AppBar>

        <section className={classes.addSection}>
          <Button
            style={{ marginLeft: '1rem' }}
            color='primary'
            variant='contained'
            startIcon={<AddIcon />}
            onClick={() => {
              setOpenEvent(true);
              setNewEvent(true);
            }}
          >
            EVENT
          </Button>

          <FormControl variant='outlined' style={{ width: '21rem', marginRight: '1rem' }}>
            <OutlinedInput
              id='outlined-adornment-weight'
              placeholder='Search Events'
              endAdornment={<InputAdornment position='end'>{<SearchIcon />}</InputAdornment>}
              aria-describedby='outlined-weight-helper-text'
              labelWidth={0}
              value={searchInput}
              onChange={event => setSearchInput(event.target.value)}
            />
          </FormControl>
        </section>

        {/* LISTING ALL THE EVENT's FOR A GIVEN MODEL ID */}
        <DataGrid
          autoHeight
          className={classes.gridColHeader}
          rows={rowData}
          pageSize={Array.from(new Set(rowData.map(data => data.eventId))).length}
          columns={columns}
          density='comfortable'
          hideFooter
          hideFooterPagination
          hideFooterRowCount
          hideFooterSelectedRowCount
          disableSelectionOnClick
          onCellClick={(params: GridValueFormatterParams) => {
            if (params.field) {
              setOnCellClick(true);
              setOpenEvent(true);
              setOnCellClickEvent(params.row);
            }
          }}
        />
      </Dialog>
    </>
  );
};

/*
 * COMPONENT TO OVERRIDE THE COLUMN OF THE DATA-GRID TO DISPLAY EVENT DESC AND EVENT CODE.
 */

interface ListTypeProps {
  data: any;
}

export const ListType: React.FC<ListTypeProps> = props => {
  return (
    <Avatar style={{ background: '#9e54b0' }}>
      <Typography variant='body2'>E</Typography>
    </Avatar>
  );
};

/*
 * COMPONENT TO OVERRIDE THE COLUMN OF THE DATA-GRID TO DISPLAY LIST NAME AND EVENT GROUP.
 */
interface ListNameGroupProps {
  data: any;
}

export const ListNameGroup: React.FC<ListNameGroupProps> = props => {
  const { data } = props;

  return (
    <div style={{ minWidth: 0 }}>
      <Typography variant='body1' noWrap={true}>
        {data.row.eventDesc}
      </Typography>
      <Typography noWrap={true} color='textSecondary'>
        {`Requests (PROD): Active (${data.row.activeProdReq}), Inactive(${data.row.inactiveProdReq})`}
      </Typography>
    </div>
  );
};

/*
 * COMPONENT TO OVERRIDE THE COLUMN OF THE DATA-GRID TO DISPLAY LAST EDIT DATE AND LAST EDIT BY USER.
 */
interface LastEditProps {
  data: any;
}

export const LastEdit: React.FC<LastEditProps> = props => {
  const { data } = props;

  return (
    <div style={{ minWidth: 0 }}>
      <Typography variant='body1' noWrap={true}>
        {data.row.lstUpdtByUsrNm}
      </Typography>
      <Typography variant='body2' color='textSecondary' noWrap={true}>
        {data.row.lstUpdtDt}
      </Typography>
    </div>
  );
};

/*
 * COMPONENT TO OVERRIDE THE COLUMN OF THE DATA-GRID TO DISPLAY MENU WITH LIST OF OPTIONS.
 */
interface MenuProps {
  data: any;
  setRefreshList: any;
  refreshList: boolean;
  isoCountryCd: string;
  modelId: number;
}

export const MenuCol: React.FC<MenuProps> = props => {
  const { data, setRefreshList, refreshList, isoCountryCd, modelId } = props;
  return (
    <EventMenuItem
      scheduleEvent={data.row}
      setRefreshList={setRefreshList}
      refreshList={refreshList}
      isoCountryCd={isoCountryCd}
      modelId={modelId}
    />
  );
};

export default EventList;
