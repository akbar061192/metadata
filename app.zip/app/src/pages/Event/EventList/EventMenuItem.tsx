import React, { useState } from 'react';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import { Typography, IconButton, Menu, MenuItem } from '@material-ui/core';
import { IGetEventsByModelId, IUpsertEventsDelete, IUpsertEventsDetails } from '../../../global/services/apistypes';
import EventEdit from '../EventEdit/EventEdit';
import { globalApis } from '../../../global/services/apis';

interface EventMenuItemProps {
  scheduleEvent: any;
  setRefreshList: any;
  refreshList: boolean;
  isoCountryCd: string;
  modelId: number;
}

/**
 *
 * Component for listing the Edit actions for each Event
 *
 * @param scheduleEvent - scheduleEvent details object of user clicked row under list data grid
 *
 **/

// HEIGHT OF MENU DISPLAY
const ITEM_HEIGHT = 48;

export const EventDetails: IGetEventsByModelId = {
  eventId: 0,
  eventCd: '',
  eventDesc: '',
  modelId: 0,
  isrtdDt: '',
  isrtdByUsrNm: '',
  lstUpdtDt: '',
  lstUpdtByUsrNm: '',
  topicName: '',
  groupName: '',
  maxMessage: 1,
  filterJson: '',
  activeProdReq: 0,
  inactiveProdReq: 0
};

// START OF COMPONENT
const EventMenuItem: React.FC<EventMenuItemProps> = props => {

  // DE-STRUCTURING THE INCOMING PROPS
  const { scheduleEvent, setRefreshList, refreshList, isoCountryCd, modelId } = props;

  // LOCAL STATE TO HANDLE MENU FOR OPENING AND CLOSING
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);

  // FUNCTION TO OPEN MENU WHEN USER CLICKS MENU 3 DOTS ICON BUTTON.
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  // LOCAL STATE TO STORE BOOLEAN VALUE FOR OPENING EDIT DIALOG
  const [openEditEvent, setOpenEditEvent] = useState(false);

  // LOCAL STATE TO STORE EVENT DETAILS OBJECT WHICH WILL BE THEN PASSED TO EVENT EDIT LIST DIALOG.
  const [eventDetails, setEventDetails] = useState<IGetEventsByModelId>(EventDetails);

  // FUNCTION WILL BE CALLED WHEN USER CLICKS ON EDIT SETTINGS OPTION
  const openEditEventDialog = (scheduleEvent: IGetEventsByModelId) => {
    setOpenEditEvent(true);
    setEventDetails(scheduleEvent);
    setAnchorEl(null);
  };

  // FUNCTION TO CLOSE EDIT LIST DIALOG
  const closeEditEventDialog = () => {
    setOpenEditEvent(false);
    setAnchorEl(null);
  };

  // FUNCTION TO DELETE A EVENT
  const deleteEvents = (eventId: IUpsertEventsDelete) => {
    const upsertInput: IUpsertEventsDetails = {
      mdelId: modelId,
      insert: null,
      update: null,
      delete: [{ eventId }]
    };

    globalApis
      .upsertEventsDetails(upsertInput)
      .then(response => {
        setAnchorEl(null);
        setRefreshList(!refreshList);
      })
      .catch(error => error);
  };
  return (
    <>
      {openEditEvent ? (
        <EventEdit
          mdelId={eventDetails.modelId}
          openEditDialog={openEditEvent}
          closeEditDialog={closeEditEventDialog}
          eventDetails={eventDetails}
          newEvent={false}
          setRefreshList={setRefreshList}
          refreshList={refreshList}
          isoCountryCd={isoCountryCd}
        />
      ) : null}
      <section>
        <IconButton aria-label='more' aria-controls='long-menu' aria-haspopup='true' onClick={handleClick}>
          <MoreVertIcon />
        </IconButton>
        <Menu
          id='long-menu'
          anchorEl={anchorEl}
          keepMounted
          open={open}
          onClose={() => setAnchorEl(null)}
          PaperProps={{
            style: {
              maxHeight: ITEM_HEIGHT * 3.5,
              width: '10.5rem',
            },
          }}
          elevation={1}
          getContentAnchorEl={null}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
          transformOrigin={{ vertical: 'top', horizontal: 'right' }}
        >
          <MenuItem onClick={() => openEditEventDialog(scheduleEvent)}>
            <Typography>Edit settings...</Typography>
          </MenuItem>
          <MenuItem divider />
          <MenuItem onClick={() => { deleteEvents(scheduleEvent?.eventId) }}>
            <Typography>Delete…</Typography>
          </MenuItem>
        </Menu>
      </section>
    </>
  );
};

export default EventMenuItem;
