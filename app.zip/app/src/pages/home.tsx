import React, { FC } from "react";
import { makeStyles, Theme, createStyles } from "@material-ui/core/styles";
import { SubjectAreaCards } from "./subjectArea/subjectAreaCards";
import { Header } from "../global/components/header/header";
import StateProvider from "../global/context/subjectAreaContext";

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      display: "flex",
    },
    toolbar: theme.mixins.toolbar,
    content: {
      flexGrow: 1,
      // padding: theme.spacing(3),
    },
  })
);
export const Home: FC = () => {
  const classes = useStyles();
  return (
    <div className={classes.root}>
      <StateProvider>
        <Header></Header>
        <main className={classes.content}>
          <div className={classes.toolbar} />
          <SubjectAreaCards></SubjectAreaCards>
        </main>
      </StateProvider>
   
    </div>
    
  );
};
