import { useEffect, useContext, useState, FC, Dispatch } from 'react';
import Box from '@material-ui/core/Box';
import Typography from '@material-ui/core/Typography';
import AddIcon from '@material-ui/icons/Add';
import MoreIcon from '@material-ui/icons/MoreVert';
import WarningIcon from '@material-ui/icons/Warning';
import Button from '@material-ui/core/Button';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import CardActions from '@material-ui/core/CardActions';
import IconButton from '@material-ui/core/IconButton';
import Grid from '@material-ui/core/Grid';
import { makeStyles, Theme, createStyles } from '@material-ui/core/styles';
import { globalApis } from '../../global/services/apis';
import { Context } from '../../global/context/subjectAreaContext';
import { Link } from 'react-router-dom';
import SentimentVeryDissatisfiedIcon from '@material-ui/icons/SentimentVeryDissatisfied';
import AlertDialog from '../../global/components/alertDialog/AlertDialog';
import { useSelector, useDispatch } from 'react-redux';
import { AppState } from '../../global/redux/reducers/rootReducer';
import { PrivilegeActions, privilegesActionTypes } from '../../global/redux/actions/privilegesAction';

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      display: 'flex',
    },

    subjectCardArea: {
      padding: '0rem 1rem 0.5rem 1rem',
    },

    subjectCard: {
      padding: '0rem 0rem 0rem 0rem',
      boxSizing: 'border-box',
    },

    emptyPage: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      color: 'rgba(0, 0, 0, 0.38)',
      paddingTop: '5rem',
    },

    sadIcon: {
      width: '13rem',
      height: '13rem',
      opacity: '0.3',
    },
  })
);

// START OF THE COMPONENT
export const SubjectAreaCards: FC = () => {
  const classes = useStyles();
  const state = useContext(Context);
  const privilegesDispatch = useDispatch<Dispatch<PrivilegeActions>>();

  // DISPATCHING GET PRIVILEGES SUCCESS ACTION AND STORING DATA IN REDUX STORE
  const privilegeSuccess = (userPerms: any) => {
    privilegesDispatch({ type: privilegesActionTypes.GET_PRIVILEGES_SUCCESS, payload: userPerms });
  };

  // FETCHING DATA FROM REDUX STORE FOR USER PRIVILEGES
  const { userPerms } = useSelector((state: AppState) => state.privileges);

  // '+ADD' BUTTON VALIDATION BY CHECKING modelId=0 , privCd='AddModel' and MUST HAVE roleCd === 'CreateNewModel' OR USER WHO HAS DataArchitect ROLE WITH AddModel PRIVILEGES CAN ABLE TO CREATE A NEW MODEL.
  const addModelBtnValidation = userPerms.filter(user => {
    return (
      (user.modelId === 0 && user.roleCd === 'CreateNewModel' && user.privCd === 'AddModel') ||
      (user.roleCd === 'DataArchitect' && user.privCd === 'AddModel')
    );
  });

  // BELOW WILL FILTER ONLY THE MODEL's WHICH LOGGED IN USER HAS EDIT PRIVILEGES
  const modelsWithEditPriv = userPerms
    .filter(modelDetails => modelDetails.privCd === 'EditModel')
    .filter(models => state?.state.subjectArea.map(model => model.mdelDetails.mdelId)?.includes(models.modelId));

  // LOCAL STATE TO OPEN AND CLOSE DIALOG IF USER DOES NOT HAVE EDIT PRIVILEGES
  const [open, setOpen] = useState<boolean>(false);

  // OPEN DIALOG
  const openDialog = () => {
    setOpen(true);
  };

  //CLOSE DIALOG
  const closeDialog = (event?: React.SyntheticEvent, reason?: string) => {
    if (reason === 'backdropClick') {
      return;
    }
    setOpen(false);
  };

  useEffect(() => {
    globalApis
      .getPermissions()
      .then(response => {
        privilegeSuccess(response.data);
      })
      .catch(error => {});
    globalApis
      .getSubjectArea()
      .then(response => {
        state?.dispatch({
          type: 'subjectArea',
          payload: response.data,
        });
      })

      .catch(error => {});
  }, []);

  return (
    <div>
      {/* OPEN THE DIALOG IF 'open' IS true IN LOCAL STATE AND PASS NECESSARY PROPS TO ALERTDIALOG COMPONENT */}
      {open && <AlertDialog handleClose={closeDialog} open={open} />}
      {/* Page Content */}
      <Box p='1.5rem 0rem 0.5rem 1.5rem'>
        {' '}
        {/* Title Bar */}
        <Typography variant='h5'>Subject Areas</Typography>
      </Box>
      <Box p='0.75rem 0rem 1rem 1.5rem'>
        {' '}
        {/* Button Bar */}
        <Button variant='contained' color='primary' startIcon={<AddIcon />} disabled={addModelBtnValidation.length === 0 ? true : false}>
          Add
        </Button>
      </Box>
      {/* CHECK FOR SUBJECT AREA RETRIEVED FOR LOGGED-IN USER,IF EMPTY THEN BLANK PAGE WITH SAD FACE ICON IS DISPLAYED ELSE SUBJECT AREA CARDS */}
      {state?.state.subjectArea.length === 0 ? (
        <section className={classes.emptyPage}>
          <SentimentVeryDissatisfiedIcon className={classes.sadIcon} />
          <Typography color='textSecondary'>No Subject Areas!</Typography>
          <Typography color='textSecondary'>Click ‘Add’ to start creating a new one.</Typography>
        </section>
      ) : (
        <Grid container className={classes.subjectCardArea}>
          {' '}
          {/* Start Card Grid */}
          {state?.state.subjectArea.map((text, index) => (
            <Grid item xs={12} sm={12} md={6} lg={4} xl={3} key={index}>
              <div>
                <Box p='0.5rem'>
                  {' '}
                  {/* Start Subject Area Card */}
                  <Card className={classes.subjectCard}>
                    {' '}
                    {/* Card Component */}
                    <CardContent>
                      <Box display='flex'>
                        {/* Card Title */}
                        <Box p='0 0.25rem 0 0' color='text.secondary' flexGrow={1}>
                          <Typography variant='h6'>{text.mdelDetails.mdelDesc}</Typography>
                        </Box>
                        <Box p='0.5rem 0.25rem 0 0.25rem'>
                          {' '}
                          {/* Card Status */}
                          <WarningIcon fontSize='small' color='error' />
                        </Box>
                      </Box>
                    </CardContent>
                    <CardActions style={{ display: 'flex' }}>
                      {' '}
                      {/* Card Actions */}
                      {/* LINK BUTTON STARTS  */}
                      {/* VALIDATING THE MODELS WHICH HAS EDIT PRIV WITH ALL THE MODELS WHICH USER HAS ACCESS TO.
                    IF MODEL ID MATCHES THEN USER CAN ABLE TO EDIT IT ELSE THE DIALOG WILL OPEN WITH MESSAGE.
                    */}
                      {modelsWithEditPriv.some(model => {
                        return model.modelId === text.mdelDetails.mdelId;
                      }) ? (
                        <Link
                          style={{ textDecoration: 'none' }}
                          to={{
                            pathname: '/SubjectAreaDetails',
                            state: {
                              modelDetails: text.mdelDetails,
                            },
                          }}
                          key={text.mdelDetails.mdelId}
                        >
                          <Button color='primary'>Open</Button>
                        </Link>
                      ) : (
                        <Link style={{ textDecoration: 'none' }} to='#' onClick={openDialog} key={text.mdelDetails.mdelId}>
                          <Button color='primary'>Open</Button>
                        </Link>
                      )}
                      {/* LINK BUTTON END  */}
                      <Box flexGrow={1}></Box> {/* Filler Space */}
                      <IconButton aria-label='More Options'>
                        <MoreIcon />
                      </IconButton>
                    </CardActions>
                  </Card>
                </Box>
              </div>
            </Grid>
          ))}
          {/* End Card */}
        </Grid>
      )}{' '}
      {/* End Card Area */}
    </div> /* End Page Content */
  );
};
