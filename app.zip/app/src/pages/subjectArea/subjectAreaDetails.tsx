import { useEffect, useState, Dispatch, useRef } from 'react';
import { AppBar, Typography, Toolbar, CardContent, Card, Button, Grid, IconButton } from '@material-ui/core';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import SettingsIcon from '@material-ui/icons/Settings';
import ReportProblemOutlinedIcon from '@material-ui/icons/ReportProblemOutlined';
import CloudUploadIcon from '@material-ui/icons/CloudUpload';
import { useHistory, useLocation } from 'react-router-dom';
import { createStyles, makeStyles, Theme } from '@material-ui/core/styles';
import CloudCircleIcon from '@material-ui/icons/CloudCircle';
import BuildIcon from '@material-ui/icons/Build';
import SupervisorAccountIcon from '@material-ui/icons/SupervisorAccount';
import PlayCircleOutlineIcon from '@material-ui/icons/PlayCircleOutline';
import CenterFocusStrongIcon from '@material-ui/icons/CenterFocusStrong';
import PlaylistAddCheckIcon from '@material-ui/icons/PlaylistAddCheck';
import SettingsBackupRestoreIcon from '@material-ui/icons/SettingsBackupRestore';
import SaveIcon from '@material-ui/icons/Save';
import InsertLinkIcon from '@material-ui/icons/InsertLink';
import AdjustIcon from '@material-ui/icons/Adjust';
import LocationOnIcon from '@material-ui/icons/LocationOn';
import AccessAlarmIcon from '@material-ui/icons/AccessAlarm';
import FormatListNumberedIcon from '@material-ui/icons/FormatListNumbered';
import GroupWorkIcon from '@material-ui/icons/GroupWork';
import PermDataSettingIcon from '@material-ui/icons/PermDataSetting';
import ListIcon from '@material-ui/icons/List';
import Box from '@material-ui/core/Box';
import ExtensionIcon from '@material-ui/icons/Extension';
import CommitDialog from '../../global/components/commitDialog/CommitDialog';
import { CommitActions, commitActionTypes } from '../../global/redux/actions/commitAction';
import { useSelector, useDispatch } from 'react-redux';
import { AppState } from '../../global/redux/reducers/rootReducer';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import { globalApis } from '../../global/services/apis';
import RevertDialog from '../../global/components/revertDialog/RevertDialog';
import { IFetchPreviousCommits } from '../../global/services/apistypes';
import PromoteDialog from '../../global/components/promoteDialog/PromoteDialog';
import NoCommitDialog from '../../global/components/NoCommitDialog/NoCommitDialog';
import PromotePreviousDialog from '../../global/components/promotePreviousDialog/PromotePreviousDialog';
import SnackbarAlert from '../../global/components/snackBar/SnackBar';
import PublishIcon from '@material-ui/icons/Publish';
import LOVList from '../LOV/LOVList/LOVList';
import OutputDestList from '../OutputDestination/OutputDestList/OutputDestList';
import EventList from '../Event/EventList/EventList';

/**
 *
 * Component for displaying Subject Area Details of a User clicked SA under Cards page
 *
 * @param - This component receives 'modelDetails' as props from SubjectArea Cards page via Router Link and can be de-structured using useLocation hook.
 *
 **/

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    invalidIcon: {
      marginRight: '10px',
      color: 'error',
    },
    card: {
      cursor: 'pointer',
      '&:hover': {
        backgroundColor: 'whitesmoke',
      },
    },
    cardContent: {
      display: 'flex',
      '& .MuiSvgIcon-root': {
        color: 'grey',
      },
    },
    flexRow: {
      display: 'flex',
      flexDirection: 'row',
      alignItems: 'center',
      padding: '0rem 0.5rem',
    },
    previousCommitContainer: {
      display: 'flex',
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'flex-start',
      maxWidth: '30rem',
      '& .MuiSelect-root': {
        display: 'flex',
      },
    },
    menuItem: {
      display: 'flex',
      flexGrow: 1,
      flexDirection: 'column',
    },
    iconRow: {
      display: 'flex',
      alignItems: 'center',
    },
  })
);

// ARRAY OF SUBJECT AREA CARD DETAILS
const cardDetails = [
  { id: 1, title: 'General Settings', icon: <SettingsIcon fontSize='large' />, route: 'generalSettings' },
  { id: 2, title: 'Data Lake Settings', icon: <CloudCircleIcon fontSize='large' />, route: 'dataLakeSettings' },
  { id: 3, title: 'Data Customization Settings', icon: <BuildIcon fontSize='large' />, route: 'dataCustomizationSettings' },
  { id: 4, title: 'Client List Settings', icon: <SupervisorAccountIcon fontSize='large' />, route: 'clientListSettings' },
  { id: 5, title: 'Request Settings', icon: <PlayCircleOutlineIcon fontSize='large' />, route: 'requestSettings' },
  { id: 6, title: 'Entities', icon: <CenterFocusStrongIcon fontSize='large' />, route: 'entities' },
  { id: 7, title: 'Joins', icon: <InsertLinkIcon fontSize='large' />, route: 'joins' },
  { id: 8, title: 'Markets', icon: <AdjustIcon fontSize='large' />, route: 'markets' },
  { id: 9, title: 'Geographies', icon: <LocationOnIcon fontSize='large' />, route: 'geographies' },
  { id: 10, title: 'Schedule Events', icon: <AccessAlarmIcon fontSize='large' />, route: 'scheduleEvents' },
  { id: 11, title: 'Parameters', icon: <FormatListNumberedIcon fontSize='large' />, route: 'parameters' },
  { id: 12, title: 'Custom Attributes', icon: <GroupWorkIcon fontSize='large' />, route: 'customAttributes' },
  { id: 13, title: 'Custom Values', icon: <PermDataSettingIcon fontSize='large' />, route: 'customValues' },
  { id: 14, title: 'Output Destinations', icon: <PublishIcon fontSize='large' />, route: 'outputDestinations' },
  { id: 15, title: 'Modules', icon: <ExtensionIcon fontSize='large' />, route: 'modules' },
  { id: 16, title: 'List of Values', icon: <FormatListNumberedIcon fontSize='large' />, route: 'lists' },
];

export interface PromoteDetails {
  value: string;
  desc: string;
  key: string;
}

const revertResponse: IFetchPreviousCommits = {
  action: '',
  actionMsg: '',
  actionOutcome: '',
  actionLifecyc: '',
  actionTs: '',
  commitBranch: '',
  commitId: '',
  commitMsg: '',
  commitTs: '',
  modelId: 0,
  promotedEnv: '',
  userEmail: '',
  userName: '',
  version: '',
};
interface LocationParams {
  pathname: string;
  modelDetails: {
    mdelDesc: string;
    mdelId: number;
    mdelName: string;
    commitBranch: string;
    commitId: string;
    commitTs: string;
    commitMsg: string;
    isoCountryCd: string;
  };
  search: string;
  hash: string;
  key: string;
}

// LIST OF PROMOTES
export const promotes: PromoteDetails[] = [
  {
    value: 'Development',
    desc: 'Promote to Development…',
    key: 'devl',
  },
  {
    value: 'UACC',
    desc: 'Promote to UACC…',
    key: 'uacc',
  },
  {
    value: 'Production',
    desc: 'Promote to Production…',
    key: 'prod',
  },
];

// START OF THE COMPONENT
const SubjectAreaDetails: React.FC = () => {
  //HOOK TO GET props SENT FROM SUBJECT AREA CARDS PAGE VIA ROUTER LINK
  const location = useLocation<LocationParams>();
  const { modelDetails } = location.state;
  // HOOK WILL BE USED TO PUSH USER BACK TO SUBJECT AREA CARDS PAGE
  const history = useHistory();
  const classes = useStyles();

  // LOCAL STATE TO OPEN DIALOG WHEN USER CLICK ANY CARD FROM AVAILABLE CARDS
  const [openDialog, setOpenDialog] = useState({
    lists: false,
    outputDestinations: false,
    scheduleEvents: false,
  });

  // FUNCTION USED TO CHECK WHICH CARD IS CLICKED BY THE USER AND SET THE STATE ONLY FOR THE CLICKED CARD
  const openDialogOnCardClick = (cardID: number) => {
    const id = cardDetails.find(cID => cID.id === cardID);
    switch (id?.route) {
      case 'lists':
        setOpenDialog(prev => ({ ...prev, lists: true }));
        break;
      case 'outputDestinations':
        setOpenDialog(prev => ({ ...prev, outputDestinations: true }));
        break;
      case 'scheduleEvents':
        setOpenDialog(prev => ({ ...prev, scheduleEvents: true }));
        break;
    }
  };

  // FETCHING DATA FROM REDUX STORE FOR COMMIT
  const { IsCommit } = useSelector((state: AppState) => state.commmit);

  const backIconClick = () => {
    history.push('/SubjectAreaCards');
  };

  // LOCAL STATE WITH LIST OF PREVIOUS COMMITS OF A SUBJECT AREA
  const [allCommits, setAllCommits] = useState<any>([]);
  const [filteredCommits, setFilteredCommits] = useState<any>([]);

  // LOCAL STATE TO CAPTURE VERSION OF PREVIOUS REVERTING VERSION
  const [version, setVersion] = useState<any>('');

  // LOCAL STATE TO CAPTURE COMMITTING VERSION WHEN USER CLICKS ON COMMIT BUTTON IN DETIALS PAGE
  const [commitingVersion, setCommittingVersion] = useState<any>('');

  // SIMPLE HOOK TO GET PREVIOUS STATE OF VERSION AND WILL BE USED IF USER CLICKS ON CANCEL BUTTON UNDER REVERT DIALOG.
  const GetPreviousVersionState = (version: any) => {
    const ref = useRef();
    useEffect(() => {
      ref.current = version;
    }, [version]);
    return ref.current;
  };

  // INVOKING ABOVE HOOK AND STORING PREVIOUS VERSION STATE
  const prevStateVersion = GetPreviousVersionState(version);

  // STATE TO STORE ALL COMMITS WHILE LOADING DETAILS PAGE
  const [commits, setCommits] = useState<IFetchPreviousCommits[] | undefined>();

  useEffect(() => {
    // DISPATCHING GET ENABLE COMMIT ACTION TO GET THE ENABLE STATUS
    commitDispatch({ type: commitActionTypes.GET_ENABLE_COMMIT });

    // FETCHING PREVIOUS COMMITS AND COMPARING COMMIT OBJECT WITH EDITING SUBJECT AREA OBJECT
    globalApis
      .fetchPreviousCommits(modelDetails.mdelId)
      .then(response => {
        setCommits(response.data);
        const currentVersion = response.data.find(ver => {
          return (
            ver.commitId === modelDetails.commitId && ver.commitMsg === modelDetails.commitMsg && ver.commitTs === modelDetails.commitTs
          );
        });
        setVersion(currentVersion?.version);
      })
      .catch(error => error);
  }, []);

  // LOCAL STATE FOR OPENING AND CLOSING COMMIT COMMENT DIALOG
  const [openCommit, setOpenCommit] = useState(false);
  const commitDispatch = useDispatch<Dispatch<CommitActions>>();

  // LOCAL STATE FOR OPENING AND CLOSING PROMOTE COMMENT DIALOG
  const [openPromote, setOpenPromote] = useState(false);

  // LOCAL STATE FOR OPENING AND CLOSING NON COMMIT DIALOG
  const [openNoCommit, setNoCommit] = useState(false);

  // LOCAL STATE FOR OPENING AND CLOSING PROMOTE PREVIOUS VERSION DIALOG
  const [openPromotePrevious, setOpenPromotePrevious] = useState(false);

  // OPENING REVERT COMMIT DIALOG AND SENDING CLICKED COMMIT DETAILS TO DIALOG COMPONENT
  const [openRevertCommitDialog, setOpenRevertCommitDialog] = useState(false);

  const [revertingCommit, setRevertingCommit] = useState<IFetchPreviousCommits>(revertResponse);

  // PROMTING ITEM CLICKED BY USER [DEVL,UACC,PROD]
  const [promotingLifeCycle, setPromotingLifeCycle] = useState<any>();

  //LOCAL STATE FOR STORING ALL PREVIOUS COMMITS ON CLICKING PROMOTE PREVIOUS VERSION ITEM
  const [previousCommits, setPreviousCommits] = useState<any>([]);

  // OPEN COMMIT COMMENT DIALOG ON CLICKING 'COMMIT' BUTTON
  const openCommitDialog = () => {
    setOpenCommit(true);
  };

  // CLOSE COMMIT COMMENT DIALOG ON CLICKING CANCEL BUTTON
  const closeCommitDialog = (event?: React.SyntheticEvent, reason?: string) => {
    if (reason === 'backdropClick') {
      return;
    }
    setOpenCommit(false);
  };

  // OPEN PROMOTE DIALOG ON CLICKING 'PROMOTE' ICON BUTTON
  const openPromoteDialog = (lifeCycle: PromoteDetails) => {
    setOpenPromote(true);
    setPromotingLifeCycle(lifeCycle);
    setAnchorElPromote(null);
  };

  // CLOSE PROMOTE DIALOG ON CLICKING CANCEL BUTTON
  const closePromoteDialog = (event?: React.SyntheticEvent, reason?: string) => {
    if (reason === 'backdropClick') {
      return;
    }
    setOpenPromote(false);
  };

  // OPEN MENU FOR LIST OF DIFFERENT PROMOTES
  const [anchorElPromote, setAnchorElPromote] = useState<null | HTMLElement>(null);

  // OPENING PROMOTE MENU
  const openPromoteMenu = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorElPromote(event.currentTarget);
  };

  // CLOSING PROMOTE MENU
  const closePromoteMenu = () => {
    setAnchorElPromote(null);
  };

  // OPEN NON COMMIT DIALOG ON CLICKING 'PROMOTE' ICON BUTTON IF USER DID NOT COMMIT
  const openNoCommitDialog = () => {
    setNoCommit(true);
  };

  // CLOSE NO COMMIT DIALOG ON CLICKING CANCEL BUTTON
  const closeNoCommitDialog = (event?: React.SyntheticEvent, reason?: string) => {
    if (reason === 'backdropClick') {
      return;
    }
    setNoCommit(false);
  };

  // OPEN PROMOTE PREVIOUS DIALOG ON CLICKING 'PROMOTE PREVIOUS' ITEM FROM PROMOTE LIST MENU ITEMS
  const openPromotePreviousDialog = () => {
    setOpenPromotePrevious(true);
    setAnchorElPromote(null);
    globalApis
      .fetchPreviousCommits(modelDetails.mdelId)
      .then(response => {
        setPreviousCommits(response.data.filter(commit => commit.action === 'COMMITTED'));
      })
      .catch(error => {
        return error;
      });
  };

  // CLOSE NON COMMIT DIALOG ON CLICKING CANCEL BUTTON
  const closePromotePreviousDialog = (event?: React.SyntheticEvent, reason?: string) => {
    if (reason === 'backdropClick') {
      return;
    }
    setOpenPromotePrevious(false);
  };

  // MAKE A COMMIT BY CALLING API BY CLICKING 'COMMIT' BUTTON ON COMMIT DIALOG
  const makeCommit = (commitDetails: any) => {
    setCommittingVersion(commitDetails.version);
    setVersion(commitDetails.version);
  };

  // CLOSE REVET COMMIT DIALOG ON CLICKING CANCEL BUTTON
  const closeRevertCommitDialog = (event?: React.SyntheticEvent, reason?: string) => {
    if (reason === 'backdropClick') {
      return;
    }
    setOpenRevertCommitDialog(false);
    setVersion(prevStateVersion);
  };

  // LOCAL STATE FOR OPENING AND CLOSING SNACKBAR ALERT AFTER REVERT IS SUCCESSFUL
  const [openSnackBarRevert, setOpenSnackBarRevert] = useState(false);

  // CLICKING REVERT BUTTON IN REVERT DIALOG TO PREVIOUS VERSION BY CALLING API
  const revertPreviousVersion = () => {
    globalApis
      .promoteSubjectArea({
        modelId: revertingCommit.modelId,
        commitId: revertingCommit.commitId,
        targetEnv: 'intg',
      })
      .then(response => {
        closeRevertCommitDialog();
        setVersion(version);
        setOpenSnackBarRevert(true);
      })
      .catch(error => {
        closeRevertCommitDialog();
        return error;
      });
  };

  // STATE OF OPENING & CLOSING REVERT PREVIOUS COMMIT MENU
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

  // CLICK REVERT BUTTON TO OPEN PREVIOUS COMMITS MENU
  const clickRevertMenuButton = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
    globalApis
      .fetchPreviousCommits(modelDetails.mdelId)
      .then(response => {
        setFilteredCommits(response.data.filter(commit => commit.action === 'COMMITTED').slice(0, 5));
        setAllCommits(response.data.filter(commit => commit.action === 'COMMITTED'));
      })
      .catch(error => {
        return error;
      });
  };

  //LOAD COMMITS ON CLICKING MORE VERSION MENU ITEM
  const loadCommits = () => {
    const versions = [...allCommits];
    const slicedVersions = versions.slice(filteredCommits.length, filteredCommits.length + 5);
    setFilteredCommits([...filteredCommits, ...slicedVersions]);
  };

  // CLICKING A PREVIOUS COMMIT TO REVERT FROM LIST OF COMMITS
  const revertDialog = (commitInfo: IFetchPreviousCommits) => {
    setOpenRevertCommitDialog(true);
    setAnchorEl(null);
    setRevertingCommit(commitInfo);
    setVersion(commitInfo.version);
  };

  //CLOSE REVERT PREVIOUS COMMIT LIST
  const closePreviousCommitsMenu = () => {
    setAnchorEl(null);
  };

  // CONVERTING INCOMING DATE TO UTC WITH PROPER FORMATTING
  const dateFormat = (date: string) => {
    const inputDate = new Date(date).toUTCString().slice(5, 22) + ' UTC';
    let char = ',';
    let position = 11;
    let output = [inputDate.slice(0, position), char, inputDate.slice(position)].join('');
    return output;
  };

  // CLOSE SNAKBAR ALERT WHEN USER CLICKS ON X BUTTON
  const closeSnackBarRevert = (event?: React.SyntheticEvent, reason?: string) => {
    if (reason === 'clickaway') {
      return;
    }
    setOpenSnackBarRevert(false);
  };

  return (
    <>
      {/* START OF DIALOG's */}
      {/* OPENS LOV LIST DIALOG WHEN USER CLICKS ON LIST OF VALUES CARD OPTION FROM SA DETAILS PAGE */}
      {openDialog.lists ? (
        <LOVList
          openListDialog={openDialog.lists}
          closeListDialog={() => setOpenDialog(prev => ({ ...prev, lists: false }))}
          modelId={modelDetails.mdelId}
        />
      ) : null}
      {/* OPENS OUTPUT DESTINATION DIALOG WHEN USER CLICKS ON OUTPUT DESTINATION CARD OPTION FROM SA DETAILS PAGE */}
      {openDialog.outputDestinations ? (
        <OutputDestList
          openListDialog={openDialog.outputDestinations}
          closeListDialog={() => setOpenDialog(prev => ({ ...prev, outputDestinations: false }))}
          modelId={modelDetails.mdelId}
        />
      ) : null}
      {/* OPENS EVENTS DIALOG WHEN USER CLICKS ON SCHEDULE EVENTS CARD OPTION FROM SA DETAILS PAGE */}
      {openDialog.scheduleEvents ? (
        <EventList
          openListDialog={openDialog.scheduleEvents}
          closeListDialog={() => setOpenDialog(prev => ({ ...prev, scheduleEvents: false }))}
          modelId={modelDetails.mdelId}
          isoCountryCd={modelDetails.isoCountryCd}
        />
      ) : null}
      {/* OPENS COMMIT DIALOG WHEN USER CLICKS ON COMMIT BUTTON */}
      <CommitDialog
        open={openCommit}
        handleClose={closeCommitDialog}
        mdelId={modelDetails.mdelId}
        makeCommit={makeCommit}
        version={commitingVersion}
      />
      {/* OPENS REVERT DIALOG WHEN USER CLICKS ON REVERT PREVIOUS VERSION ICON BUTTON */}
      <RevertDialog
        open={openRevertCommitDialog}
        handleClose={closeRevertCommitDialog}
        reverting={revertingCommit}
        isCommit={IsCommit}
        revertPreviousVersion={revertPreviousVersion}
      />
      {/* OPENS NO COMMIT DIALOG IF USER CLICKS ON PROMOTE ICON BUTTON WITH CHANGES BEFORE COMMITTING */}
      <NoCommitDialog
        open={openNoCommit}
        handleClose={closeNoCommitDialog}
        mdelId={modelDetails.mdelId}
        version={version}
        makeCommit={makeCommit}
      />
      {/* OPENS PROMOTE DIALOG WHEN USER CLICKS ON ICON BUTTON AFTER ALL CHANGES ARE COMMITED */}
      <PromoteDialog
        open={openPromote}
        handleClose={closePromoteDialog}
        promotingLifeCycle={promotingLifeCycle}
        promotingVersion={version}
        commits={commits}
      />
      {/* OPENS PROMOTE PREVIOUS DIALOG IF USER SELECTS PREVIOUS OPTION FROM THE MENU ITEM LIST */}
      <PromotePreviousDialog
        open={openPromotePrevious}
        handleClose={closePromotePreviousDialog}
        previousCommits={previousCommits}
        currentVersion={version}
      />
      {/* OPENS SNACKBAR WHEN REVERT IS SUCCESSFUL */}
      <SnackbarAlert
        alertMessage={`Reverted to ${version} version`}
        closeSnackBarAlert={closeSnackBarRevert}
        openSnackBar={openSnackBarRevert}
      />
      {/* END OF DIALOG's */}
      <AppBar style={{ backgroundColor: 'white' }}>
        <Toolbar>
          <IconButton onClick={backIconClick} disableRipple edge='start'>
            <ArrowBackIcon />
          </IconButton>
          <Typography color='textPrimary' variant='h6'>
            {modelDetails.mdelDesc}
          </Typography>
          <Typography style={{ flexGrow: 1, marginLeft: '12px' }} color='textSecondary' variant='body2'>
            {version ? `v${version}` : ''}
          </Typography>
          <IconButton title='Revert to previous version' onClick={clickRevertMenuButton}>
            <SettingsBackupRestoreIcon />
          </IconButton>

          {/* DISPLAY LIST OF PREVIOUS VERSION OF A SUBJECT AREA -- START*/}
          <Menu
            id='simple-menu'
            anchorEl={anchorEl}
            keepMounted
            open={Boolean(anchorEl)}
            onClose={closePreviousCommitsMenu}
            getContentAnchorEl={null}
            anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
            transformOrigin={{ vertical: 'top', horizontal: 'right' }}
          >
            {filteredCommits.length > 0 &&
              filteredCommits.map((option: IFetchPreviousCommits) => (
                <MenuItem
                  key={option.version}
                  className={classes.previousCommitContainer}
                  style={{ backgroundColor: option.version === version ? 'lightgray' : '' }}
                  title={option.commitMsg}
                  onClick={() => revertDialog(option)}
                >
                  <div className={classes.menuItem} style={{ minWidth: 0, paddingRight: '1rem' }}>
                    <Typography
                      color='textPrimary'
                      style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}
                      variant='body1'
                    >
                      {option.version + ' - ' + dateFormat(option.commitTs && option.commitTs)}
                    </Typography>
                    <Typography
                      color='textSecondary'
                      style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}
                      variant='caption'
                    >
                      {option.commitMsg}
                    </Typography>
                  </div>

                  <div className={classes.iconRow}>
                    <Typography color='textPrimary' variant='body2'>
                      {option.promotedEnv?.toUpperCase()}
                    </Typography>
                    {option.promotedEnv ? (
                      <CloudUploadIcon style={{ color: 'gray', paddingLeft: '0.5rem' }} />
                    ) : (
                      <SaveIcon style={{ color: 'gray' }} />
                    )}
                  </div>
                </MenuItem>
              ))}
            <MenuItem disabled={allCommits.length === filteredCommits.length ? true : false} onClick={loadCommits}>
              {allCommits.length === 0 ? 'No Commits found' : 'More versions...'}
            </MenuItem>
          </Menu>
          {/* DISPLAY LIST OF PREVIOUS VERSION OF A SUBJECT AREA -- END */}
          <IconButton title='Promote Subject Area' onClick={IsCommit ? openPromoteMenu : openNoCommitDialog}>
            <CloudUploadIcon />
          </IconButton>

          {/* MENU LIST FOR DIFFERENT PROMOTE OPTIONS */}
          <Menu
            id='simple-menu'
            anchorEl={anchorElPromote}
            keepMounted
            open={Boolean(anchorElPromote)}
            onClose={closePromoteMenu}
            getContentAnchorEl={null}
            anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
            transformOrigin={{ vertical: 'top', horizontal: 'right' }}
          >
            {promotes.map((promote: PromoteDetails) => {
              return (
                <MenuItem key={promote.value} onClick={() => openPromoteDialog(promote)}>
                  {promote.desc}
                </MenuItem>
              );
            })}
            <MenuItem divider />
            <MenuItem onClick={openPromotePreviousDialog}>Promote a previous version…</MenuItem>
          </Menu>
        </Toolbar>
      </AppBar>
      <Toolbar></Toolbar> {/* MUI hack to push down content under the AppBar */}
      {/* Page Message and button bar Start */}
      <div
        className={classes.flexRow}
        style={{
          flexDirection: 'row-reverse',
          flexWrap: 'wrap',
          justifyContent: 'space-between',
        }}
      >
        <div className={classes.flexRow} style={{ justifyContent: 'flex-end', minHeight: '4rem' }}>
          <Button variant='outlined' color='primary' startIcon={<PlaylistAddCheckIcon />}>
            Validate
          </Button>
          <div style={{ width: '1rem' }}></div> {/* space between buttons */}
          <Button variant='contained' color='primary' disabled={!IsCommit} startIcon={<SaveIcon />} onClick={openCommitDialog}>
            COMMIT
          </Button>
        </div>

        {/* OPENS COMMIT COMMENT DIALOG WHEN ABOVE COMMIT BUTTON IS CLICKED */}

        <div className={classes.flexRow}>
          {/* {' '} */}
          {/* Lifecycle Environment versions start */}
          {/* <Typography variant="body2" color="textPrimary" style={{ padding: '0rem 0.25rem 0rem 1rem' }}>
            Dev:
          </Typography>
          <Typography variant="body2" color="textSecondary"> */}
          {/* Below text will be updated based on dev version */}
          {/* 2.0.1 */}
          {/* </Typography>
          <Typography variant="body2" color="textPrimary" style={{ padding: '0rem 0.25rem 0rem 1rem' }}>
            UACC:
          </Typography>
          <Typography variant="body2" color="textSecondary"> */}
          {/* Below text will be updated based on UACC version */}
          {/* 1.32.2
          </Typography>
          <Typography variant="body2" color="textPrimary" style={{ padding: '0rem 0.25rem 0rem 1rem' }}>
            Prod:
          </Typography>
          <Typography variant="body2" color="textSecondary"> */}
          {/* Below text will be updated based on Prod version */}
          {/* </Typography> */}
        </div>

        <div className={classes.flexRow} style={{ padding: '0rem 0.25rem 0rem 1rem' }}>
          {' '}
          {/* Warning message text start */}
          {/* Icon and colour will be updated based on message type */}
          {/* <ReportProblemOutlinedIcon color="error" />
          <Typography variant="body2" color="textSecondary" style={{ paddingLeft: '0.5rem' }}> */}
          {/* Below text will be updated based on validations later */}
          {/* Some settings are invalid, please correct to allow commiting
          </Typography> */}
        </div>
      </div>
      {/* Row Grid End */}
      {/* Cards Start */}
      <Box p='0.5rem 1rem 0.5rem 1rem'>
        <Grid container spacing={2}>
          {cardDetails.map(card => {
            return (
              <Grid item xs={12} sm={6} md={4} lg={3} key={card.id}>
                <Card className={classes.card} onClick={() => openDialogOnCardClick(card.id)}>
                  <CardContent className={classes.cardContent}>
                    {card.icon}

                    <Typography variant='h4'>
                      {' '}
                      {/* Bullet box */}
                      {/* Below visibility and colour will be updated based on card state version */}
                      <Box p='0rem 0.5rem 0rem 0.75rem' minWidth='0.75rem' lineHeight='1' color='text.disabled'>
                        &#8226;
                      </Box>
                    </Typography>

                    <Typography style={{ minHeight: '4rem' }} variant='h6' color='textPrimary'>
                      {' '}
                      {/* Card Title */}
                      {card.title}
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
            );
          })}
        </Grid>
      </Box>{' '}
      {/* </section> */}
      {/* Cards End */}
    </>
  );
};

export default SubjectAreaDetails;
