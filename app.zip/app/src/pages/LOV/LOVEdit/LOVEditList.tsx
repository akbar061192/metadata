import React, { useState, useEffect } from 'react';
import { createStyles, makeStyles, Theme } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import Grid from '@material-ui/core/Grid';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import IconButton from '@material-ui/core/IconButton';
import Typography from '@material-ui/core/Typography';
import CloseIcon from '@material-ui/icons/Close';
import Switch from '@material-ui/core/Switch';
import MenuItem from '@material-ui/core/MenuItem';
import Slide from '@material-ui/core/Slide';
import { TransitionProps } from '@material-ui/core/transitions';
import { TextField } from '@material-ui/core';
import HelpOutlineSharpIcon from '@material-ui/icons/HelpOutlineSharp';
import { IUpsertSingleLoVValue, IUpsertSingleLoV, IGetDbTags, IValidateSql } from '../../../global/services/apistypes';
import { globalApis } from '../../../global/services/apis';
import { TrendingUpTwoTone } from '@material-ui/icons';

interface LOVEditProps {
  openEditDialog: boolean;
  closeEditDialog: () => void;
  lovDetails: any;
  newLov: boolean;
  setRefreshList: any;
  refreshList: boolean;
  mdelId: number;
}

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    appBar: {
      position: 'relative',
    },
    title: {
      marginLeft: theme.spacing(2),
      flex: 1,
    },
    textFieldFlex: {
      display: 'flex',
      alignItems: 'center',
      marginBottom: '2.8rem',
    },
    gridContainer: {
      margin: '0 1.5rem',
    },
    fieldSize: {
      width: '20.5rem',
    },
    toggle: {
      display: 'flex',
      alignItems: 'center',
      width: '20.5rem',
      justifyContent: 'space-between',
    },
    icon: {
      marginLeft: '1rem',
      color: 'gray',
    },
    rightInfoContainer: {
      backgroundColor: ' rgba(0, 0, 0, 0.05)',
      height: '100%',
    },
    sideContent: {
      display: 'flex',
      flexDirection: 'column',
    },
    textField: {
      marginBottom: '1.5rem',
    },
    helperText: {
      color: 'black',
    },
    SQLtextarea: {
      resize: 'both',
    },
  })
);

const Transition = React.forwardRef(function Transition(
  props: TransitionProps & { children?: React.ReactElement },
  ref: React.Ref<unknown>
) {
  return <Slide direction='up' ref={ref} {...props} />;
});

// CONVERTING INCOMING DATE TO UTC WITH PROPER FORMATTING
const dateFormat = (date: string) => {
  const inputDate = new Date(date).toUTCString().slice(5, 22);
  let char = ',';
  let position = 11;
  let output = [inputDate.slice(0, position), char, inputDate.slice(position)].join('');
  return output;
};

// START OF THE COMPONENT
const LOVEdit: React.FC<LOVEditProps> = props => {
  const { openEditDialog, closeEditDialog, lovDetails, newLov, mdelId: model, setRefreshList, refreshList } = props;

  const classes = useStyles();

  // DE-STRUCTURING INCOMING PROPS
  const {
    lovCd,
    lovGrp,
    lovTyp,
    lovDesc,
    valueReqd,
    lovId,
    dbTag,
    sqlTxt,
    esRefreshSQL,
    esIndex,
    esRefreshIntervalHours,
    esLastRefreshDT,
    esLastRefresh_Status,
    lastUpdtDt,
    lastUpdtByUsrNm,
    isrtedByUsrNm,
    isrtedDt,
  } = lovDetails;

  // LOCAL STATE TO HANDLE FORM CHANGES FOR LOV TYPE
  const [lovList, setLovList] = useState({
    code: lovCd,
    type: lovTyp,
    group: lovGrp,
    desc: lovDesc,
    required: valueReqd === 'Y' ? true : false,
    sqlText: sqlTxt,
    DbTag: dbTag,
    esInterval: esRefreshIntervalHours,
    esSQL: esRefreshSQL,
    esIndx: esIndex,
  });

  // LOCAL STATE TO STORE ALL DB TAGS FOR A PARTICULAR LIFECYCLE
  const [dbTagsList, setDbTagsList] = useState<IGetDbTags[]>([]);

  // LOCAL STATE TO DISABLE UPDATE BUTTON DURING VALIDATE SQL FAILURE
  const [isValid, setIsValid] = useState(false);

  // INVOKING DB TAGS API
  useEffect(() => {
    if (lovList.type !== '' && lovList.type !== 'LIST') {
      globalApis
        .getDbTags()
        .then(response => {
          const data = response.data;
          let dbTags = [];
          if (window.location.hostname === 'caruiceapp02i.rxcorp.com') {
            dbTags = data.filter((db: IGetDbTags) => db.lifeCyc === 'intg');
            setDbTagsList(dbTags);
          } else {
            dbTags = data.filter((db: IGetDbTags) => db.lifeCyc === 'devl');
            setDbTagsList(dbTags);
          }
        })
        .catch(err => err);
    }
  }, [lovList.type]);

  // FUNCTION TO HANDLE INPUT CHANGES
  const handleLoVChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const name = event.target.name;
    setLovList(prevState => ({
      ...prevState,
      [name]: event.target.type === 'checkbox' ? event.target.checked : event.target.value,
    }));
  };

  // CREATING NEW LOV TYPE AND UPDATING EXISTING LOV TYPE
  const upsertLoVList = () => {
    const input: IUpsertSingleLoV = {
      lovCd: lovList.code,
      lovGrp: lovList.group,
      lovTyp: lovList.type,
      lovDesc: lovList.desc,
      valueRequired: lovList.required ? 'Y' : 'N',
      lovId: lovId ? lovId : 0,
      dbTag: lovList.DbTag ? lovList.DbTag : null,
      sqlTxt: lovList.sqlText ? lovList.sqlText : null,
      esIndex: lovList.esIndx ? lovList.esIndx : null,
      esRefreshSQL: lovList.esSQL ? lovList.esSQL : null,
      esRefreshIntervalHours: lovList.esInterval ? +lovList.esInterval : null,
      esLastRefreshDT: esLastRefreshDT ? esLastRefreshDT : null,
      esLastRefresh_Status: esLastRefresh_Status ? esLastRefresh_Status : null,
    };

    const upsert: IUpsertSingleLoVValue = {
      mdelId: model,
      insert: newLov ? [input] : null,
      update: !newLov ? [input] : null,
      delete: null,
    };

    globalApis
      .upsertLoV(upsert)
      .then(response => {
        closeEditDialog();
        setRefreshList(!refreshList);
      })
      .catch(error => error);
  };

  //CHECKING FOR REQUIRED FIELDS
  let isRequired = lovList.code && lovList.type && lovList.group && lovList.desc ? true : false;
  let isRequiredElastic =
    lovList.type === 'ELASTICSEARCH' ? (isRequired && !lovList.esIndx ? true : /^bde_/.test(lovList.esIndx)) : 'false';

  const onSqlValidate = (sqlText: string | null) => {
    const validateSql: IValidateSql = {
      modelId: model,
      sqlTxt: sqlText,
      dbTag: lovList.DbTag,
    };
    globalApis
      .validateSql(validateSql)
      .then((response: any) => {})
      .catch(error => {
        setIsValid(true);
      });
  };

  const btnDisableCheck = isValid || !isRequired || !isRequiredElastic;

  return (
    <Dialog fullScreen open={openEditDialog} onClose={closeEditDialog} TransitionComponent={Transition}>
      <AppBar className={classes.appBar} color='transparent'>
        <Toolbar>
          <IconButton edge='start' color='inherit' onClick={closeEditDialog} aria-label='close'>
            <CloseIcon />
          </IconButton>
          <Typography variant='h6' className={classes.title}>
            {lovTyp === 'LIST'
              ? 'Edit List'
              : lovTyp === 'ELASTICSEARCH'
              ? 'Edit Elastic'
              : lovTyp === 'SQL'
              ? 'Edit SQL'
              : ''}
          </Typography>
          <Button variant='contained' color='primary' disabled={btnDisableCheck} onClick={upsertLoVList}>
            {newLov ? 'CREATE' : 'UPDATE'}
          </Button>
        </Toolbar>
      </AppBar>
      <section style={{ padding: '1.5rem' }}>
        <Typography>List of Values’ Parameters and settings</Typography>
        <Typography style={{ marginTop: '0.8rem' }} variant='subtitle1' color='textSecondary'>
          The “LoV Type” setting will allow the appropraite settings whether the values are from Elastic Search, a SQL
          source or in a value list managed in this app. Required fields are marked with an asterisk “*”.
        </Typography>
      </section>

      <form className={classes.gridContainer}>
        <Grid container>
          <Grid item xs={12} sm={12} md={6}>
            <div className={classes.textFieldFlex}>
              <TextField
                className={classes.fieldSize}
                label='LoV Code*'
                type='text'
                variant='outlined'
                name='code'
                value={lovList.code}
                onChange={handleLoVChange}
              />
              <HelpOutlineSharpIcon className={classes.icon} />
            </div>
            <div className={classes.textFieldFlex}>
              <TextField
                select
                label='LoV Group*'
                className={classes.fieldSize}
                variant='outlined'
                name='group'
                value={lovList.group}
                onChange={handleLoVChange}
              >
                {['QUERY', 'FACT'].map(option => (
                  <MenuItem key={option} value={option}>
                    {option}
                  </MenuItem>
                ))}
              </TextField>
              <HelpOutlineSharpIcon className={classes.icon} />
            </div>
            <div className={classes.textFieldFlex}>
              <TextField
                select
                label='LoV Type*'
                name='type'
                onChange={handleLoVChange}
                className={classes.fieldSize}
                variant='outlined'
                value={lovList.type}
              >
                {['ELASTICSEARCH', 'SQL', 'LIST'].map(option => (
                  <MenuItem key={option} value={option}>
                    {option}
                  </MenuItem>
                ))}
              </TextField>
              <HelpOutlineSharpIcon className={classes.icon} />
            </div>
            <div className={classes.textFieldFlex}>
              <TextField
                className={classes.fieldSize}
                label='LoV Description*'
                type='text'
                variant='outlined'
                name='desc'
                value={lovList.desc}
                onChange={handleLoVChange}
              />
              <HelpOutlineSharpIcon className={classes.icon} />
            </div>
            <div className={classes.textFieldFlex}>
              <div className={classes.toggle}>
                <Typography color='textSecondary'>Require value</Typography>
                <Switch
                  name='required'
                  checked={lovList.required}
                  onChange={handleLoVChange}
                  color='primary'
                  inputProps={{ 'aria-label': 'primary checkbox' }}
                />
              </div>
              <HelpOutlineSharpIcon className={classes.icon} />
            </div>

            {/* NEW FIELDS FOR SQL LOV TYPE */}
            {lovList.type === 'SQL' ? (
              <div>
                <div className={classes.textFieldFlex}>
                  <TextField
                    name='DbTag'
                    select
                    label='Database Tag'
                    onChange={handleLoVChange}
                    className={classes.fieldSize}
                    variant='outlined'
                    value={lovList.DbTag}
                  >
                    {dbTagsList.map((option: any) => (
                      <MenuItem key={option.dbCrdlId} value={option.dbTag}>
                        {option.dbTag}
                      </MenuItem>
                    ))}
                  </TextField>
                  <HelpOutlineSharpIcon className={classes.icon} />
                </div>

                <Typography>List SQL</Typography>
                <div style={{ width: '90%', display: 'flex', justifyContent: 'space-between' }}>
                  <div></div>
                  <Button
                    color='primary'
                    onClick={() => onSqlValidate(lovList.sqlText)}
                    disableRipple
                    disabled={!lovList.sqlText ? true : false}
                  >
                    Validate
                  </Button>
                </div>
                <div className={classes.textFieldFlex}>
                  <TextField
                    style={{ width: '90%' }}
                    className={classes.fieldSize}
                    label='SQL'
                    placeholder='Enter SQL code here…'
                    type='text'
                    variant='outlined'
                    inputProps={{ className: classes.SQLtextarea }}
                    multiline
                    helperText='Click ‘Validate’ to check the syntax'
                    value={lovList.sqlText}
                    onChange={handleLoVChange}
                    name='sqlText'
                    error={isValid}
                  />
                  <HelpOutlineSharpIcon style={{ marginBottom: '1rem' }} className={classes.icon} />
                </div>
              </div>
            ) : null}

            {/* NEW FIELDS FOR ELASTIC SEARCH LOV TYPE */}
            {lovList.type === 'ELASTICSEARCH' ? (
              <div>
                <div className={classes.textFieldFlex}>
                  <TextField
                    name='DbTag'
                    select
                    label='Database Tag'
                    onChange={handleLoVChange}
                    className={classes.fieldSize}
                    variant='outlined'
                    value={lovList.DbTag}
                  >
                    {dbTagsList.map((option: any) => (
                      <MenuItem key={option.dbCrdlId} value={option.dbTag}>
                        {option.dbTag}
                      </MenuItem>
                    ))}
                  </TextField>
                  <HelpOutlineSharpIcon className={classes.icon} />
                </div>
                <Typography>List SQL</Typography>
                <div style={{ width: '90%', display: 'flex', justifyContent: 'space-between' }}>
                  <div></div>
                  <Button
                    color='primary'
                    disableRipple
                    disabled={!lovList.sqlText ? true : false}
                    onClick={() => onSqlValidate(lovList.sqlText)}
                  >
                    Validate
                  </Button>
                </div>
                <div className={classes.textFieldFlex}>
                  <TextField
                    style={{ width: '90%' }}
                    className={classes.fieldSize}
                    label='SQL'
                    placeholder='Enter SQL code here…'
                    type='text'
                    variant='outlined'
                    inputProps={{ className: classes.SQLtextarea }}
                    multiline
                    helperText='Click ‘Validate’ to check the syntax'
                    value={lovList.sqlText}
                    onChange={handleLoVChange}
                    name='sqlText'
                    error={isValid}
                  />
                  <HelpOutlineSharpIcon style={{ marginBottom: '1rem' }} className={classes.icon} />
                </div>
                <div className={classes.textFieldFlex}>
                  <TextField
                    name='esIndx'
                    className={classes.fieldSize}
                    label='Elastic Search Index'
                    type='text'
                    variant='outlined'
                    helperText='Index must start with “bde_”'
                    FormHelperTextProps={{
                      className: classes.helperText,
                    }}
                    value={lovList.esIndx}
                    onChange={handleLoVChange}
                    error={!/^bde_/.test(lovList.esIndx) && lovList.esIndx}
                  />
                  <HelpOutlineSharpIcon style={{ marginBottom: '1rem' }} className={classes.icon} />
                </div>
                <Typography>Elastic Search Refresh SQL</Typography>
                <div style={{ width: '90%', display: 'flex', justifyContent: 'space-between' }}>
                  <div></div>
                  <Button
                    color='primary'
                    disableRipple
                    disabled={!lovList.esSQL ? true : false}
                    onClick={() => onSqlValidate(lovList.esSQL)}
                  >
                    Validate
                  </Button>
                </div>
                <div className={classes.textFieldFlex}>
                  <TextField
                    style={{ width: '90%' }}
                    className={classes.fieldSize}
                    label='SQL'
                    placeholder='Enter SQL code here…'
                    type='text'
                    variant='outlined'
                    inputProps={{ className: classes.SQLtextarea }}
                    multiline
                    name='esSQL'
                    helperText='Click ‘Validate’ to check the syntax'
                    value={lovList.esSQL}
                    onChange={handleLoVChange}
                  />
                  <HelpOutlineSharpIcon style={{ marginBottom: '1rem' }} className={classes.icon} />
                </div>
                <div className={classes.textFieldFlex}>
                  <TextField
                    name='esInterval'
                    className={classes.fieldSize}
                    label='Elastic Search Refresh Interval (Hrs)'
                    type='number'
                    variant='outlined'
                    InputProps={{ inputProps: { min: 0 } }}
                    value={lovList.esInterval}
                    onChange={handleLoVChange}
                  />
                  <HelpOutlineSharpIcon className={classes.icon} />
                </div>
              </div>
            ) : null}
          </Grid>
          <Grid item xs={12} sm={12} md={6} className={classes.rightInfoContainer}>
            <aside style={{ display: 'flex', margin: '1rem' }}>
              <div style={{ marginRight: '3rem' }} className={classes.sideContent}>
                <Typography className={classes.textField}>Last update:</Typography>
                <Typography className={classes.textField}>Created:</Typography>
                {lovTyp === 'ELASTICSEARCH' && <Typography className={classes.textField}>Last refresh:</Typography>}
                <Typography className={classes.textField}>Model ID:</Typography>
                <Typography>LoV ID:</Typography>
              </div>
              <div className={classes.sideContent}>
                <Typography className={classes.textField} color='textSecondary'>
                  {lastUpdtDt ? dateFormat(lastUpdtDt) + ' , ' + lastUpdtByUsrNm : '-'}
                </Typography>
                <Typography className={classes.textField} color='textSecondary'>
                  {isrtedDt ? dateFormat(isrtedDt) + ' , ' + isrtedByUsrNm : '-'}
                </Typography>
                {lovTyp === 'ELASTICSEARCH' && (
                  <Typography className={classes.textField} color='textSecondary'>
                    {esLastRefresh_Status ? esLastRefresh_Status + ' , ' + dateFormat(esLastRefreshDT + '') : '-'}
                  </Typography>
                )}
                <Typography color='textSecondary' className={classes.textField}>
                  {model}
                </Typography>
                <Typography color='textSecondary'>{lovId ? lovId : '-'}</Typography>
              </div>
            </aside>
          </Grid>
        </Grid>
      </form>
    </Dialog>
  );
};

export default LOVEdit;
