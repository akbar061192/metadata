import React, { useState, useEffect, Dispatch, useCallback, useRef, useMemo } from 'react';
import { createStyles, makeStyles, Theme } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import IconButton from '@material-ui/core/IconButton';
import Typography from '@material-ui/core/Typography';
import CloseIcon from '@material-ui/icons/Close';
import Slide from '@material-ui/core/Slide';
import { TransitionProps } from '@material-ui/core/transitions';
import AddIcon from '@material-ui/icons/Add';
import HelpOutlineSharpIcon from '@material-ui/icons/HelpOutlineSharp';
import {
  DataGrid,
  GridColDef,
  GridRowData,
  GridValueFormatterParams,
  GridSelectionModel,
} from '@material-ui/data-grid';
import {
  IGetLoVs,
  IGetLoVDetails,
  IGetRolesByModelId,
  IUpsertLoVDetails,
  IUpsertLoV,
} from '../../../global/services/apistypes';
import { globalApis } from '../../../global/services/apis';
import { MenuItem, FormControl, Select } from '@material-ui/core';
import { useSelector, useDispatch } from 'react-redux';
import { AppState } from '../../../global/redux/reducers/rootReducer';
import { RoleModelActions, roleModelActionTypes } from '../../../global/redux/actions/roleModelActions';

interface LOVEditProps {
  openEditDialog: boolean;
  closeEditDialog: () => void;
  lov: IGetLoVs;
}

/**
 *
 * Component for listing the LOV values for a given LOV_ID and also for performing Edit actions.
 *
 * @param openEditDialog - boolean state to open the LOVEditValues dialog.
 * @param closeEditDialog - boolean state to close the LOVEditValues dialog.
 * @param lovValues - array of object containing list of values for a LOV_ID on which user clicked.
 *
 **/

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    appBar: {
      position: 'relative',
    },
    title: {
      marginLeft: theme.spacing(2),
      flex: 1,
    },
    btnFlex: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      margin: '0 1rem',
    },
    iconHover: {
      color: 'gray',
      cursor: 'pointer',
    },
    gridColHeader: {
      borderTop: 'none',
      '& .MuiDataGrid-columnHeaderTitle': {
        fontWeight: 550,
      },
      width: '100%',
      marginTop: '2rem',
      '& .inActive': {
        color: 'grey',
      },
    },
  })
);

// DIALOG TRANSISTION EFFECT
const Transition = React.forwardRef(function Transition(
  props: TransitionProps & { children?: React.ReactElement },
  ref: React.Ref<unknown>
) {
  return <Slide direction='up' ref={ref} {...props} />;
});

// CONVERTING INCOMING DATE TO UTC WITH PROPER FORMATTING
const dateFormat = (date: string) => {
  if (date) {
    const inputDate = new Date(date).toUTCString().slice(5, 22);
    let char = ',';
    let position = 11;
    let output = [inputDate.slice(0, position), char, inputDate.slice(position)].join('');
    return output;
  }
};

// COLUMNS DEFINITION FOR DATA GRID
const columns: GridColDef[] = [
  {
    field: 'lovValue',
    headerName: 'Value',
    type: 'string',
    flex: 1,
    editable: true,
    disableColumnMenu: true,
    align: 'left',
    headerAlign: 'left',
  },
  {
    field: 'lovDesc',
    headerName: 'Value Description',
    type: 'string',
    flex: 1,
    editable: true,
    disableColumnMenu: true,
    align: 'left',
    headerAlign: 'left',
  },
  {
    field: 'lovSeq',
    headerName: 'Sequence',
    type: 'number',
    flex: 1,
    editable: true,
    disableColumnMenu: true,
    align: 'left',
    headerAlign: 'left',
  },
  {
    field: 'roleRead',
    headerName: 'Read',
    type: 'string',
    flex: 1.5,
    editable: true,
    disableColumnMenu: true,
    align: 'left',
    headerAlign: 'left',
    renderCell: (params: GridValueFormatterParams) => {
      return <RoleRead data={params} />;
    },
  },
  {
    field: 'roleUpdate',
    headerName: 'Update',
    type: 'string',
    flex: 1.5,
    editable: true,
    disableColumnMenu: true,
    align: 'left',
    headerAlign: 'left',
    renderCell: (params: GridValueFormatterParams) => {
      return <RoleUpdate data={params} />;
    },
  },
  {
    field: 'ownerUser',
    headerName: 'Owner',
    type: 'string',
    flex: 1,
    editable: false,
    disableColumnMenu: true,
  },
  {
    field: 'tmplLikeList',
    headerName: 'Template Like',
    type: 'string',
    flex: 1,
    editable: true,
    disableColumnMenu: true,
  },
  {
    field: 'lastUpdateDate',
    headerName: 'Info',
    type: 'string',
    flex: 1,
    editable: false,
    renderCell: (params: GridValueFormatterParams) => {
      return <InfoColumn data={params} />;
    },
    disableColumnMenu: true,
  },
];

// FUNCTION TO GET ALL THE UPDATED ROWS FROM DATA GRID
const useApiRef = () => {
  const apiRef: any = useRef();
  const _columns = useMemo(
    () =>
      columns.concat({
        field: '__HIDDEN__',
        headerName: '',
        editable: false,
        width: 0,
        renderCell: (params: GridValueFormatterParams) => {
          apiRef.current = params.api;
          return null;
        },
      }),
    []
  );

  return { apiRef, columns: _columns };
};

// INITIAL STATE FOR GET LOV VALUE DETAILS API
const LoVValueDetails: IGetLoVDetails[] | [] = [];

// START OF THE COMPONENT
const LOVEditValues: React.FC<LOVEditProps> = props => {
  // DE-STRUCTURING useApiRef() FUNCTION
  const { apiRef, columns } = useApiRef();

  // DISPATCHING ROLE MODEL SUCCES ACTION
  const roleModelDispatch = useDispatch<Dispatch<RoleModelActions>>();

  // FETCHING DATA FROM REDUX STORE FOR COMMIT
  const { roleModelData } = useSelector((state: AppState) => state.roleModel);

  // DE-STRUCTURING THE INCOMING PROPS
  const { openEditDialog, closeEditDialog, lov } = props;

  const classes = useStyles();

  // LOCAL STATE TO STORE INCOMING LOV VALUES
  const [lovDetailValues, setLoVDetailValues] = useState<IGetLoVDetails[]>(LoVValueDetails);

  // LOCAL STATE TO STORE THE ROWS WHICH USER DELETES IN THE DATA GRID
  const [selectionModel, setSelectionModel] = useState<GridSelectionModel>([]);

  // TRANSFORMING INCOMING LOV VALUES TO HAVE 'ID' AS KEY SINCE DATA GRID EXPECTS.
  useEffect(() => {
    globalApis
      .getRolesByModelId(lov.mdelId)
      .then(response => {
        roleModelDispatch({ type: roleModelActionTypes.GET_ROLE_MODEL_SUCCESS, payload: response.data });
      })
      .catch(err => err);
    globalApis
      .getLoVDetailsByLoVId(lov.lovId)
      .then(response => {
        const updatedLovs: IGetLoVDetails[] = response.data.map((val: IGetLoVDetails) => ({
          ...val,
          id: +(Math.random() * 1000).toFixed(10),
          key: '',
        }));
        setLoVDetailValues(updatedLovs);
      })
      .catch(err => err);
  }, [lov.lovId, lov.mdelId, roleModelDispatch]);

  // FUNCTION CALL INVOKE API TO MAKE UPSERT NEW LOV VALUE AFTER CLICKING UPDATE LISTS BUTTON
  const upsertLovValues = () => {
    // NEW LOV VALUE
    const rowsDataMapInsert = apiRef?.current?.getRowModels();
    const selectedRowsInsert = Array.from(rowsDataMapInsert, ([key, value]) => value);
    const insertedRowsData = selectedRowsInsert.filter((item: IGetLoVDetails) => item.key === 'insert');

    const insertRows: IUpsertLoV[] = insertedRowsData.map((val: IGetLoVDetails) => {
      const roleRead: any =
        roleModelData && roleModelData.find((lov: IGetRolesByModelId) => lov.roleDesc === val.roleRead);

      const roleUpdate: any =
        roleModelData && roleModelData.find((lov: IGetRolesByModelId) => lov.roleDesc === val.roleUpdate);

      return {
        lovId: val.lovId,
        oldLovValue: val.lovValue,
        newLovValue: val.lovValue,
        lovDesc: val.lovDesc,
        lovSeq: val.lovSeq,
        roleRead: roleRead.roleId,
        roleUpdate: roleUpdate.roleId,
        ownerUser: val.ownerUser,
        tmplLikeList: val.tmplLikeList,
      };
    });

    // UPDATING EXISTING LOV VALUE
    const rowsDataMapUpdated = apiRef?.current?.getRowModels();
    const selectedRowsUpdate = Array.from(rowsDataMapUpdated, ([key, value]) => value);
    const updatedRowsData = selectedRowsUpdate.filter((item: IGetLoVDetails) => !lovDetailValues.includes(item));

    const updateRows: IUpsertLoV[] = updatedRowsData.map((val: IGetLoVDetails) => {
      const oldValue: any = lovDetailValues && lovDetailValues.find((lov: IGetLoVDetails) => lov.id === val.id);

      const roleRead: any =
        roleModelData && roleModelData.find((lov: IGetRolesByModelId) => lov.roleDesc === val.roleRead);
      const roleUpdate: any =
        roleModelData && roleModelData.find((lov: IGetRolesByModelId) => lov.roleDesc === val.roleUpdate);

      return {
        lovId: val.lovId,
        oldLovValue: oldValue.lovValue,
        newLovValue: val.lovValue,
        lovDesc: val.lovDesc,
        lovSeq: val.lovSeq,
        roleRead: roleRead.roleId,
        roleUpdate: roleUpdate.roleId,
        ownerUser: val.ownerUser,
        tmplLikeList: val.tmplLikeList,
      };
    });

    // FINAL SET OF ARRAY'S USER DID THE UPDATE
    const updatedRows = updateRows.filter(e => e.oldLovValue !== '');

    // DELETING EXISTING ROWS
    const rowsDataMapDeleted = apiRef?.current?.getSelectedRows();
    const selectedRowsDel = Array.from(rowsDataMapDeleted, ([key, value]) => value);

    const deleteRows: IUpsertLoV[] = selectedRowsDel.map((val: IGetLoVDetails) => {
      const oldValue: any = lovDetailValues && lovDetailValues.find((lov: IGetLoVDetails) => lov.id === val.id);
      const roleRead: any =
        roleModelData && roleModelData.find((lov: IGetRolesByModelId) => lov.roleCode === val.roleReadCd);
      const roleUpdate: any =
        roleModelData && roleModelData.find((lov: IGetRolesByModelId) => lov.roleCode === val.roleUpdateCd);

      return {
        lovId: val.lovId,
        oldLovValue: oldValue.lovValue,
        newLovValue: val.lovValue,
        lovDesc: val.lovDesc,
        lovSeq: val.lovSeq,
        roleRead: roleRead.roleId,
        roleUpdate: roleUpdate.roleId,
        ownerUser: val.ownerUser,
        tmplLikeList: val.tmplLikeList,
      };
    });

    const upsertLovDetails: IUpsertLoVDetails = {
      mdelId: lov.mdelId,
      insert: insertRows.length > 0 ? insertRows : null,
      update: updatedRows.length > 0 ? updatedRows : null,
      delete: deleteRows.length > 0 ? deleteRows : null,
    };

    // INVOKING UPSERT API
    globalApis
      .upsertLoVDetails(upsertLovDetails)
      .then(response => {
        closeEditDialog();
      })
      .catch(err => err);
  };

  // FUNCTION TO SET THE ROWS WHICH USER WANTS TO DELETE AFTER CLICKING DELETE BUTTON
  const deleteValues = () => {
    const rowsDataMap = apiRef?.current?.getSelectedRows();
    const rowsDataArray = Array.from(rowsDataMap, ([key, value]) => value);

    const deleteRows: IUpsertLoV[] = rowsDataArray.map((val: IGetLoVDetails) => {
      const oldValue: any = lovDetailValues && lovDetailValues.find((lov: IGetLoVDetails) => lov.id === val.id);
      const roleRead: any =
        roleModelData && roleModelData.find((lov: IGetRolesByModelId) => val.roleReadCd === lov.roleCode);
      const roleUpdate: any =
        roleModelData && roleModelData.find((lov: IGetRolesByModelId) => lov.roleCode === val.roleUpdateCd);

      return {
        lovId: val.lovId,
        oldLovValue: oldValue.lovValue,
        newLovValue: val.lovValue,
        lovDesc: val.lovDesc,
        lovSeq: val.lovSeq,
        roleRead: roleRead.roleId,
        roleUpdate: roleUpdate.roleId,
        ownerUser: val.ownerUser,
        tmplLikeList: val.tmplLikeList,
      };
    });

    const upsertLovDetails: IUpsertLoVDetails = {
      mdelId: lov.mdelId,
      insert: null,
      update: null,
      delete: deleteRows.length > 0 ? deleteRows : null,
    };

    globalApis
      .upsertLoVDetails(upsertLovDetails)
      .then(response => closeEditDialog())
      .catch(err => err);
  };

  // FUNCTION TO CHECK/UN-CHECK THE CHECKBOX
  const handleEditCheckBox = useCallback((newSelectionModel: any) => {
    setSelectionModel(newSelectionModel);
  }, []);

  // ADDING A NEW LOV VALUE ROW WHEN USER CLICK +LOV BUTTON.
  const addNewLovValue = () => {
    const rowsDataMapUpdated = apiRef?.current?.getRowModels();
    const selectedRowsUpdate = rowsDataMapUpdated && Array.from(rowsDataMapUpdated, ([key, value]) => value);
    const maxSequence = selectedRowsUpdate && Math.max(...selectedRowsUpdate.map((seq: any) => seq.lovSeq));
    const maxId = selectedRowsUpdate && Math.max(...selectedRowsUpdate.map((id: any) => id.id));

    selectedRowsUpdate
      ? setLoVDetailValues([
          ...lovDetailValues,
          ...selectedRowsUpdate,
          {
            lovId: lov.lovId,
            lovValue: '',
            lovDesc: '',
            lovSeq: maxSequence ? maxSequence + 1 : 1,
            lovPrev: '',
            lovEditFlg: 'true',
            insertByUser: '',
            updateByUser: '',
            insertDate: '',
            lastUpdateDate: '',
            ownerUser: '',
            tmplLikeList: '',
            roleRead: 'General User Role',
            roleReadCd: 'UserGeneral',
            roleUpdate: 'General User Role',
            roleUpdateCd: 'UserGeneral',
            id: maxId ? maxId + 100 : 100,
            key: 'insert',
          },
        ])
      : setLoVDetailValues([
          ...lovDetailValues,
          {
            lovId: lov.lovId,
            lovValue: '',
            lovDesc: '',
            lovSeq: maxSequence ? maxSequence + 1 : 1,
            lovPrev: '',
            lovEditFlg: 'true',
            insertByUser: '',
            updateByUser: '',
            insertDate: '',
            lastUpdateDate: '',
            ownerUser: '',
            tmplLikeList: '',
            roleRead: 'General User Role',
            roleReadCd: 'UserGeneral',
            roleUpdate: 'General User Role',
            roleUpdateCd: 'UserGeneral',
            id: maxId ? maxId + 100 : 100,
            key: 'insert',
          },
        ]);
  };
  const updateBtnCheck = lovDetailValues.length > 0 ? true : false;

  return (
    <>
      <Dialog fullScreen open={openEditDialog} onClose={closeEditDialog} TransitionComponent={Transition}>
        <AppBar className={classes.appBar} color='transparent'>
          <Toolbar>
            <IconButton edge='start' color='inherit' onClick={closeEditDialog} aria-label='close'>
              <CloseIcon />
            </IconButton>
            <Typography variant='h6' className={classes.title}>
              Edit Values
            </Typography>
            <Button variant='contained' disabled={!updateBtnCheck} color='primary' onClick={upsertLovValues}>
              UPDATE VALUES
            </Button>
          </Toolbar>
        </AppBar>

        <section style={{ padding: '1.5rem' }}>
          <Typography>Edit values and their parameters</Typography>
          <Typography style={{ marginTop: '0.8rem', fontSize: '0.9rem' }} variant='subtitle1' color='textSecondary'>
            Each entry for the menu list requires the displayed menu text, its associated value, the optional sequence
            number indicating where it appears in the menu, who can see the menu item, who can change the menu item and
            who has overall rights to it. Details of when the value was created and when it was last updated can be
            found by hovering over the info icon on on the far right of the table.
          </Typography>
        </section>

        <section className={classes.btnFlex}>
          <Button variant='contained' color='primary' startIcon={<AddIcon />} onClick={addNewLovValue}>
            VALUE
          </Button>
          <Button
            variant='outlined'
            color='primary'
            onClick={deleteValues}
            disabled={selectionModel.length === 0 && true}
          >
            DELETE
          </Button>
        </section>

        {/* LISTING ALL THE LOV VALUES FOR A GIVEN LOV ID */}
        <DataGrid
          autoHeight
          className={classes.gridColHeader}
          rows={lovDetailValues as GridRowData[]}
          columns={columns}
          checkboxSelection
          disableSelectionOnClick
          onSelectionModelChange={handleEditCheckBox}
          selectionModel={selectionModel}
          hideFooter
          hideFooterPagination
          hideFooterRowCount
          hideFooterSelectedRowCount
          isCellEditable={params => (params.row.lovEditFlg === 'true' ? true : false)}
          isRowSelectable={params => (params.row.lovEditFlg === 'true' ? true : false)}
          getRowClassName={params => {
            return params.row.lovEditFlg === 'false' ? 'inActive' : '';
          }}
        />
      </Dialog>
    </>
  );
};

/*
 * COMPONENT TO OVERRIDE THE LAST COLUMN OF THE DATA-GRID TO DISPLAY ICON WITH MOUSE HOVER EFFECT
 * THIS COMPONENT WILL BE RENDERED UNDER THE 'LAST_UPDT_DT' FIELD OF COLUMNS ARRAY.
 */
interface InfoColumnProps {
  data: GridValueFormatterParams;
}

export const InfoColumn: React.FC<InfoColumnProps> = props => {
  const { data } = props;
  const classes = useStyles();
  const hover = `Last Update: ${dateFormat(data.row.lastUpdateDate)}, ${data.row.updateByUser} 
Inserted:  ${dateFormat(data.row.insertDate)}, ${data.row.insertByUser}`;

  return <HelpOutlineSharpIcon titleAccess={hover} className={classes.iconHover} />;
};

// COMPONENT TO RENDER ROLE READ COLUMN UNDER DATA GRID
interface RoleReadProps {
  data: GridValueFormatterParams;
}

export const RoleRead: React.FC<RoleReadProps> = props => {
  const { data } = props;

  // FETCHING DATA FROM REDUX STORE FOR COMMIT
  const { roleModelData } = useSelector((state: AppState) => state.roleModel);
  const { id, api, field } = data;

  const handleChange = (event: any) => {
    api.setEditCellValue({ id, field, value: event.target.value }, event);
    if (event.nativeEvent.clientX !== 0 && event.nativeEvent.clientY !== 0) {
      api.commitCellChange({ id, field });
      api.setCellMode(id, field, 'view');
    }
  };
  return (
    <FormControl style={{ width: '100%', justifyContent: 'center' }}>
      {data.row.lovEditFlg === 'true' ? (
        <Select value={data.row.roleRead} onChange={handleChange} disableUnderline>
          {roleModelData &&
            roleModelData.map((lov: IGetRolesByModelId) => {
              return (
                <MenuItem key={lov.roleId} value={lov.roleDesc}>
                  <div style={{ minWidth: 0, paddingRight: '1rem' }}>
                    <Typography
                      color='textPrimary'
                      style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}
                      variant='body1'
                    >
                      {lov.roleDesc}
                    </Typography>
                  </div>
                </MenuItem>
              );
            })}
        </Select>
      ) : (
        <Select disabled value={data.row.roleRead} disableUnderline>
          <MenuItem value={data.row.roleRead}>
            <div style={{ minWidth: 0, paddingRight: '1rem' }}>
              <Typography
                color='textPrimary'
                style={{ whiteSpace: 'nowrap', color: 'grey', overflow: 'hidden', textOverflow: 'ellipsis' }}
                variant='body1'
              >
                {data.row.roleRead}
              </Typography>
            </div>
          </MenuItem>
        </Select>
      )}
    </FormControl>
  );
};

interface RoleUpdateProps {
  data: GridValueFormatterParams;
}

// COMPONENT TO RENDER ROLE UPDATE COLUMN UNDER DATA GRID

export const RoleUpdate: React.FC<RoleUpdateProps> = props => {
  const { data } = props;

  // FETCHING DATA FROM REDUX STORE FOR COMMIT
  const { roleModelData } = useSelector((state: AppState) => state.roleModel);
  const { id, api, field } = data;

  const handleChange = (event: any) => {
    api.setEditCellValue({ id, field, value: event.target.value }, event);

    if (event.nativeEvent.clientX !== 0 && event.nativeEvent.clientY !== 0) {
      api.commitCellChange({ id, field });
      api.setCellMode(id, field, 'view');
    }
  };
  return (
    <FormControl style={{ width: '100%', justifyContent: 'center' }}>
      {data.row.lovEditFlg === 'true' ? (
        <Select value={data.row.roleUpdate} onChange={handleChange} disableUnderline>
          {roleModelData &&
            roleModelData.map((lov: IGetRolesByModelId) => {
              return (
                <MenuItem key={lov.roleId} value={lov.roleDesc}>
                  <div style={{ minWidth: 0, paddingRight: '1rem' }}>
                    <Typography
                      color='textPrimary'
                      style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}
                      variant='body1'
                    >
                      {lov.roleDesc}
                    </Typography>
                  </div>
                </MenuItem>
              );
            })}
        </Select>
      ) : (
        <Select disabled value={data.row.roleUpdate} disableUnderline>
          <MenuItem value={data.row.roleUpdate}>
            <div style={{ minWidth: 0, paddingRight: '1rem' }}>
              <Typography
                color='textPrimary'
                style={{ whiteSpace: 'nowrap', color: 'grey', overflow: 'hidden', textOverflow: 'ellipsis' }}
                variant='body1'
              >
                {data.row.roleUpdate}
              </Typography>
            </div>
          </MenuItem>
        </Select>
      )}
    </FormControl>
  );
};

export default LOVEditValues;
