import React, { useState, useEffect } from 'react';
import { createStyles, makeStyles, Theme } from '@material-ui/core/styles';
import { TransitionProps } from '@material-ui/core/transitions';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import AddIcon from '@material-ui/icons/Add';
import SearchIcon from '@material-ui/icons/Search';
import { FormControl, InputAdornment, OutlinedInput, Slide, Dialog, AppBar, Button } from '@material-ui/core';
import { Typography, Avatar, Toolbar, IconButton } from '@material-ui/core';
import LOVMenuItem from './LOVMenuItem';
import { DataGrid, GridColDef, GridRowData, GridValueFormatterParams } from '@material-ui/data-grid';
import { globalApis } from '../../../global/services/apis';
import { IGetLoVs } from '../../../global/services/apistypes';
import LOVEditList from '../LOVEdit/LOVEditList';
import { LoVDetails } from './LOVMenuItem';

interface LOVListProps {
  openListDialog: boolean;
  closeListDialog: () => void;
  modelId: number;
}

// LIST OF LOV's INTIAL STATE AND WILL BE USED WHILE CALLING API.
const LoVList: IGetLoVs[] | [] = [];

/**
 *
 * Component for listing the LOV values for a given MODEL ID and also for performing Edit actions.
 *
 * @param openEditDialog - boolean state to open the LOVList dialog.
 * @param closeEditDialog - boolean state to close the LOVList dialog.
 * @param modelId - model id of currently editing subject area.
 *
 **/

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    appBar: {
      position: 'relative',
    },
    title: {
      marginLeft: theme.spacing(2),
      flex: 1,
    },
    addSection: {
      padding: '1rem',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '1rem',
    },
    gridContainer: {
      alignItems: 'center',
    },
    gridColHeader: {
      borderTop: 'none',
      cursor: 'pointer',
      '& .MuiDataGrid-columnHeaderTitle': {
        color: 'gray',
      },
      '& .MuiDataGrid-columnSeparator': {
        color: 'white',
      },
      '& .MuiDataGrid-columnHeaderTitleContainer': {
        padding: 0,
      },
    },
  })
);

// CONVERTING INCOMING DATE TO UTC WITH PROPER FORMATTING
const dateFormat = (date: string) => {
  const inputDate = new Date(date).toUTCString().slice(5, 22);
  let char = ',';
  let position = 11;
  let output = [inputDate.slice(0, position), char, inputDate.slice(position)].join('');
  return output;
};

// DIALOG TRANSISTION EFFECT
const Transition = React.forwardRef(function Transition(
  props: TransitionProps & { children?: React.ReactElement },
  ref: React.Ref<unknown>
) {
  return <Slide direction='up' ref={ref} {...props} />;
});

// START OF COMPONENT
const LOVList: React.FC<LOVListProps> = props => {
  // DE-STRUCTURING THE INCOMING PROPS
  const { openListDialog, closeListDialog, modelId } = props;
  const classes = useStyles();

  // LOCAL STATE TO STORE USER INPUT ENTERED UNDER SEARCH BOX
  const [searchInput, setSearchInput] = useState<string>('');

  // LOCAL STATE TO STORE LOV's FOR A GIVEN MODEL ID
  const [lovs, setLovs] = useState<IGetLoVs[]>(LoVList);

  // LOCAL STATE TO STORE SEARCHED RESULTS WHEN USER ENTER'S VALUES IN SEARCH BOX
  const [searchResults, setSearchResults] = useState<IGetLoVs[]>(LoVList);

  const [openEditList, setOpenEditList] = useState(false);

  // STATE FOR STORING TRUE/FALSE VALUE WHEN +DESTINATION BUTTON IS CLICKED
  const [newLoV, setNewLoV] = useState(false);

  // STATE FOR REFRESHING THE LOV LIST AFTER UPSERT
  const [refreshList, setRefreshList] = useState(false);

  //STATE FOR CLICKING A SPECIFIC LIST ROW AND OPENING EDIT PAGE
  const [onCellClick, setOnCellClick] = useState(false);
  //STATE FOR SAVING LOV OBJECT ON WHICH USER HAS CLICKED
  const [onCellClickLoV, setOnCellClickLoV] = useState<IGetLoVs | {}>({});

  // FUNCTION TO CLOSE EDIT LIST DIALOG
  const closeEditListDialog = () => {
    setOpenEditList(false);
    setNewLoV(false);
    setOnCellClickLoV(LoVDetails);
  };

  // TRANSFORMING INCOMING LOV VALUES TO HAVE 'ID' AS KEY SINCE DATA GRID EXPECTS.
  useEffect(() => {
    globalApis
      .getLoVsByModelId(modelId)
      .then(response => {
        const updatedLovs: IGetLoVs[] = response.data.map((lov: IGetLoVs) => ({
          ...lov,
          lastUpdtDt: dateFormat(lov.lastUpdtDt),
          id: lov.lovId,
        }));
        setLovs(updatedLovs);
      })
      .catch(err => err);
  }, [modelId, refreshList]);

  // LOGIC TO FILTER THE LIST OF LOV's WITH USER ENTERED DATA IN SEARCH BOX.
  useEffect(() => {
    if (searchInput !== '') {
      const filteredOutput = lovs.filter((lov: IGetLoVs) => {
        return Object.values(lov).join(' ').toLowerCase().includes(searchInput.toLowerCase());
      });
      setSearchResults(filteredOutput);
    } else {
      setSearchResults(lovs);
    }
  }, [searchInput, lovs]);

  // COLUMNS DEFINITION FOR DATA GRID
  const columns: GridColDef[] = [
    {
      field: 'lovTyp',
      headerName: 'List Type',
      type: 'string',
      width: 120,
      editable: false,
      disableColumnMenu: true,
      align: 'center',
      headerAlign: 'center',
      sortable: true,
      renderCell: (params: GridValueFormatterParams) => {
        return <ListType data={params} />;
      },
    },
    {
      field: 'lovId',
      headerName: 'ID',
      type: 'number',
      flex: 0,
      editable: false,
      disableColumnMenu: true,
      align: 'center',
      headerAlign: 'center',
      valueFormatter: (params: GridValueFormatterParams) => {
        const valueFormatted = Number(params.value).toString().replace(',', '');
        return valueFormatted;
      },
    },
    {
      field: 'lovDesc',
      headerName: 'List Name and Group',
      type: 'string',
      flex: 1,
      editable: false,
      disableColumnMenu: true,
      align: 'left',
      headerAlign: 'left',
      renderCell: (params: GridValueFormatterParams) => {
        return <ListNameGroup data={params} />;
      },
    },
    {
      field: 'lastUpdtDt',
      headerName: 'Last Edit',
      type: 'string',
      flex: 0.2,
      minWidth: 200,
      editable: false,
      disableColumnMenu: true,
      align: 'left',
      headerAlign: 'left',
      renderCell: (params: GridValueFormatterParams) => {
        return <LastEdit data={params} />;
      },
    },
    {
      field: '',
      headerName: '',
      type: 'string',
      editable: false,
      disableColumnMenu: true,
      width: 48,
      align: 'center',
      headerAlign: 'center',
      sortable: false,
      renderCell: (params: GridValueFormatterParams) => {
        return <MenuCol data={params} setRefreshList={setRefreshList} refreshList={refreshList} />;
      },
    },
  ];

  // CHECK FOR DISPLAYING ROW DATA IN DATA GRID.
  const rowData: GridRowData[] = searchInput.length < 1 ? lovs : searchResults;

  return (
    <>
      {openEditList && newLoV ? (
        <LOVEditList
          openEditDialog={openEditList}
          closeEditDialog={closeEditListDialog}
          lovDetails={LoVDetails}
          newLov={newLoV}
          setRefreshList={setRefreshList}
          refreshList={refreshList}
          mdelId={modelId}
        />
      ) : null}

      {openEditList && onCellClick ? (
        <LOVEditList
          openEditDialog={openEditList}
          closeEditDialog={closeEditListDialog}
          lovDetails={onCellClickLoV}
          newLov={newLoV}
          setRefreshList={setRefreshList}
          refreshList={refreshList}
          mdelId={modelId}
        />
      ) : null}

      <Dialog fullScreen open={openListDialog} onClose={closeListDialog} TransitionComponent={Transition}>
        <AppBar className={classes.appBar} color='transparent'>
          <Toolbar>
            <IconButton edge='start' color='inherit' onClick={closeListDialog} aria-label='close'>
              <ArrowBackIcon />
            </IconButton>
            <Typography variant='h6' className={classes.title}>
              Lists of Values
            </Typography>
          </Toolbar>
        </AppBar>

        <section className={classes.addSection}>
          <Button
            onClick={() => {
              setOpenEditList(true);
              setNewLoV(true);
            }}
            style={{ marginLeft: '1rem' }}
            variant='contained'
            color='primary'
            startIcon={<AddIcon />}
          >
            LOV
          </Button>
          <FormControl variant='outlined' style={{ width: '21rem', marginRight: '1rem' }}>
            <OutlinedInput
              id='outlined-adornment-weight'
              placeholder='Search Lists'
              endAdornment={<InputAdornment position='end'>{<SearchIcon />}</InputAdornment>}
              aria-describedby='outlined-weight-helper-text'
              labelWidth={0}
              value={searchInput}
              onChange={event => setSearchInput(event.target.value)}
            />
          </FormControl>
        </section>

        {/* LISTING ALL THE LOV's FOR A GIVEN MODEL ID */}
        <DataGrid
          autoHeight
          className={classes.gridColHeader}
          rows={rowData}
          pageSize={Array.from(new Set(rowData.map(data => data.lovId))).length}
          columns={columns}
          density='comfortable'
          hideFooter
          hideFooterPagination
          hideFooterRowCount
          hideFooterSelectedRowCount
          disableSelectionOnClick
          onCellClick={(params: GridValueFormatterParams) => {
            if (params.field) {
              setOnCellClick(true);
              setOpenEditList(true);
              setOnCellClickLoV(params.row);
            }
          }}
        />
      </Dialog>
    </>
  );
};

/*
 * COMPONENT TO OVERRIDE THE COLUMN OF THE DATA-GRID TO DISPLAY LOV DESC AND LOV CODE.
 */

interface ListTypeProps {
  data: any;
}

export const ListType: React.FC<ListTypeProps> = props => {
  const { data } = props;
  const color =
    data.row.lovTyp === 'SQL'
      ? '#0768fd'
      : data.row.lovTyp === 'ELASTICSEARCH'
      ? '#4caf50'
      : data.row.lovTyp === 'LIST'
      ? '#9e54b0'
      : 'none';

  return (
    <Avatar style={{ background: color }}>
      <Typography variant='body2'>{data.row.lovTyp === 'ELASTICSEARCH' ? 'ES' : data.row.lovTyp}</Typography>
    </Avatar>
  );
};

/*
 * COMPONENT TO OVERRIDE THE COLUMN OF THE DATA-GRID TO DISPLAY LIST NAME AND LOV GROUP.
 */
interface ListNameGroupProps {
  data: any;
}

export const ListNameGroup: React.FC<ListNameGroupProps> = props => {
  const { data } = props;

  return (
    <div style={{ minWidth: 0 }}>
      <Typography variant='body1' noWrap={true}>
        {data.row.lovDesc}
      </Typography>
      <Typography noWrap={true} color='textSecondary'>
        {data.row.lovCd}
      </Typography>
    </div>
  );
};

/*
 * COMPONENT TO OVERRIDE THE COLUMN OF THE DATA-GRID TO DISPLAY LAST EDIT DATE AND LAST EDIT BY USER.
 */
interface LastEditProps {
  data: any;
}

export const LastEdit: React.FC<LastEditProps> = props => {
  const { data } = props;

  return (
    <div style={{ minWidth: 0 }}>
      <Typography variant='body1' noWrap={true}>
        {data.row.lastUpdtByUsrNm}
      </Typography>
      <Typography variant='body2' color='textSecondary' noWrap={true}>
        {data.row.lastUpdtDt}
      </Typography>
    </div>
  );
};

/*
 * COMPONENT TO OVERRIDE THE COLUMN OF THE DATA-GRID TO DISPLAY MENU WITH LIST OF OPTIONS.
 */
interface MenuProps {
  data: any;
  setRefreshList: any;
  refreshList: boolean;
}

export const MenuCol: React.FC<MenuProps> = props => {
  const { data, setRefreshList, refreshList } = props;
  return <LOVMenuItem lov={data.row} setRefreshList={setRefreshList} refreshList={refreshList} />;
};

export default LOVList;
