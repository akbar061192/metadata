import React, { useState } from 'react';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import { Typography, IconButton, Menu, MenuItem } from '@material-ui/core';
import LOVEditValues from '../LOVEdit/LOVEditValues';
import LOVEditList from '../LOVEdit/LOVEditList';
import { IGetLoVs, IUpsertSingleLoVValue } from '../../../global/services/apistypes';
import { globalApis } from '../../../global/services/apis';

interface LOVMenuItemProps {
  lov: IGetLoVs;
  setRefreshList: any;
  refreshList: boolean;
}

/**
 *
 * Component for listing the LOV values for a given MODEL ID and also for performing Edit actions.
 *
 * @param lov - lov details object of user clicked row under list data grid
 *
 **/

// HEIGHT OF MENU DISPLAY
const ITEM_HEIGHT = 48;

export const LoVDetails: IGetLoVs = {
  mdelId: 0,
  lovCd: '',
  lovGrp: '',
  lovTyp: '',
  lovDesc: '',
  valueReqd: '',
  isrtedDt: '',
  isrtedByUsrNm: '',
  lastUpdtDt: '',
  lastUpdtByUsrNm: '',
  lovId: 0,
  dbTag: '',
  sqlTxt: '',
  esIndex: '',
  esRefreshSQL: '',
  esRefreshIntervalHours: 0,
  esLastRefreshDT: '',
  esLastRefresh_Status: '',
  id: 0,
};

// START OF COMPONENT
const LOVMenuItem: React.FC<LOVMenuItemProps> = props => {
  // DE-STRUCTURING THE INCOMING PROPS
  const { lov, setRefreshList, refreshList } = props;

  // LOCAL STATE TO HANDLE MENU FOR OPENING AND CLOSING
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);

  // FUNCTION TO OPEN MENU WHEN USER CLICKS MENU 3 DOTS ICON BUTTON.
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  // 2 LOCAL STATES TO STORE BOOLEAN VALUE FOR CHECKING WHICH DIALOG(EDIT LIST/EDIT VALUE) TO OPEN/CLOSE.
  const [openEditList, setOpenEditList] = useState(false);
  const [openEditValues, setOpenEditValues] = useState(false);

  // LOCAL STATE TO STORE LOV DETAILS OBJECT WHICH WILL BE THEN PASSED TO LOV EDIT LIST DIALOG.
  const [lovDetails, setLovDetails] = useState<IGetLoVs>(LoVDetails);

  /* FUNCTION WILL BE CALLED WHEN USER CLICKS ON EDIT LIST OPTION FROM THE MENU WHERE THE LOV DETAILS OBJECT IS THEN PASSED TO EDIT LIST DIALOG COMPONENT.
  TYPE==='LIST'*/
  const openEditListDialog = (lov: IGetLoVs) => {
    setOpenEditList(true);
    setLovDetails(lov);
    setAnchorEl(null);
  };

  /* FUNCTION WILL BE CALLED WHEN USER CLICKS ON EDIT VALUES OPTION FROM THE MENU WHERE THE API CALL WILL HAPPEN TO GET THE LIST OF LOV VALUES FOR USER CLICKED LOV_ID */
  const openEditValuesDialog = () => {
    setOpenEditValues(true);
    setAnchorEl(null);
  };

  // FUNCTION TO CLOSE EDIT LIST DIALOG
  const closeEditListDialog = () => {
    setOpenEditList(false);
    setAnchorEl(null);
  };

  // FUNCTION TO CLOSE EDIT VALUES DIALOG
  const closeEditValuesDialog = () => {
    setOpenEditValues(false);
    setAnchorEl(null);
  };

  const openEditPage = (lov: IGetLoVs) => {
    openEditListDialog(lov);
  };

  // FUNCTION TO DELETE A LOV TYPE
  const deleteLoVType = (inputLoV: IGetLoVs) => {
    const deleteLoV = {
      lovCd: inputLoV.lovCd,
      lovGrp: inputLoV.lovGrp,
      lovTyp: inputLoV.lovTyp,
      lovDesc: inputLoV.lovDesc,
      valueRequired: inputLoV.valueReqd,
      lovId: inputLoV.lovId,
      dbTag: inputLoV.dbTag,
      sqlTxt: inputLoV.sqlTxt,
      esIndex: inputLoV.esIndex,
      esRefreshSQL: inputLoV.esRefreshSQL,
      esRefreshIntervalHours: inputLoV.esRefreshIntervalHours,
      esLastRefreshDT: inputLoV.esLastRefreshDT,
      esLastRefresh_Status: inputLoV.esLastRefresh_Status,
    };
    const upsertInput: IUpsertSingleLoVValue = {
      mdelId: lov.mdelId,
      insert: null,
      update: null,
      delete: [deleteLoV],
    };

    globalApis
      .upsertLoV(upsertInput)
      .then(response => {
        setAnchorEl(null);
        setRefreshList(!refreshList);
      })
      .catch(error => error);
  };

  return (
    <>
      {openEditList ? (
        <LOVEditList
          openEditDialog={openEditList}
          closeEditDialog={closeEditListDialog}
          lovDetails={lovDetails}
          newLov={false}
          setRefreshList={setRefreshList}
          refreshList={refreshList}
          mdelId={lovDetails.mdelId}
        />
      ) : null}
      {openEditValues ? <LOVEditValues openEditDialog={openEditValues} closeEditDialog={closeEditValuesDialog} lov={lov} /> : null}

      <section>
        <IconButton aria-label='more' aria-controls='long-menu' aria-haspopup='true' onClick={handleClick}>
          <MoreVertIcon />
        </IconButton>
        <Menu
          id='long-menu'
          anchorEl={anchorEl}
          keepMounted
          open={open}
          onClose={() => setAnchorEl(null)}
          PaperProps={{
            style: {
              maxHeight: ITEM_HEIGHT * 3.5,
              width: '10.5rem',
            },
          }}
          elevation={1}
          getContentAnchorEl={null}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
          transformOrigin={{ vertical: 'top', horizontal: 'right' }}
        >
          <MenuItem onClick={() => openEditPage(lov)}>
            <Typography>Edit list settings…</Typography>
          </MenuItem>
          <MenuItem onClick={() => openEditValuesDialog()}>
            <Typography>Edit list values…</Typography>
          </MenuItem>
          <MenuItem divider />
          <MenuItem onClick={() => deleteLoVType(lov)}>
            <Typography>Delete…</Typography>
          </MenuItem>
        </Menu>
      </section>
    </>
  );
};

export default LOVMenuItem;
