import React, { useState } from 'react';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import { Typography, IconButton, Menu, MenuItem } from '@material-ui/core';
import { IGetTargetsByModelId, IUpsertTarget, IUpsertTargetDetails } from '../../../global/services/apistypes';
import OutputDestEdit from '../OutputDestEdit/OutputDestEdit';
import { globalApis } from '../../../global/services/apis';

interface OutputDestMenuItemProps {
  target: IGetTargetsByModelId;
  setRefreshList: any;
  refreshList: boolean;
}

/**
 *
 * Component for listing the Edit actions for each Destination
 *
 * @param target - target details object of user clicked row under list data grid
 *
 **/

// HEIGHT OF MENU DISPLAY
const ITEM_HEIGHT = 48;

export const TargetDetails: IGetTargetsByModelId = {
  mdelId: 0,
  targetId: 0,
  destType: '',
  targetType: '',
  targetHost: '',
  port: 0,
  userName: '',
  password: '',
  defaultPath: '',
  targetSubType: '',
  isrtedDt: '',
  isrtedByUsrName: '',
  lastupdtDt: '',
  lastUpdtbyUsrName: '',
  jdbcUrl: '',
  jdbcDriver: '',
  linkPath: '',
  keyLocation: '',
  keyPassPhrase: '',
  authMethod: '',
  roleReadCd: '',
  roleReadDesc: '',
  roleReadId: 0,
  roleUpdateDesc: '',
  roleUpdateId: 0,
  roleUpdateCd: '',
  ownerName: '',
};

// START OF COMPONENT
const OutputDestMenuItem: React.FC<OutputDestMenuItemProps> = props => {
  // DE-STRUCTURING THE INCOMING PROPS
  const { target, setRefreshList, refreshList } = props;

  // LOCAL STATE TO HANDLE MENU FOR OPENING AND CLOSING
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);

  // FUNCTION TO OPEN MENU WHEN USER CLICKS MENU 3 DOTS ICON BUTTON.
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  // LOCAL STATE TO STORE BOOLEAN VALUE FOR OPENING EDIT DIALOG
  const [openEditDest, setOpenEditDest] = useState(false);

  // LOCAL STATE TO STORE LOV DETAILS OBJECT WHICH WILL BE THEN PASSED TO LOV EDIT LIST DIALOG.
  const [targetDetails, setTargetDetails] = useState<IGetTargetsByModelId>(TargetDetails);

  // FUNCTION WILL BE CALLED WHEN USER CLICKS ON EDIT SETTINGS OPTION
  const openEditDestDialog = (target: IGetTargetsByModelId) => {
    setOpenEditDest(true);
    setTargetDetails(target);
    setAnchorEl(null);
  };

  // FUNCTION TO CLOSE EDIT LIST DIALOG
  const closeEditDestDialog = () => {
    setOpenEditDest(false);
    setAnchorEl(null);
  };

  // FUNCTION TO DELETE A TARGET DESTINATION
  const deleteTargetDest = (inputTarget: IUpsertTarget) => {
    const upsertInput: IUpsertTargetDetails = {
      mdelId: target.mdelId,
      insert: null,
      update: null,
      delete: [inputTarget],
    };

    globalApis
      .upsertTargetDetails(upsertInput)
      .then(response => {
        setAnchorEl(null);
        setRefreshList(!refreshList);
      })
      .catch(error => error);
  };

  return (
    <>
      {openEditDest ? (
        <OutputDestEdit
          mdelId={targetDetails.mdelId}
          openEditDialog={openEditDest}
          closeEditDialog={closeEditDestDialog}
          targetDetails={targetDetails}
          newDest={false}
          setRefreshList={setRefreshList}
          refreshList={refreshList}
        />
      ) : null}

      <section>
        <IconButton aria-label='more' aria-controls='long-menu' aria-haspopup='true' onClick={handleClick}>
          <MoreVertIcon />
        </IconButton>
        <Menu
          id='long-menu'
          anchorEl={anchorEl}
          keepMounted
          open={open}
          onClose={() => setAnchorEl(null)}
          PaperProps={{
            style: {
              maxHeight: ITEM_HEIGHT * 3.5,
              width: '10.5rem',
            },
          }}
          elevation={1}
          getContentAnchorEl={null}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
          transformOrigin={{ vertical: 'top', horizontal: 'right' }}
        >
          <MenuItem onClick={() => openEditDestDialog(target)}>
            <Typography>Edit settings...</Typography>
          </MenuItem>
          <MenuItem divider />
          <MenuItem onClick={() => deleteTargetDest(target)}>
            <Typography>Delete…</Typography>
          </MenuItem>
        </Menu>
      </section>
    </>
  );
};

export default OutputDestMenuItem;
