import React, { useState, useEffect } from 'react';
import { createStyles, makeStyles, Theme } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import Grid from '@material-ui/core/Grid';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import IconButton from '@material-ui/core/IconButton';
import Typography from '@material-ui/core/Typography';
import CloseIcon from '@material-ui/icons/Close';
import MenuItem from '@material-ui/core/MenuItem';
import Slide from '@material-ui/core/Slide';
import { TransitionProps } from '@material-ui/core/transitions';
import { FormControl, InputAdornment, InputLabel, TextField, OutlinedInput } from '@material-ui/core';
import AppDialog from '../../../global/components/appDialog/AppDialog';
import HelpOutlineSharpIcon from '@material-ui/icons/HelpOutlineSharp';
import {
  IGetRolesByModelId,
  IGetUsersByModelId,
  IUpsertTargetDetails,
  IUpsertTarget,
} from '../../../global/services/apistypes';
import VisibilityIcon from '@material-ui/icons/Visibility';
import VisibilityOffIcon from '@material-ui/icons/VisibilityOff';
import { globalApis } from '../../../global/services/apis';
import Autocomplete from '@material-ui/lab/Autocomplete';

interface OutputDestEditProps {
  openEditDialog: boolean;
  closeEditDialog: () => void;
  targetDetails: any
  mdelId: number;
  newDest: boolean;
  setRefreshList: any;
  refreshList: boolean;
}

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    appBar: {
      position: 'relative',
    },
    title: {
      marginLeft: theme.spacing(2),
      flex: 1,
    },
    textFieldFlex: {
      display: 'flex',
      alignItems: 'center',
      marginBottom: '2.5rem',
    },
    gridContainer: {
      margin: '0 1.5rem',
    },
    fieldSize: {
      width: '20.5rem',
    },
    toggle: {
      display: 'flex',
      alignItems: 'center',
      width: '20.5rem',
      justifyContent: 'space-between',
    },
    icon: {
      marginLeft: '1rem',
      color: 'gray',
    },
    rightInfoContainer: {
      backgroundColor: ' rgba(0, 0, 0, 0.05)',
      height: '100%',
    },
    sideContent: {
      display: 'flex',
      flexDirection: 'column',
    },
    textField: {
      marginBottom: '1.5rem',
    },
  })
);

const Transition = React.forwardRef(function Transition(
  props: TransitionProps & { children?: React.ReactElement },
  ref: React.Ref<unknown>
) {
  return <Slide direction='up' ref={ref} {...props} />;
});

// CONVERTING INCOMING DATE TO UTC WITH PROPER FORMATTING
const dateFormat = (date: string) => {
  const inputDate = new Date(date).toUTCString().slice(5, 22);
  let char = ',';
  let position = 11;
  let output = [inputDate.slice(0, position), char, inputDate.slice(position)].join('');
  return output;
};

// START OF THE COMPONENT
const OutputDestEdit: React.FC<OutputDestEditProps> = props => {
  // DESTRUCTING INCOMING PROPS
  const { openEditDialog, closeEditDialog, targetDetails, mdelId: model, newDest, refreshList, setRefreshList } = props;

  const classes = useStyles();

  // DESTRUCTING TARGET DETAILS FOR A SINGLE TARGET DESTINATION
  const {
    destType,
    targetType,
    targetSubType,
    targetHost,
    port,
    defaultPath,
    userName,
    password,
    jdbcUrl,
    jdbcDriver,
    authMethod,
    targetId,
    lastUpdtbyUsrName,
    lastupdtDt,
    isrtedDt,
    isrtedByUsrName,
    keyLocation,
    keyPassPhrase,
    roleReadDesc,
    roleUpdateDesc,
    ownerName,
    linkPath,
  } = targetDetails;

  // STATE FOR HANDLING USER CHANGES TO FORM AND DISPLAYING IT
  const [destEdit, setDestEdit] = useState({
    destName: destType,
    tgtTyp: targetType,
    tgtSubType: targetSubType,
    tgtHost: targetHost,
    tgtPort: port,
    dfltPath: defaultPath,
    usrName: userName,
    pswd: password,
    url: jdbcUrl,
    driver: jdbcDriver,
    lnkPath: linkPath,
    authValues: authMethod === 'PASSWORD' ? 'Use Password' : authMethod === 'KEYFILE' ? 'Key File' : '',
    keyLoc: keyLocation,
    keyPass: keyPassPhrase,
    roleRead: roleReadDesc,
    roleUpdate: roleUpdateDesc,
  });

  // VALIDATING REQUIRED FIELDS
  const isRequired =
    destEdit.destName &&
    destEdit.tgtTyp &&
    destEdit.tgtSubType &&
    destEdit.tgtHost &&
    destEdit.usrName &&
    (destEdit.tgtTyp === 'DATABASE' ? 'PASSWORD' : destEdit.authValues)
      ? true
      : false;

  // STATE FOR SHOWING/HIDING PASSWORD
  const [showPassword, setShowPassword] = useState(false);
  // STATE FOR STORING ALL THE USER ROLES IN WHICH USER HAS ACCESS TO FOR A GIVEN MODEL
  const [userRoles, setUserRoles] = useState<IGetRolesByModelId[]>([
    { roleCode: '', roleDesc: '', roleId: 0, modelId: 0 },
  ]);

  // STATE FOR STORING OWNER NAME OF A GIVEN TARGET
  const [ownerVal, setOwnerVal] = React.useState<string | null | undefined>(ownerName);
  const [ownerEmail, setOwnerEmail] = React.useState<string | null | undefined>('');

  // STATE FOR STORING ALL THE USERS WHICH HAS ACCESS TO MODEL WHICH USER IS PERFORMING EDIT ACTIONS
  const [users, setUsers] = useState<IGetUsersByModelId[]>([
    {
      userName: '',
      fullName: '',
      userId: 0,
      withGrantFlg: null,
    },
  ]);

  const [testConnectionDialog, setTestConnectionDialog] = useState(false);
  const userEmail = localStorage.getItem('useremail');

  // HOOK TO INVOKE ROLES AND USERS API FOR A GIVEN MODEL ID
  useEffect(() => {
    globalApis
      .getRolesByModelId(model)
      .then(response => {
        setUserRoles(response.data);
      })
      .catch(error => error);
    globalApis
      .getUsersByModelId(model)
      .then(response => {
        setUsers(response.data);
        const user = response.data.find(user => user.userName === userEmail);
        if (newDest) {
          setOwnerVal(user?.fullName);
        }
      })
      .catch(error => error);
  }, [model, userEmail, newDest]);

  useEffect(() => {
    const user = users.find(user => user.fullName === ownerVal);
    setOwnerEmail(user?.userName);
  }, [ownerVal, users]);

  // FUNCTION TO CREATE A NEW DESTINATION AND ALSO TO UPDATE AN EXISTING ONE
  const destinationUpsert = () => {
    const input: IUpsertTarget = {
      targetId: targetId ? targetId : 0,
      destType: destEdit.destName,
      targetType: destEdit.tgtTyp,
      targetHost: destEdit.tgtHost,
      port: destEdit.tgtPort ? +destEdit.tgtPort : null,
      userName: destEdit.usrName,
      password: destEdit.pswd ? destEdit.pswd : null,
      defaultPath: destEdit.dfltPath ? destEdit.dfltPath : null,
      targetSubType: destEdit.tgtSubType,
      jdbcUrl: destEdit.url ? destEdit.url : null,
      jdbcDriver: destEdit.driver ? destEdit.driver : null,
      linkPath: destEdit.lnkPath ? destEdit.lnkPath : null,
      keyLocation: destEdit.keyLoc ? destEdit.keyLoc : null,
      keyPassPhrase: destEdit.keyPass ? destEdit.keyPass : null,
      authMethod:
        destEdit.tgtTyp === 'DATABASE'
          ? 'PASSWORD'
          : destEdit.authValues === 'Use Password'
          ? 'PASSWORD'
          : destEdit.authValues === 'Key File'
          ? 'KEYFILE'
          : '',
      roleReadId: userRoles.find(role => role.roleDesc === destEdit.roleRead)?.roleId,
      roleUpdateId: userRoles.find(role => role.roleDesc === destEdit.roleUpdate)?.roleId,
      ownerName: ownerEmail,
    };
    const upsertInput: IUpsertTargetDetails = {
      mdelId: model,
      insert: newDest ? [input] : null,
      update: !newDest ? [input] : null,
      delete: null,
    };

    globalApis
      .upsertTargetDetails(upsertInput)
      .then(response => {
        closeEditDialog();
        setRefreshList(!refreshList);
      })
      .catch(error => error);
  };

  const ftpSubTypes = ['SFTP', 'SMB3', 'MAINFRAME', 'SMB2', 'DBF'];
  const dBSubTypes = ['SFTP', 'EXASOL', 'SQLServer', 'DBF', 'HIVE'];

  const subType = destEdit.tgtTyp === 'FTP' ? ftpSubTypes : destEdit.tgtTyp === 'DATABASE' ? dBSubTypes : [];

  const onTestConnection = () => {
    const upsertTestConnection = {
      targetType: destEdit.tgtTyp,
      targetSubType: destEdit.tgtSubType,
      host: destEdit.tgtHost ? destEdit.tgtHost : null,
      userName: destEdit.usrName ? destEdit.usrName : null,
      authMethod: destEdit.authValues ? destEdit.authValues : null,
      password: destEdit.pswd ? destEdit.pswd : null,
      port: destEdit.tgtPort ? +destEdit.tgtPort : null,
      keyPath: destEdit.keyLoc ? destEdit.keyLoc : null,
      keyPassphrase: destEdit.keyPass ? destEdit.keyPass : null,
      jdbcUrl: destEdit.url ? destEdit.url : null,
      jdbcDriver: destEdit.driver ? destEdit.driver : null,
      defaultPath: destEdit.dfltPath ? destEdit.dfltPath : null,
    };

    globalApis
      .jdbcTestConnection(upsertTestConnection)
      .then(response => {
        if (response.data) setTestConnectionDialog(true);
      })
      .catch(error => error);
  };

  //close dialog
  const closeDialog = (event?: React.SyntheticEvent, reason?: string) => {
    if (reason === 'backdropClick') {
      return;
    }
    setTestConnectionDialog(false);
  };

  return (
    <>
      {testConnectionDialog && (
        <AppDialog
          title='Connection OK'
          content='Able to connect to destination'
          open={testConnectionDialog}
          handleClose={closeDialog}
          ok='OK'
          cancel=''
        />
      )}

      <Dialog fullScreen open={openEditDialog} onClose={closeEditDialog} TransitionComponent={Transition}>
        <AppBar className={classes.appBar} color='transparent'>
          <Toolbar>
            <IconButton edge='start' color='inherit' onClick={closeEditDialog} aria-label='close'>
              <CloseIcon />
            </IconButton>
            <Typography variant='h6' className={classes.title}>
              {destType}
            </Typography>
            <Button variant='contained' color='primary' onClick={destinationUpsert} disabled={!isRequired}>
              {newDest ? 'CREATE' : 'UPDATE'}
            </Button>
          </Toolbar>
        </AppBar>
        <section style={{ padding: '1.5rem' }}>
          <Typography>Destination Definition</Typography>
          <Typography style={{ marginTop: '0.8rem' }} variant='subtitle1' color='textSecondary'>
            These settings configure a “Destination” option for output files and tables. Required fields are marked 
            with an asterisk “*”.
          </Typography>
        </section>

        <form className={classes.gridContainer}>
          <Grid container>
            <Grid item xs={12} sm={12} md={6}>
              <div className={classes.textFieldFlex}>
                <TextField
                  className={classes.fieldSize}
                  label='Destination Name*'
                  type='text'
                  variant='outlined'
                  value={destEdit.destName}
                  onChange={event => setDestEdit(prev => ({ ...prev, destName: event.target.value }))}
                  disabled={!newDest}
                />
                <HelpOutlineSharpIcon className={classes.icon} />
              </div>
              <div className={classes.textFieldFlex}>
                <TextField
                  className={classes.fieldSize}
                  select
                  label='Destination Type*'
                  variant='outlined'
                  value={destEdit.tgtTyp}
                  onChange={event => setDestEdit(prev => ({ ...prev, tgtTyp: event.target.value }))}
                >
                  {['DATABASE', 'FTP'].map(option => (
                    <MenuItem key={option} value={option}>
                      {option}
                    </MenuItem>
                  ))}
                </TextField>
                <HelpOutlineSharpIcon className={classes.icon} />
              </div>
              <div className={classes.textFieldFlex}>
                <TextField
                  select
                  label='Destination Sub-type*'
                  className={classes.fieldSize}
                  variant='outlined'
                  value={destEdit.tgtSubType}
                  onChange={event => setDestEdit(prev => ({ ...prev, tgtSubType: event.target.value }))}
                  disabled={!destEdit.tgtTyp}
                >
                  {subType.map(option => (
                    <MenuItem key={option} value={option}>
                      {option}
                    </MenuItem>
                  ))}
                </TextField>
                <HelpOutlineSharpIcon className={classes.icon} />
              </div>
              <Typography style={{ marginBottom: '1rem' }}>Host</Typography>
              <div className={classes.textFieldFlex}>
                <TextField
                  label='Host Name/Address*'
                  value={destEdit.tgtHost}
                  onChange={event => setDestEdit(prev => ({ ...prev, tgtHost: event.target.value }))}
                  className={classes.fieldSize}
                  variant='outlined'
                />
                <HelpOutlineSharpIcon className={classes.icon} />
              </div>
              <div className={classes.textFieldFlex}>
                <TextField
                  className={classes.fieldSize}
                  style={{ width: '15%' }}
                  label='Port'
                  type='text'
                  variant='outlined'
                  value={destEdit.tgtPort}
                  onChange={event => setDestEdit(prev => ({ ...prev, tgtPort: +event.target.value }))}
                />
                <HelpOutlineSharpIcon className={classes.icon} />
              </div>
              <div className={classes.textFieldFlex}>
                <TextField
                  className={classes.fieldSize}
                  label='Default Path'
                  type='text'
                  variant='outlined'
                  value={destEdit.dfltPath}
                  onChange={event => setDestEdit(prev => ({ ...prev, dfltPath: event.target.value }))}
                />
                <HelpOutlineSharpIcon className={classes.icon} />
              </div>

              <Typography style={{ marginBottom: '1rem' }}>Authentication</Typography>
              <div className={classes.textFieldFlex}>
                <TextField
                  label='Username*'
                  value={destEdit.usrName}
                  onChange={event => setDestEdit(prev => ({ ...prev, usrName: event.target.value }))}
                  className={classes.fieldSize}
                  variant='outlined'
                />
                <HelpOutlineSharpIcon className={classes.icon} />
              </div>
              {destEdit.tgtTyp === 'FTP' ? (
                <div className={classes.textFieldFlex}>
                  <TextField
                    select
                    label='Authentication Method*'
                    className={classes.fieldSize}
                    variant='outlined'
                    value={destEdit.authValues}
                    onChange={event => setDestEdit(prev => ({ ...prev, authValues: event.target.value }))}
                  >
                    {['Key File', 'Use Password'].map(option => (
                      <MenuItem key={option} value={option}>
                        {option}
                      </MenuItem>
                    ))}
                  </TextField>
                  <HelpOutlineSharpIcon className={classes.icon} />
                </div>
              ) : null}

              {destEdit.authValues === 'Use Password' ? (
                <div className={classes.textFieldFlex}>
                  <FormControl
                    variant='outlined'
                    style={{ marginLeft: `${destEdit.tgtTyp === 'DATABASE' ? 0 : '2.5rem'}` }}
                  >
                    <InputLabel htmlFor='outlined-adornment-password'>Password</InputLabel>
                    <OutlinedInput
                      className={classes.fieldSize}
                      id='outlined-adornment-password'
                      type={showPassword ? 'text' : 'password'}
                      value={destEdit.pswd}
                      onChange={event => setDestEdit(prev => ({ ...prev, pswd: event.target.value }))}
                      endAdornment={
                        <InputAdornment position='end'>
                          <IconButton
                            aria-label='toggle password visibility'
                            onClick={() => setShowPassword(!showPassword)}
                            edge='end'
                          >
                            {showPassword ? <VisibilityIcon /> : <VisibilityOffIcon />}
                          </IconButton>
                        </InputAdornment>
                      }
                      labelWidth={70}
                    />
                  </FormControl>
                  <HelpOutlineSharpIcon className={classes.icon} />
                  {destEdit.tgtTyp === 'DATABASE' ? null : (
                    <Button
                      variant='outlined'
                      onClick={onTestConnection}
                      style={{ marginLeft: '2rem' }}
                      color='primary'
                    >
                      TEST CONNECTION
                    </Button>
                  )}
                </div>
              ) : null}
              {destEdit.authValues === 'Key File' ? (
                <div>
                  <div className={classes.textFieldFlex}>
                    <TextField
                      style={{ marginLeft: '2.5rem' }}
                      label='SSH Private Key Location'
                      value={destEdit.keyLoc}
                      onChange={event => setDestEdit(prev => ({ ...prev, keyLoc: event.target.value }))}
                      className={classes.fieldSize}
                      variant='outlined'
                    />
                    <HelpOutlineSharpIcon className={classes.icon} />
                    <Button
                      variant='outlined'
                      onClick={onTestConnection}
                      style={{ marginLeft: '2rem' }}
                      color='primary'
                    >
                      TEST CONNECTION
                    </Button>
                  </div>

                  <div className={classes.textFieldFlex}>
                    <FormControl variant='outlined' style={{ marginLeft: '2.5rem' }}>
                      <InputLabel htmlFor='outlined-adornment-password'>SSH Private Key Passphrase</InputLabel>
                      <OutlinedInput
                        className={classes.fieldSize}
                        id='outlined-adornment-password'
                        type={showPassword ? 'text' : 'password'}
                        value={destEdit.keyPass}
                        onChange={event => setDestEdit(prev => ({ ...prev, keyPass: event.target.value }))}
                        endAdornment={
                          <InputAdornment position='end'>
                            <IconButton
                              aria-label='toggle password visibility'
                              onClick={() => setShowPassword(!showPassword)}
                              edge='end'
                            >
                              {showPassword ? <VisibilityIcon /> : <VisibilityOffIcon />}
                            </IconButton>
                          </InputAdornment>
                        }
                        labelWidth={200}
                      />
                    </FormControl>
                    <HelpOutlineSharpIcon className={classes.icon} />
                  </div>
                </div>
              ) : null}

              {destEdit.tgtTyp === 'DATABASE' ? (
                <div>
                  <Typography style={{ marginBottom: '1rem' }}>JDBC Connection</Typography>
                  <div className={classes.textFieldFlex}>
                    <TextField
                      label='URL'
                      value={destEdit.url}
                      onChange={event => setDestEdit(prev => ({ ...prev, url: event.target.value }))}
                      className={classes.fieldSize}
                      variant='outlined'
                    />
                    <HelpOutlineSharpIcon className={classes.icon} />
                    <Button
                      variant='outlined'
                      onClick={onTestConnection}
                      style={{ marginLeft: '2rem' }}
                      color='primary'
                    >
                      TEST CONNECTION
                    </Button>
                  </div>
                  <div className={classes.textFieldFlex}>
                    <TextField
                      label='Driver'
                      value={destEdit.driver}
                      onChange={event => setDestEdit(prev => ({ ...prev, driver: event.target.value }))}
                      className={classes.fieldSize}
                      variant='outlined'
                    />
                    <HelpOutlineSharpIcon className={classes.icon} />
                  </div>
                </div>
              ) : null}

              <Typography style={{ marginBottom: '1rem' }}>Access Rights for this Destination</Typography>

              <div className={classes.textFieldFlex}>
                <TextField
                  select
                  label='Read'
                  className={classes.fieldSize}
                  variant='outlined'
                  value={destEdit.roleRead}
                  onChange={event => setDestEdit(prev => ({ ...prev, roleRead: event.target.value }))}
                  helperText='Able to select this destination in the application'
                >
                  {userRoles.map(option => (
                    <MenuItem key={option.roleId} value={option.roleDesc}>
                      {option.roleDesc}
                    </MenuItem>
                  ))}
                </TextField>
                <HelpOutlineSharpIcon style={{ marginBottom: '1.5rem' }} className={classes.icon} />
              </div>

              <div className={classes.textFieldFlex}>
                <TextField
                  select
                  label='Update'
                  className={classes.fieldSize}
                  variant='outlined'
                  value={destEdit.roleUpdate}
                  onChange={event => setDestEdit(prev => ({ ...prev, roleUpdate: event.target.value }))}
                  helperText='Able to modify this destination definition'
                >
                  {userRoles.map(option => (
                    <MenuItem key={option.roleId} value={option.roleDesc}>
                      {option.roleDesc}
                    </MenuItem>
                  ))}
                </TextField>
                <HelpOutlineSharpIcon style={{ marginBottom: '1.5rem' }} className={classes.icon} />
              </div>

              <div className={classes.textFieldFlex}>
                <Autocomplete
                  className={classes.fieldSize}
                  value={ownerVal}
                  onChange={(event: any, newValue: string | null) => {
                    setOwnerVal(newValue);
                  }}
                  options={users.map((user: IGetUsersByModelId) => {
                    return user.fullName;
                  })}
                  renderInput={params => <TextField {...params} label='Owner' variant='outlined' />}
                />
                <HelpOutlineSharpIcon className={classes.icon} />
              </div>
            </Grid>
            <Grid item xs={12} sm={12} md={6} className={classes.rightInfoContainer}>
              <aside style={{ display: 'flex', margin: '1rem' }}>
                <div style={{ marginRight: '3rem' }} className={classes.sideContent}>
                  <Typography className={classes.textField}>Last update:</Typography>
                  <Typography className={classes.textField}>Created:</Typography>
                  <Typography className={classes.textField}>Model ID:</Typography>
                  <Typography>Target ID:</Typography>
                </div>
                <div className={classes.sideContent}>
                  <Typography className={classes.textField} color='textSecondary'>
                    {lastupdtDt ? dateFormat(lastupdtDt) + ' , ' + lastUpdtbyUsrName : '-'}
                  </Typography>
                  <Typography className={classes.textField} color='textSecondary'>
                    {isrtedDt ? dateFormat(isrtedDt) + ' , ' + isrtedByUsrName : '-'}
                  </Typography>
                  <Typography color='textSecondary' className={classes.textField}>
                    {model}
                  </Typography>
                  <Typography color='textSecondary'>{targetId ? targetId : '-'}</Typography>
                </div>
              </aside>
            </Grid>
          </Grid>
        </form>
      </Dialog>
    </>
  );
};

export default OutputDestEdit;
