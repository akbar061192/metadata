import React, { useState, useEffect, Dispatch } from 'react';
import { Paper, Container, Theme, Typography, Button, TextField } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import { useHistory } from 'react-router-dom';
import { globalApis } from '../../global/services/apis';
import ReportProblemIcon from '@material-ui/icons/ReportProblem';
import img from '../../assets/images/loginIcon.png';
import { useSelector, useDispatch } from 'react-redux';
import { AppState } from '../../global/redux/reducers/rootReducer';
import { LoginActions } from '../../global/redux/actions/subjectAreaAction';
import { subjectAreaActionTypes } from '../../global/redux/actions/subjectAreaAction';

type LoginInput = {
  emailId: string;
  password: string;
};

/**
 *
 * Component for User Login using Email and Password.
 *
 * @param emailId - User Email
 * @param password - User Password
 *
 **/

const useStyles = makeStyles((theme: Theme) => {
  return {
    paper: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      marginTop: theme.spacing(8),
      width: theme.spacing(42),
      height: theme.spacing(69),
    },
    icon: {
      marginTop: theme.spacing(8),
      marginBottom: theme.spacing(3),
    },
    form: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      marginTop: theme.spacing(1),
      width: '80%',
      '& .MuiInputBase-input': {
        color: 'black',
      },
    },
    helperText: {
      color: 'red',
      fontWeight: 'bold',
    },
    loginError: {
      width: '80%',
      display: 'flex',
      justifyContent: 'center',
      flexDirection: 'row',
      alignItems: 'center',
      marginTop: '24px',
    },
  };
});

// START OF THE COMPONENT
const Login: React.FC = () => {
  const classes = useStyles();

  // LOCAL STATE TO STORE USER INPUTS
  const [inputs, setInputs] = useState<LoginInput | any>({ emailId: '', password: '' });
  // LOCAL STATE TO STORE ERROR OBJECT IF INVALID CREDS ARE ENTERED
  const [errors, setErrors] = useState<LoginInput>({ emailId: '', password: '' });

  // DISPATCH FOR REDUX ACTIONS
  const loginDispatch = useDispatch<Dispatch<LoginActions>>();
  // useHistroy HOOK FOR PUSHING USER TO SUBJECT AREA CARDS PAGE WHEN LOGIN BUTTON IS CLICKED
  const history = useHistory();

  // DISPATCHING LOGIN SUCCESS ACTION AND STORING DATA IN REDUX STORE
  const loginSuccess = (user: any) => {
    loginDispatch({ type: subjectAreaActionTypes.AUTH_LOGIN_SUCCESS, payload: user });
  };

  // FETCHING DATA FROM REDUX STORE
  const { valid, token, userApps } = useSelector((state: AppState) => state.login);

  // WILL BE CALLED ONCE THE STORE STATE CHANGES MAKES TO RENDER THE PAGE AND REDIRECT TO LANDING PAGE
  useEffect(() => {
    if (valid) {
      localStorage.setItem('token', token);
      localStorage.setItem('useremail', inputs.emailId);
      history.push('/SubjectAreaCards');
    }
  }, [valid, token, history, inputs.emailId]);

  useEffect(() => {
    if (localStorage.getItem('useremail') !== null) {
      setInputs({ emailId: localStorage.getItem('useremail'), password: '' });
    }
  }, []);

  // VALIDATING LOGIN FORM ON CLICKING LOGIN BUTTON AND ALSO WHILE TYPING
  const formValidation = (values: any = inputs) => {
    let errObj: any = {};
    if ('emailId' in values) errObj.emailId = values.emailId ? '' : 'Required*';
    if ('password' in values) errObj.password = values.password ? '' : 'Required*';

    setErrors(prevState => {
      return {
        ...prevState,
        ...errObj,
      };
    });

    return Object.values(errObj).every(value => value === '');
  };

  // HANDLING INPUT ENTERED BY THE USER WITH VALIDATION
  const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = event.target;

    setInputs((prevState: any) => {
      return {
        ...prevState,
        [name]: value,
      };
    });

    formValidation({
      [name]: value,
    });
  };

  // SUBMITTING USER INPUT AND CALLING AUTH API WITH LOGINSUCCESS ACTION
  const loginSubmit = (event: React.SyntheticEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (formValidation()) {
      globalApis
        .authenticateUser(inputs)
        .then(response => {
          loginSuccess(response.data);
        })
        .catch(err => {
          return err;
        });
    }
  };

  return (
    <Container maxWidth='xs'>
      <Paper className={classes.paper}>
        <div className={classes.icon}>
          <img style={{ width: '62px', height: '62px' }} src={img} alt='Big Metadata' />
        </div>
        <Typography variant='h4'>Big Data</Typography>
        <Typography style={{ marginTop: '5px' }} variant='subtitle1' color='textSecondary'>
          Meta Data Manager
        </Typography>
        {!valid && userApps === null && (
          <div className={classes.loginError}>
            <ReportProblemIcon style={{ color: 'red', marginRight: '5px' }} />
            <Typography style={{ color: 'red' }} variant='subtitle2'>
              {token}
            </Typography>
          </div>
        )}
        <form className={classes.form} onSubmit={loginSubmit}>
          <TextField
            fullWidth
            variant='outlined'
            InputLabelProps={{ shrink: false }}
            label={inputs.emailId === '' ? 'Email' : ''}
            style={{ margin: '20px 0' }}
            value={inputs.emailId}
            onChange={handleInputChange}
            name='emailId'
            FormHelperTextProps={{
              className: classes.helperText,
            }}
            helperText={errors.emailId}
            error={errors.emailId ? true : false}
          />
          <TextField
            fullWidth
            label={inputs.password === '' ? 'Password' : ''}
            style={{ marginBottom: '30px' }}
            InputLabelProps={{ shrink: false }}
            variant='outlined'
            type='password'
            value={inputs.password}
            onChange={handleInputChange}
            FormHelperTextProps={{
              className: classes.helperText,
            }}
            name='password'
            helperText={errors.password}
            error={errors.password ? true : false}
          />
          <Button type='submit' variant='contained' color='primary'>
            LOG IN
          </Button>
        </form>
      </Paper>
    </Container>
  );
};

export default Login;
