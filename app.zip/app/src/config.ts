const envSettings = window as any;

export class Config {
  static api_url = envSettings.API_URL;
}