import React, { FC } from 'react';
import Routes from './global/routes/Routes';
import { Home } from './pages/home';


export const App: FC = () => {
  return (
    <div>
      <Routes>
        <Home></Home>
      </Routes>
    </div>
  );
};
