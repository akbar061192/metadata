const config = {
  apiEndPoints: {
    BASEURL: {
      API_UI_URL: 'http://caruiceapp02i.rxcorp.com:9005/',
      API_METADATA_URL: 'http://caruiceapp02i.rxcorp.com:9002/',
      API_METADATA_URL_DEV: 'http://caruiceapp01d.rxcorp.com:9002/',
      API_UI_URL_DEV: 'http://caruiceapp01d.rxcorp.com:9005/',
    },
    ICEUI: {
      GET_SUBJECT_AREA: 'api/iceuirequest/request/requestApplDashboard/',
    },
    METADATA: {
      AUTHENTICATE_USER: 'api/metadata/authenticate/',
      PERMISSIONS: 'api/metadata/user/permissions/',
      COMMIT_SUBJECT_AREA: 'api/metadata/model/commit',
      FETCH_PREVIOUS_COMMITS: 'api/metadata/model/commits/',
      PROMOTE_SUBJECT_AREA: 'api/metadata/model/promote',
      LOV_BY_MDEL_ID: 'api/metadata/listofvalueheaders/',
      LOV_DETAILS_BY_LOV_ID: 'api/metadata/listofvaluedetails/',
      LOV_DETAILS_UPSERT: 'api/metadata/listofvaluedetails/upsert',
      ROLES_BY_MODEL_ID: 'api/metadata/user/roles/model/',
      TARGETS_BY_MODEL_ID: 'api/metadata/targets/',
      USERS_BY_MODEL_UD: 'api/metadata/user/',
      TARGET_UPSERT: 'api/metadata/targets/',
      LOV_UPSERT: 'api/metadata/listofvalueheaders/upsert',
      EVENTS_BY_MODEL_ID: 'api/metadata/event/',
      EVENTS_UPSERT: 'api/metadata/event/upsert',
      GET_DBTAGS: 'api/metadata/dbcredentials/namelifecycle/',
      JDBC_TEST_CONNECTION: 'api/metadata/target/connection',
      VALIDATE_SQL: 'api/metadata/validatelovsql',
    },
  },
};

export default config;
