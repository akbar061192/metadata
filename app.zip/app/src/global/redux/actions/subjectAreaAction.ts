export enum subjectAreaActionTypes {
  AUTH_LOGIN_SUCCESS = 'AUTH_LOGIN_SUCCESS',
  LOGOUT_CLEAR_AUTH_STATE = 'LOGOUT_CLEAR_AUTH_STATE',
}

export interface IUserPayload {
  valid: boolean;
  token: string;
  userApps?: IUserApps;
  userPerms: IUserPerms[];
}

export interface IUserApps {
  requestList: string;
  users: string;
  metaData: string;
  cLASP: string;
  markets: string;
  jobMonitor: string;
}

export interface IUserPerms {
  modelId: number;
  privCd: string;
}

export interface ILoginSuccessAction {
  readonly type: subjectAreaActionTypes.AUTH_LOGIN_SUCCESS;
  payload: IUserPayload;
}

export interface ILogut {
  readonly type: subjectAreaActionTypes.LOGOUT_CLEAR_AUTH_STATE;
}

export type LoginActions = ILoginSuccessAction | ILogut;
