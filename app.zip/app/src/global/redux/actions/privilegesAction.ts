export enum privilegesActionTypes {
  GET_PRIVILEGES_SUCCESS = 'GET_PRIVILEGES_SUCCESS',
  LOGOUT_CLEAR_PRIVILEGES_STATE = 'LOGOUT_CLEAR_PRIVILEGES_STATE',
}

export interface IUserPerms {
  modelId: number;
  privCd: string;
  roleCd: string;
}

export interface IUserPermsSuccessAction {
  readonly type: privilegesActionTypes.GET_PRIVILEGES_SUCCESS;
  payload: IUserPerms[];
}
export interface IClearStateAction {
  readonly type: privilegesActionTypes.LOGOUT_CLEAR_PRIVILEGES_STATE;
}

export type PrivilegeActions = IUserPermsSuccessAction | IClearStateAction;
