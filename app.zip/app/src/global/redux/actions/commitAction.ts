export enum commitActionTypes {
  ENABLE_COMMIT = 'ENABLE_COMMIT',
  GET_ENABLE_COMMIT = 'GET_ENABLE_COMMIT',
}

export interface IEnableCommit {
  Iscommit: boolean;
}

export interface IEnableCommitAction {
  readonly type: commitActionTypes.ENABLE_COMMIT;
  payload: IEnableCommit;
}

export interface IGetCommitAction {
  readonly type: commitActionTypes.GET_ENABLE_COMMIT;
}

export type CommitActions = IEnableCommitAction | IGetCommitAction;
