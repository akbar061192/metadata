export enum roleModelActionTypes {
  GET_ROLE_MODEL_SUCCESS = 'GET_ROLE_MODEL_SUCCESS',
}

export interface IRoleModel {
  roleCode: string;
  roleDesc: string;
  roleId: number;
  modelId: number;
}

export interface IRoleModelSuccessAction {
  readonly type: roleModelActionTypes.GET_ROLE_MODEL_SUCCESS;
  payload: IRoleModel[];
}
export type RoleModelActions = IRoleModelSuccessAction;
