import { RoleModelActions, IRoleModel, roleModelActionTypes } from '../actions/roleModelActions';
export interface IRoleModelState {
  roleModelData: IRoleModel[];
}

const initialState: IRoleModelState = {
  roleModelData: [{ roleCode: '', roleDesc: '', roleId: 0, modelId: 0 }],
};

const privilegeReducer = (state = initialState, action: RoleModelActions) => {
  switch (action.type) {
    case roleModelActionTypes.GET_ROLE_MODEL_SUCCESS:
      return {
        ...state,
        roleModelData: action.payload,
      };

    default:
      return state;
  }
};
export default privilegeReducer;
