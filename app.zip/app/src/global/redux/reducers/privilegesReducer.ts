import { PrivilegeActions } from '../actions/privilegesAction';
import { privilegesActionTypes } from '../actions/privilegesAction';

export interface IUserPermState {
  userPerms: IUserPerms[];
}

export interface IUserPerms {
  modelId: number;
  privCd: string;
  roleCd: string;
}

const initialState: IUserPermState = {
  userPerms: [{ modelId: 0, privCd: '', roleCd: '' }],
};

const privilegeReducer = (state: IUserPermState = initialState, action: PrivilegeActions): IUserPermState => {
  switch (action.type) {
    case privilegesActionTypes.GET_PRIVILEGES_SUCCESS:
      return {
        ...state,
        userPerms: action.payload,
      };
    case privilegesActionTypes.LOGOUT_CLEAR_PRIVILEGES_STATE:
      return {
        ...state,
        userPerms: [{ modelId: 0, privCd: '', roleCd: '' }],
      };

    default:
      return state;
  }
};
export default privilegeReducer;
