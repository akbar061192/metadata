import { combineReducers } from 'redux';
import loginReducer from './subjectAreaReducer';
import privilegesReducer from './privilegesReducer';
import commitReducer from './commitReducer';
import roleModelReducer from './roleModelReducer';

const rootReducer = combineReducers({
  login: loginReducer,
  privileges: privilegesReducer,
  commmit: commitReducer,
  roleModel: roleModelReducer,
});
export type AppState = ReturnType<typeof rootReducer>;
export default rootReducer;
