import { LoginActions } from '../actions/subjectAreaAction';
import { subjectAreaActionTypes } from '../actions/subjectAreaAction';

export interface IUserState {
  valid: boolean;
  token: string;
  userApps?: IUserApps;
}

export interface IUserApps {
  requestList: string;
  users: string;
  metaData: string;
  cLASP: string;
  markets: string;
  jobMonitor: string;
}

export interface IUserPerms {
  modelId: number;
  privCd: string;
}

const initialState: IUserState = {
  valid: false,
  token: '',
  userApps: {
    requestList: '',
    users: '',
    metaData: '',
    cLASP: '',
    markets: '',
    jobMonitor: '',
  },
};

const loginReducer = (state: IUserState = initialState, action: LoginActions): IUserState => {
  switch (action.type) {
    case subjectAreaActionTypes.AUTH_LOGIN_SUCCESS:
      return {
        ...state,
        valid: action.payload.valid,
        token: action.payload.token,
        userApps: action.payload.userApps,
      };
    case subjectAreaActionTypes.LOGOUT_CLEAR_AUTH_STATE: {
      return {
        ...state,
        valid: false,
        token: '',
      };
    }
    default:
      return state;
  }
};
export default loginReducer;
