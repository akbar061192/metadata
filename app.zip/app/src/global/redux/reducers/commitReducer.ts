import { CommitActions } from '../actions/commitAction';
import { commitActionTypes } from '../actions/commitAction';

export interface IEnableCommitState {
  IsCommit: boolean;
}

const initialState: IEnableCommitState = {
  IsCommit: true,
};

const commitReducer = (state: IEnableCommitState = initialState, action: CommitActions): IEnableCommitState => {
  switch (action.type) {
    case commitActionTypes.GET_ENABLE_COMMIT:
      return {
        ...state,
        IsCommit: true,
      };
    default:
      return state;
  }
};
export default commitReducer;
