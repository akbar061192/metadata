import React, { useState, useEffect } from 'react';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import SnackbarAlert from '../snackBar/SnackBar';
import CloudUploadIcon from '@material-ui/icons/CloudUpload';
import { createStyles, makeStyles, Theme } from '@material-ui/core/styles';
import { IFetchPreviousCommits } from '../../services/apistypes';
import { PromoteDetails } from '../../../pages/subjectArea/subjectAreaDetails';
import { globalApis } from '../../services/apis';

interface PromoteDialogProps {
  handleClose: () => void;
  open: boolean;
  promotingLifeCycle: PromoteDetails | undefined;
  promotingVersion: string;
  commits: IFetchPreviousCommits[] | undefined;
}

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    promoteContainer: {
      width: '30rem',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-start',
      marginTop: '1rem',
      marginLeft: '1rem',
    },
    versionRow: {
      display: 'flex',
      alignItems: 'center',
      marginRight: '1rem',
    },
  })
);

const PromoteDialog: React.FC<PromoteDialogProps> = props => {
  const { handleClose, open, promotingLifeCycle, promotingVersion, commits } = props;
  const [details, setDetails] = useState<IFetchPreviousCommits | any>();
  const classes = useStyles();

  // LOCAL STATE FOR OPENING AND CLOSING SNACKBAR ALERT
  const [openSnackBar, setOpenSnackBar] = React.useState(false);

  // CLOSE PROMOTE DIALOG
  const closePromoteDialog = () => {
    handleClose();
  };

  useEffect(() => {
    const data = commits?.find(d => d.version === promotingVersion);
    setDetails(data);
  }, [commits, promotingVersion]);

  // CLOSE SNACKBAR ALERT WHEN USER CLICKS ON X BUTTON
  const closeSnackBarAlert = (event?: React.SyntheticEvent, reason?: string) => {
    if (reason === 'clickaway') {
      return;
    }
    setOpenSnackBar(false);
  };

  // CONVERTING INCOMING DATE TO UTC WITH PROPER FORMATTING
  const dateFormat = (date: any) => {
    const inputDate = new Date(date).toUTCString().slice(5, 22) + ' UTC';
    let char = ',';
    let position = 11;
    let output = [inputDate.slice(0, position), char, inputDate.slice(position)].join('');
    return output;
  };

  //CLICKING PROMOTE BUTTON TO MAKE A PROMOTE TO OTHER LIFECYCLES.
  const promoteSubjectArea = (lifeCycle: any) => {
    globalApis
      .promoteSubjectArea({
        modelId: details.modelId,
        commitId: details.commitId,
        targetEnv: lifeCycle,
      })
      .then(response => {
        closePromoteDialog();
        setOpenSnackBar(true);
      })
      .catch(error => {
        closePromoteDialog();
        return error;
      });
  };

  return (
    <div>
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle id='form-dialog-title'>Confirm Promote</DialogTitle>
        <DialogContent>
          Use Version:
          <section style={{ marginBottom: '1.25rem' }} className={classes.promoteContainer}>
            <div>
              <div style={{ fontSize: '0.9rem' }}>{promotingVersion + ' - ' + dateFormat(details?.commitTs)}</div>
              <div style={{ fontSize: '0.8rem', color: 'gray' }}>{details?.commitMsg}</div>
            </div>
          </section>
          Destination:
          <section className={classes.promoteContainer}>
            <div>
              <div style={{ fontSize: '1rem', color: 'gray' }}>{promotingLifeCycle?.value}</div>
            </div>
          </section>
        </DialogContent>
        <DialogActions style={{ padding: '1rem' }}>
          <Button onClick={closePromoteDialog} color='primary'>
            CANCEL
          </Button>
          <Button
            variant='contained'
            onClick={() => promoteSubjectArea(promotingLifeCycle?.key)}
            color='primary'
            startIcon={<CloudUploadIcon />}
            style={{ marginLeft: '2rem', backgroundColor: '#f57c00' }}
          >
            PROMOTE
          </Button>
        </DialogActions>
      </Dialog>

      {/* OPENS SNACKBAR WHEN ABOVE COMMIT BUTTON IS CLICKED */}
      <SnackbarAlert
        alertMessage={`Version ${promotingVersion} Promoted to ${promotingLifeCycle?.value}`}
        closeSnackBarAlert={closeSnackBarAlert}
        openSnackBar={openSnackBar}
      />
    </div>
  );
};

export default PromoteDialog;
