import React from 'react';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import { makeStyles } from '@material-ui/core/styles';

interface AppDialogProps {
  handleClose: () => void;
  open: boolean;
  title: string;
  content: string;
  ok: string | null;
  cancel: string | null;
}

const useStyles = makeStyles(theme => ({
  dialogPaper: {
    width: '400px',
  },
}));

const AppDialog: React.FC<AppDialogProps> = props => {
  const { handleClose, open, title, content, ok, cancel } = props;
  const classes = useStyles();

  return (
    <Dialog open={open} onClose={handleClose} classes={{ paper: classes.dialogPaper }}>
      <DialogTitle>{title}</DialogTitle>
      <DialogContent>
        <DialogContentText>{content}</DialogContentText>
      </DialogContent>
      <DialogActions>
        {ok && (
          <Button variant='outlined' color='primary' onClick={handleClose} style={{ margin: '1rem' }}>
            {ok}
          </Button>
        )}
        {cancel && (
          <Button color='primary' onClick={handleClose}>
            {cancel}
          </Button>
        )}
      </DialogActions>
    </Dialog>
  );
};

export default AppDialog;
