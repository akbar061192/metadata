import React, { useContext, Dispatch, useState } from 'react';
import { makeStyles, useTheme, Theme, createStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
import StorageIcon from '@material-ui/icons/Storage';
import ViewComfy from '@material-ui/icons/ViewComfy';
import clsx from 'clsx';
import Divider from '@material-ui/core/Divider';
import Drawer from '@material-ui/core/Drawer';
import Hidden from '@material-ui/core/Hidden';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import ListSubheader from '@material-ui/core/ListSubheader';
import { createTheme } from '@material-ui/core/styles';
import { Link } from 'react-router-dom';
import purple from '@material-ui/core/colors/purple';
import green from '@material-ui/core/colors/green';
import { Context } from '../../context/subjectAreaContext';
import AppsIcon from '@material-ui/icons/Apps';
import AccountCircleIcon from '@material-ui/icons/AccountCircle';
import { LoginActions } from '../../redux/actions/subjectAreaAction';
import { PrivilegeActions, privilegesActionTypes } from '../../redux/actions/privilegesAction';
import { useHistory } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { subjectAreaActionTypes } from '../../redux/actions/subjectAreaAction';
import AlertDialog from '../../components/alertDialog/AlertDialog';
import { AppState } from '../../redux/reducers/rootReducer';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import ExitToAppIcon from '@material-ui/icons/ExitToApp';
import { Config } from '../../../config';

const drawerWidth = 285;
const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    drawer: {
      [theme.breakpoints.up('sm')]: {
        width: drawerWidth,
        flexShrink: 0,
      },
    },
    drawerPaper: {
      width: drawerWidth,
    },
    toolbar: theme.mixins.toolbar,
    toolbar_color: {
      backgroundColor: 'linear-gradient(to left, #0076ae, #250056 3%)',
    },
    header: {
      background: 'linear-gradient(90deg, #250056, #0076ae) !important',
    },
    title: {
      flexGrow: 1,
    },
    appBar: {
      [theme.breakpoints.up('sm')]: {
        width: `calc(100% - ${drawerWidth}px)`,
        marginLeft: drawerWidth,
      },
    },
    menuButton: {
      marginRight: theme.spacing(2),
      [theme.breakpoints.up('sm')]: {
        display: 'none',
      },
    },
    sideBarIconWidth: {
      minWidth: '35px',
    },
  })
);
interface Props {
  window?: () => Window;
}

const theme = createTheme({
  palette: {
    primary: {
      main: purple[500],
    },
    secondary: {
      main: green[500],
    },
  },
});

export const Header = (props: Props) => {
  console.log(Config.api_url);
  console.log(process.env.REACT_APP_URI);
  const { window } = props;
  const classes = useStyles();
  const theme = useTheme();
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const state = useContext(Context);
  const loginDispatch = useDispatch<Dispatch<LoginActions>>();
  const privDispatch = useDispatch<Dispatch<PrivilegeActions>>();
  const history = useHistory();

  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);

  const clickMenu = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const closeMenu = () => {
    setAnchorEl(null);
  };

  // LOCAL STATE TO OPEN AND CLOSE DIALOG IF USER DOES NOT HAVE EDIT PRIVILEGES
  const [open, setOpen] = useState<boolean>(false);

  // OPEN EDIT PRIVILEGES DIALOG
  const openDialog = () => {
    setOpen(true);
  };

  //CLOSE EDIT PRIVILEGES DIALOG
  const closeDialog = (event?: React.SyntheticEvent, reason?: string) => {
    if (reason === 'backdropClick') {
      return;
    }
    setOpen(false);
  };

  // FETCHING DATA FROM REDUX STORE FOR USER PRIVILEGES
  const { userPerms } = useSelector((state: AppState) => state.privileges);

  // BELOW WILL FILTER ONLY THE MODEL's WHICH LOGGED IN USER HAS EDIT PRIVILEGES
  const modelsWithEditPriv = userPerms
    .filter(modelDetails => modelDetails.privCd === 'EditModel')
    .filter(models => state?.state.subjectArea.map(model => model.mdelDetails.mdelId)?.includes(models.modelId));

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const logOut = () => {
    loginDispatch({ type: subjectAreaActionTypes.LOGOUT_CLEAR_AUTH_STATE });
    privDispatch({ type: privilegesActionTypes.LOGOUT_CLEAR_PRIVILEGES_STATE });
    localStorage.setItem('token', '');
    history.push('/login');
  };

  const drawer = (
    <div>
      {/* OPEN THE DIALOG IF 'open' IS true IN LOCAL STATE AND PASS NECESSARY PROPS TO ALERTDIALOG COMPONENT */}
      {open && <AlertDialog handleClose={closeDialog} open={open} />}
      {/* left hand panel starts here */}
      <div className={classes.toolbar}>
        <Toolbar>BDF Meta Data Manager {Config.api_url}</Toolbar>
      </div>
      <Divider />
      <List>
        <ListSubheader disableSticky>Subject Areas</ListSubheader>
        <ListItem selected button key={1}>
          <ListItemIcon classes={{ root: classes.sideBarIconWidth }}>{<ViewComfy />}</ListItemIcon>
          <ListItemText primary={'All Subject Areas'} />
        </ListItem>
        {state?.state.subjectArea.map((text, index) => (
          <aside key={index}>
            {/* VALIDATING THE MODELS WHICH HAS EDIT PRIV WITH ALL THE MODELS WHICH USER HAS ACCESS TO
              IF MATCHES THEN USER CAN ABLE TO EDIT IT ELSE THE DIALOG WILL OPEN WITH MESSAGE.
            */}

            {/* LINK BUTTON STARTS  */}

            {modelsWithEditPriv.some(model => {
              return model.modelId === text.mdelDetails.mdelId;
            }) ? (
              <Link
                style={{ textDecoration: 'none', color: 'black' }}
                to={{
                  pathname: '/SubjectAreaDetails',
                  state: {
                    modelDetails: text.mdelDetails,
                  },
                }}
                key={text.mdelDetails.mdelId}
              >
                <ListItem button>
                  <ListItemIcon classes={{ root: classes.sideBarIconWidth }}>{<StorageIcon />}</ListItemIcon>
                  <ListItemText primary={text.mdelDetails.mdelDesc} />
                </ListItem>
              </Link>
            ) : (
              <Link style={{ textDecoration: 'none', color: 'black' }} to='#' onClick={openDialog} key={text.mdelDetails.mdelId}>
                <ListItem button>
                  <ListItemIcon classes={{ root: classes.sideBarIconWidth }}>{<StorageIcon />}</ListItemIcon>
                  <ListItemText primary={text.mdelDetails.mdelDesc} />
                </ListItem>
              </Link>
            )}
          </aside>
        ))}
        {/* LINK BUTTON ENDS  */}

        <ListSubheader>System Configuration</ListSubheader>
        {['Clusters', 'Database', 'Schemas', 'Look-ups'].map((text, index) => (
          <ListItem button key={index}>
            <ListItemText primary={text} />
          </ListItem>
        ))}
      </List>
    </div>
  );
  const container = window !== undefined ? () => window().document.body : undefined;
  return (
    <div>
      <AppBar position='fixed' className={clsx(classes.header, classes.appBar)}>
        <Toolbar>
          <IconButton edge='start' className={classes.menuButton} color='inherit' aria-label='menu' onClick={handleDrawerToggle}>
            <MenuIcon />
          </IconButton>
          <Typography variant='h6' className={classes.title}>
            Big meta Data
          </Typography>
          <IconButton color='inherit'>
            <AppsIcon />
          </IconButton>
          <IconButton color='inherit' onClick={clickMenu}>
            <AccountCircleIcon />
          </IconButton>
          <Menu
            id='simple-menu'
            anchorEl={anchorEl}
            keepMounted
            open={Boolean(anchorEl)}
            onClose={closeMenu}
            getContentAnchorEl={null}
            anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
            transformOrigin={{ vertical: 'top', horizontal: 'right' }}
          >
            <MenuItem onClick={logOut} style={{ padding: '1rem' }}>
              <ExitToAppIcon style={{ marginRight: '10px' }} />
              <div>Logout</div>
            </MenuItem>
          </Menu>
        </Toolbar>
      </AppBar>
      <nav className={classes.drawer} aria-label='mailbox folders'>
        <Hidden smUp implementation='css'>
          <Drawer
            container={container}
            variant='temporary'
            anchor={theme.direction === 'rtl' ? 'right' : 'left'}
            open={mobileOpen}
            onClose={handleDrawerToggle}
            classes={{
              paper: classes.drawerPaper,
            }}
          >
            {drawer}
          </Drawer>
        </Hidden>
        <Hidden xsDown implementation='css'>
          <Drawer
            classes={{
              paper: classes.drawerPaper,
            }}
            variant='permanent'
            open
          >
            {drawer}
          </Drawer>
        </Hidden>
      </nav>
    </div>
  );
};
