import React, { useState } from 'react';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import SaveIcon from '@material-ui/icons/Save';
import SnackbarAlert from '../snackBar/SnackBar';
import { globalApis } from '../../services/apis';

interface CommitDialogProps {
  handleClose: () => void;
  open: boolean;
  mdelId: number;
  makeCommit: any;
  version: string;
}

const CommitDialog: React.FC<CommitDialogProps> = props => {
  const { handleClose, open, mdelId, makeCommit, version } = props;
  const [commitComment, setCommitComment] = useState<string>('');

  // LOCAL STATE FOR OPENING AND CLOSING SNACKBAR ALERT
  const [openSnackBar, setOpenSnackBar] = React.useState(false);

  // CLOSE COMMIT COMMENT DIALOG AND CLEAR THE USER INPUT IF ANY
  const closeCommitDialog = () => {
    handleClose();
    setCommitComment('');
  };

  // COMMIT A SUBJECT AREA AND SHOW SNACKBAR ALERT WHEN USER CLICKS ON COMMIT BUTTON
  const commitSubjectArea = () => {
    globalApis
      .commitSubjectArea({
        modelId: mdelId,
        commitMsg: commitComment,
      })
      .then(response => {
        makeCommit(response.data);
        handleClose();
        setOpenSnackBar(true);
        setCommitComment('');
      })
      .catch(error => {
        setCommitComment('');
        handleClose();
        return error;
      });
  };

  // CLOSE SNAKBAR ALERT WHEN USER CLICKS ON X BUTTON
  const closeSnackBarAlert = (event?: React.SyntheticEvent, reason?: string) => {
    if (reason === 'clickaway') {
      return;
    }
    setOpenSnackBar(false);
  };

  // HANDLING INPUT ENTERED BY THE USER FOR COMMIT COMMENT TEXT FIELD.
  const commitInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setCommitComment(event.target.value);
  };

  const commitCommentCheck = commitComment.length > 1000;

  return (
    <div>
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle id='form-dialog-title'>Commit</DialogTitle>
        <DialogContent>
          <DialogContentText style={{ paddingBottom: '1rem' }}>
            Committing a version does not impact any environments. Once a version is committed it can be promoted to a specific environment.
          </DialogContentText>
          <TextField
            error={commitCommentCheck ? true : false}
            label='Commit Comment*'
            variant='outlined'
            fullWidth
            helperText={commitCommentCheck ? 'Commit Comment should have 1000 or less characters.' : '*A commit comment is required'}
            value={commitComment}
            onChange={commitInputChange}
            multiline
          />
        </DialogContent>
        <DialogActions style={{ padding: '1rem' }}>
          <Button onClick={closeCommitDialog} color='primary'>
            CANCEL
          </Button>
          <Button
            variant='contained'
            onClick={commitSubjectArea}
            disabled={!commitComment || commitCommentCheck ? true : false}
            color='primary'
            startIcon={<SaveIcon />}
            style={{ marginLeft: '2rem' }}
          >
            COMMIT
          </Button>
        </DialogActions>
      </Dialog>

      {/* OPENS SNACKBAR WHEN ABOVE COMMIT BUTTON IS CLICKED */}
      <SnackbarAlert alertMessage={`Version ${version} commited`} closeSnackBarAlert={closeSnackBarAlert} openSnackBar={openSnackBar} />
    </div>
  );
};

export default CommitDialog;
