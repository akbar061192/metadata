import React from 'react';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import SnackbarAlert from '../snackBar/SnackBar';
import CloudUploadIcon from '@material-ui/icons/CloudUpload';
import { createStyles, makeStyles, Theme } from '@material-ui/core/styles';
import { globalApis } from '../../services/apis';
import Typography from '@material-ui/core/Typography';

interface ConfirmPromoteDialogProps {
  handleClose: () => void;
  open: boolean;
  promotingLifeCycle: any;
  promotingVersion: any;
  clearStatePrev: () => void;
}

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    promoteContainer: {
      width: '30rem',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-start',
      marginTop: '1rem',
      marginLeft: '1rem',
      flexDirection: 'column',
    },
    versionRow: {
      display: 'flex',
      alignItems: 'center',
      marginRight: '1rem',
    },
  })
);

const ConfirmPromoteDialog: React.FC<ConfirmPromoteDialogProps> = (props) => {
  const { handleClose, open, promotingLifeCycle, promotingVersion, clearStatePrev } = props;
  const classes = useStyles();

  // LOCAL STATE FOR OPENING AND CLOSING SNACKBAR ALERT
  const [openSnackBar, setOpenSnackBar] = React.useState(false);

  // CLOSE PROMOTE DIALOG
  const closePromoteDialog = () => {
    handleClose();
  };

  // CLOSE SNACKBAR ALERT WHEN USER CLICKS ON X BUTTON
  const closeSnackBarAlert = (event?: React.SyntheticEvent, reason?: string) => {
    if (reason === 'clickaway') {
      return;
    }
    setOpenSnackBar(false);
  };

  // CONVERTING INCOMING DATE TO UTC WITH PROPER FORMATTING
  const dateFormat = (date: any) => {
    const inputDate = new Date(date).toUTCString().slice(5, 22) + ' UTC';
    let char = ',';
    let position = 11;
    let output = [inputDate.slice(0, position), char, inputDate.slice(position)].join('');
    return output;
  };

  //CLICKING PROMOTE BUTTON TO MAKE A PROMOTE TO OTHER LIFECYCLES.
  const promoteSubjectArea = (lifeCycle: any) => {
    globalApis
      .promoteSubjectArea({
        modelId: promotingVersion.modelId,
        commitId: promotingVersion.commitId,
        targetEnv: lifeCycle,
      })
      .then((response) => {
        closePromoteDialog();
        clearStatePrev();
        setOpenSnackBar(true);
      })
      .catch((error) => {
        closePromoteDialog();
        clearStatePrev();
        return error;
      });
  };

  return (
    <div>
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle id="form-dialog-title">Confirm Promote</DialogTitle>
        <DialogContent>
          Use Version:
          <section style={{ marginBottom: '1.25rem' }} className={classes.promoteContainer}>
            <Typography color="textPrimary" style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} variant="body1">
              {promotingVersion?.version + ' - ' + dateFormat(promotingVersion?.commitTs)}
            </Typography>
            <Typography
              color="textSecondary"
              style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}
              variant="caption"
            >
              {' '}
              {promotingVersion?.commitMsg}
            </Typography>
          </section>
          Destination:
          <section className={classes.promoteContainer}>
            <div>
              <div style={{ fontSize: '1rem', color: 'gray' }}>{promotingLifeCycle?.value}</div>
            </div>
          </section>
        </DialogContent>
        <DialogActions style={{ padding: '1rem' }}>
          <Button onClick={closePromoteDialog} color="primary">
            CANCEL
          </Button>
          <Button
            variant="contained"
            onClick={() => promoteSubjectArea(promotingLifeCycle?.key)}
            color="secondary"
            startIcon={<CloudUploadIcon />}
            style={{ marginLeft: '2rem'}}
          >
            PROMOTE
          </Button>
        </DialogActions>
      </Dialog>

      {/* OPENS SNACKBAR WHEN ABOVE COMMIT BUTTON IS CLICKED */}
      <SnackbarAlert
        alertMessage={`Version ${promotingVersion?.version} Promoted to ${promotingLifeCycle?.value}`}
        closeSnackBarAlert={closeSnackBarAlert}
        openSnackBar={openSnackBar}
      />
    </div>
  );
};

export default ConfirmPromoteDialog;
