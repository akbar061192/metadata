import React from 'react';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';

interface AlertDialogProps {
  handleClose: () => void;
  open: boolean;
}

const AlertDialog: React.FC<AlertDialogProps> = props => {
  const { handleClose, open } = props;

  return (
    <div>
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>No Edit Privileges</DialogTitle>
        <DialogContent>
          <DialogContentText>
            You don't have the privileges to Edit this Subject Area and currently there is no 'read only' access. To gain edit access please
            contact your local technical lead.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color='primary'>
            OK
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default AlertDialog;
