import React, { useState } from 'react';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import FormControl from '@material-ui/core/FormControl';
import { InputLabel, Select, MenuItem } from '@material-ui/core/';
import { createStyles, makeStyles, Theme } from '@material-ui/core/styles';
import SaveIcon from '@material-ui/icons/Save';
import { IFetchPreviousCommits } from '../../services/apistypes';
import ConfirmPromoteDialog from '../ConfirmPromote/ConfirmPromote';
import { promotes } from '../../../pages/subjectArea/subjectAreaDetails';
import Typography from '@material-ui/core/Typography';
import CloudUploadIcon from '@material-ui/icons/CloudUpload';

interface PromotePrevDialogProps {
  handleClose: () => void;
  open: boolean;
  previousCommits: IFetchPreviousCommits[];
  currentVersion: string;
}

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    selectContainer: {
      '& .MuiSelect-root': {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
      },
    },
    previousCommitContainer: {
      display: 'flex',
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'flex-start',
      '& .MuiSelect-root': {
        display: 'flex',
      },
    },
    menuItem: {
      display: 'flex',
      flexGrow: 1,
      flexDirection: 'column',
    },
    iconRow: {
      display: 'flex',
      alignItems: 'center',
    },
    paper: {
      height: '18.5rem',
    },
  })
);

const PromotePreviousDialog: React.FC<PromotePrevDialogProps> = props => {
  const { handleClose, open, previousCommits, currentVersion } = props;
  const classes = useStyles();

  // LOCAL STATE TO OPEN AND CLOSE CONFIRM PROMOTE DIALOG
  const [openConfirmPromoteDialog, setOpenConfirmPromoteDialog] = useState(false);

  // SETTING VERSION OF SELECTED ITEM FROM DROPDOWN LIST
  const [version, setVersion] = useState('');
  // SETTING SELECTED LIFECYCLE FROM DROPDOWN LIST
  const [lifeCycle, setLifeCycle] = useState('');
  // SAVING COMMIT DETAILS ON CLICKING VERSION FROM DROP DOWN
  const [commitDetails, setCommitDetails] = useState<IFetchPreviousCommits>();
  // SAVING LIFECYCLE VALUE FOR CONFIRM PROMOTE
  const [lifeCycDetails, setLifeCycleDetails] = useState<any>('');

  // VERSION TO BE PROMOTED
  const selectVersion = (event: any) => {
    setVersion(event.target.value);
  };

  // LIFE CYCLE TO BE PROMOTED
  const selectLifeCycle = (event: any) => {
    setLifeCycle(event.target.value);
  };

  // CLOSE PROMOTE PREV DIALOG
  const closePromotePreviousDialog = () => {
    handleClose();
    setVersion('');
    setLifeCycle('');
  };

  // CLOSE CONFIRM DIALOG ON CLICKING CANCEL BUTTON
  const closeConfirmPromoteDialog = (event?: React.SyntheticEvent, reason?: string) => {
    if (reason === 'backdropClick') {
      return;
    }
    setOpenConfirmPromoteDialog(false);
    setVersion('');
    setLifeCycle('');
  };

  // CLICKING PROMOTE BUTTON AFTER SELECTING VERSION AND LIFECYCLE
  const promotePrev = () => {
    setOpenConfirmPromoteDialog(true);
    handleClose();
  };

  // CLEAR STATE FOR VERSION AND LIFECYCLE AFTER PROMOTE
  const clearStatePrev = () => {
    setVersion('');
    setLifeCycle('');
  };

  // CONVERTING INCOMING DATE TO UTC WITH PROPER FORMATTING
  const dateFormat = (date: string) => {
    const inputDate = new Date(date).toUTCString().slice(5, 22) + ' UTC';
    let char = ',';
    let position = 11;
    let output = [inputDate.slice(0, position), char, inputDate.slice(position)].join('');
    return output;
  };

  return (
    <div>
      <ConfirmPromoteDialog
        open={openConfirmPromoteDialog}
        handleClose={closeConfirmPromoteDialog}
        promotingLifeCycle={lifeCycDetails}
        promotingVersion={commitDetails}
        clearStatePrev={clearStatePrev}
      />
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle id='form-dialog-title'>Promote Previous Version</DialogTitle>
        <DialogContent>
          <DialogContentText>Promote the selected version of the Subject Area to the selected environment</DialogContentText>
          Version:
          <div className={classes.selectContainer} style={{ marginBottom: '1.5rem', marginTop: '1rem' }}>
            <FormControl style={{ width: '100%' }}>
              <Select value={version} onChange={selectVersion}>
                {previousCommits.length > 0 &&
                  previousCommits.map((commit: IFetchPreviousCommits) => {
                    return (
                      <MenuItem
                        onClick={() => setCommitDetails(commit)}
                        key={commit.version}
                        title={commit.commitMsg}
                        className={classes.previousCommitContainer}
                        value={commit.version}
                        style={{ backgroundColor: commit.version === currentVersion ? 'lightgray' : '' }}
                      >
                        <div className={classes.menuItem} style={{ minWidth: 0, paddingRight: '1rem' }}>
                          <Typography
                            color='textPrimary'
                            style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}
                            variant='body1'
                          >
                            {commit.version + ' - ' + dateFormat(commit.commitTs && commit.commitTs)}
                          </Typography>
                          <Typography
                            color='textSecondary'
                            style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}
                            variant='caption'
                          >
                            {commit.commitMsg}
                          </Typography>
                        </div>
                        <div className={classes.iconRow}>
                          <Typography color='textPrimary' variant='body2'>
                            {commit.promotedEnv?.toUpperCase()}
                          </Typography>
                          {commit.promotedEnv ? (
                            <CloudUploadIcon style={{ color: 'gray', paddingLeft: '0.5rem' }} />
                          ) : (
                            <SaveIcon style={{ color: 'gray' }} />
                          )}
                        </div>
                      </MenuItem>
                    );
                  })}
              </Select>
              {previousCommits.length === 0 && <div style={{ fontSize: '0.7rem' }}>No Commits found</div>}
            </FormControl>
          </div>
          Promote to:
          <div style={{ marginTop: '1.5rem' }}>
            <FormControl>
              <InputLabel variant='outlined' id='demo-simple-select-helper-label'>
                Environment
              </InputLabel>
              <Select
                label='Environment'
                variant='outlined'
                style={{ width: '13rem' }}
                labelId='demo-simple-select-helper-label'
                id='demo-simple-select-helper'
                value={lifeCycle}
                onChange={selectLifeCycle}
              >
                {promotes.map(promote => {
                  return (
                    <MenuItem key={promote.key} onClick={() => setLifeCycleDetails(promote)} value={promote.key}>
                      {promote.value}
                    </MenuItem>
                  );
                })}
              </Select>
            </FormControl>
          </div>
        </DialogContent>
        <DialogActions style={{ padding: '1rem' }}>
          <Button onClick={closePromotePreviousDialog} color='primary'>
            CANCEL
          </Button>
          <Button onClick={promotePrev} color='primary' disabled={version && lifeCycle ? false : true}>
            PROMOTE
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default PromotePreviousDialog;
