import React from 'react';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import SaveIcon from '@material-ui/icons/Save';
import SettingsBackupRestoreIcon from '@material-ui/icons/SettingsBackupRestore';
import { createStyles, makeStyles, Theme } from '@material-ui/core/styles';
import { IFetchPreviousCommits } from '../../services/apistypes';

interface CommitDialogProps {
  handleClose: () => void;
  open: boolean;
  reverting: IFetchPreviousCommits;
  isCommit: boolean;
  revertPreviousVersion: () => void;
}

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    revertContainer: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-start',
      marginTop: '1rem',
      marginLeft: '1rem',
    },
    versionRow: {
      display: 'flex',
      alignItems: 'center',
      marginRight: '1rem',
    },
  })
);

const RevertCommitDialog: React.FC<CommitDialogProps> = props => {
  const { handleClose, open, reverting, isCommit, revertPreviousVersion } = props;
  const classes = useStyles();

  // CLOSE COMMIT COMMENT DIALOG AND CLEAR THE USER INPUT IF ANY
  const closeReverDialog = () => {
    handleClose();
  };

  // CONVERTING INCOMING DATE TO UTC WITH PROPER FORMATTING
  const dateFormat = (date: string) => {
    const inputDate = new Date(date).toUTCString().slice(5, 22) + ' UTC';
    let char = ',';
    let position = 11;
    let output = [inputDate.slice(0, position), char, inputDate.slice(position)].join('');
    return output;
  };

  return (
    <div>
      <Dialog open={open} onClose={handleClose}>
        <div style={{ width: '36rem' }}>
          <DialogTitle id='form-dialog-title'>
            {isCommit ? 'Revert to previous version and lose changes?' : 'Revert to previous version?'}
          </DialogTitle>
          <DialogContent>
            <DialogContentText style={{ paddingBottom: '1rem' }}>
              {isCommit
                ? 'Are you sure you want to revert to a previous version? Your current changes will be lost.'
                : 'Are you sure you want to revert to a previous version?'}
            </DialogContentText>
            Version:
            <section className={classes.revertContainer}>
              <div style={{ width: '16rem' }}>
                <div style={{ fontSize: '0.8rem' }}>{reverting.version + ' - ' + dateFormat(reverting.commitTs)}</div>
                <div style={{ fontSize: '0.7rem', color: 'gray' }}>{reverting.commitMsg}</div>
              </div>
              <div className={classes.versionRow}>
                <SaveIcon style={{ color: 'gray' }} />
              </div>
            </section>
          </DialogContent>
          <DialogActions style={{ padding: '1rem' }}>
            <Button onClick={closeReverDialog} color='primary'>
              CANCEL
            </Button>
            <Button
              variant='contained'
              color='primary'
              startIcon={<SettingsBackupRestoreIcon />}
              style={{ marginLeft: '2rem' }}
              onClick={revertPreviousVersion}
            >
              REVERT
            </Button>
          </DialogActions>
        </div>
      </Dialog>
    </div>
  );
};

export default RevertCommitDialog;
