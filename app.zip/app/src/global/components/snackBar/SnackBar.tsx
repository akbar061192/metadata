import React from 'react';
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert, { AlertProps } from '@material-ui/lab/Alert';
import SaveIcon from '@material-ui/icons/Save';
import { makeStyles, createStyles, Theme } from '@material-ui/core';

const Alert = (props: AlertProps) => {
  return <MuiAlert elevation={6} variant='filled' {...props} />;
};

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    alert: {
      backgroundColor: '#3f51b5',
      alignItems: 'center',
    },
  })
);

interface SnackBarProps {
  closeSnackBarAlert: () => void;
  openSnackBar: boolean;
  alertMessage: string;
}

const SnackbarAlert: React.FC<SnackBarProps> = props => {
  const { closeSnackBarAlert, openSnackBar, alertMessage } = props;
  const classes = useStyles();

  return (
    <div>
      <Snackbar open={openSnackBar} autoHideDuration={3000} onClose={closeSnackBarAlert}>
        <Alert className={classes.alert} onClose={closeSnackBarAlert} severity='info' icon={<SaveIcon />}>
          {alertMessage}
        </Alert>
      </Snackbar>
    </div>
  );
};

export default SnackbarAlert;
