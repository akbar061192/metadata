import React, { useState } from 'react';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';

interface ErrorDialogProps {
  openErrorDialog: boolean;
  errorObj: any;
}

export const ErrorDialog: React.FC<ErrorDialogProps> = props => {
  const {
    openErrorDialog,
    errorObj: { errors },
  } = props;

  const [open, setOpen] = useState<boolean>(openErrorDialog);

  //CLOSE DIALOG
  const closeDialog = (event?: React.SyntheticEvent, reason?: string) => {
    if (reason === 'backdropClick') {
      return;
    }
    setOpen(false);
  };

  return (
    <Dialog open={open} aria-labelledby='alert-dialog-title' aria-describedby='alert-dialog-description'>
      <DialogTitle id='alert-dialog-title'>Oops! Something went wrong.</DialogTitle>
      <DialogContent>
        <DialogContentText id='alert-dialog-description'>
          <span>
            An error occured while dealing with your request. Please contact support team for assistance and include the following error
            message so we can look into it.<br></br>
          </span>
          <br />
          <span style={{ color: 'black' }}>
            {errors.map((err: any) => {
              return err.code ? <span key={err.code}>Error: {err.error}</span> : <span key={err.error}>Error: {err.error}</span>;
            })}
          </span>
        </DialogContentText>
      </DialogContent>
      <DialogActions>
        <Button onClick={closeDialog} color='primary'>
          CLOSE
        </Button>
      </DialogActions>
    </Dialog>
  );
};
