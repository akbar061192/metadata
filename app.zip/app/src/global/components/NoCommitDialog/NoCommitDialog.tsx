import React, { useState } from 'react';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import CommitDialog from '../commitDialog/CommitDialog';

interface NoCommitDialogProps {
  handleClose: () => void;
  open: boolean;
  mdelId: number;
  makeCommit: any;
  version: string;
}

const NoCommitDialog: React.FC<NoCommitDialogProps> = props => {
  const { handleClose, open, mdelId, version, makeCommit } = props;
  const [openCommit, setOpenCommit] = useState(false);

  // CLOSE NO COMMIT DIALOG
  const closeNoCommitDialog = () => {
    handleClose();
  };

  // OPEN COMMIT COMMENT DIALOG ON CLICKING 'COMMIT' BUTTON
  const openCommitDialog = () => {
    setOpenCommit(true);
    handleClose();
  };

  // CLOSE COMMIT COMMENT DIALOG ON CLICKING CANCEL BUTTON
  const closeCommitDialog = (event?: React.SyntheticEvent, reason?: string) => {
    if (reason === 'backdropClick') {
      return;
    }
    setOpenCommit(false);
  };

  return (
    <div>
      <CommitDialog open={openCommit} handleClose={closeCommitDialog} mdelId={mdelId} version={version} makeCommit={makeCommit} />
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle id='form-dialog-title'>Warning: Non-committed changes!</DialogTitle>
        <DialogContent>
          <DialogContentText>
            The changes in the subject area you are trying to promote have not been committed, only ‘committed’ versions can be published.
          </DialogContentText>
          <DialogContentText style={{ margin: '2rem 0' }}>
            Do you want to commit the changes in this version before promoting it?
          </DialogContentText>
        </DialogContent>
        <DialogActions style={{ padding: '1rem' }}>
          <Button onClick={closeNoCommitDialog} color='primary'>
            CANCEL
          </Button>
          <Button onClick={openCommitDialog} color='primary'>
            COMMIT
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default NoCommitDialog;
