export interface IauthUser {
  emailId: string;
  password: string;
}

export interface IsubjectArea {
  name: string;
  code: string;
}

export interface IUserPerms {
  modelId: number;
  privCd: string;
}

export interface ICommitSubjectArea {
  modelId: number;
  commitMsg: string;
}

export interface IFetchPreviousCommits {
  action: string;
  actionMsg: string;
  actionOutcome: string;
  actionLifecyc: string;
  actionTs: string;
  commitBranch: string;
  commitId: string;
  commitMsg: string;
  commitTs: string;
  modelId: number;
  promotedEnv: string;
  userEmail: string;
  userName: string;
  version: string;
}

export interface IPromoteSubjectArea {
  modelId: number;
  commitId: string;
  targetEnv: string;
}

export interface IGetLoVs {
  mdelId: number;
  lovCd: string;
  lovGrp: string;
  lovTyp: string;
  lovDesc: string;
  valueReqd: string;
  isrtedDt: string;
  isrtedByUsrNm: string;
  lastUpdtDt: string;
  lastUpdtByUsrNm: string;
  lovId: number;
  dbTag: string;
  sqlTxt: string | null;
  esIndex: string;
  esRefreshSQL: string | null;
  esRefreshIntervalHours: number;
  esLastRefreshDT: string | null;
  esLastRefresh_Status: string | null;
  id: number;
}

export interface IGetLoVDetails {
  lovId: number;
  lovValue: string;
  lovDesc: string;
  lovSeq: number;
  lovPrev: string;
  lovEditFlg: string;
  insertByUser: string;
  updateByUser: string;
  insertDate: string;
  lastUpdateDate: string;
  ownerUser: any;
  roleRead: string;
  roleUpdate: string;
  tmplLikeList: string;
  roleReadCd: string;
  roleUpdateCd: string;
  id: number;
  key?: string;
}

export interface IGetRolesByModelId {
  roleCode: string;
  roleDesc: string;
  roleId: number;
  modelId: number;
}

export interface IUpsertLoV {
  lovId: number;
  oldLovValue: string;
  newLovValue: string;
  lovDesc: string;
  lovSeq: number;
  roleRead: number;
  roleUpdate: number;
  ownerUser: string;
  tmplLikeList: string;
}

export interface IUpsertLoVDetails {
  mdelId: number;
  insert: IUpsertLoV[] | null;
  update: IUpsertLoV[] | null;
  delete: IUpsertLoV[] | null;
}

export interface IGetTargetsByModelId {
  mdelId: number;
  targetId: number;
  destType: string;
  targetType: string;
  targetHost: string;
  port: number;
  userName: string;
  password: string;
  defaultPath: string;
  targetSubType: string;
  isrtedDt: string;
  isrtedByUsrName: string;
  lastupdtDt: string;
  lastUpdtbyUsrName: string;
  jdbcUrl: string | null;
  jdbcDriver: string | null;
  linkPath: string;
  keyLocation: string | null;
  keyPassPhrase: string | null;
  authMethod: string;
  roleReadCd: string;
  roleReadDesc: string;
  roleReadId: number;
  roleUpdateCd: string;
  roleUpdateDesc: string;
  roleUpdateId: number;
  ownerName: string;
}

export interface IGetUsersByModelId {
  userName: string;
  fullName: string;
  userId: number;
  withGrantFlg: string | null;
}

export interface IUpsertTarget {
  targetId?: number;
  destType?: string;
  targetType?: string;
  targetHost?: string;
  port?: number | null;
  userName?: string;
  password?: string | null;
  defaultPath?: string | null;
  targetSubType?: string;
  jdbcUrl?: string | null;
  jdbcDriver?: string | null;
  linkPath?: string | null;
  keyLocation?: string | null;
  keyPassPhrase?: string | null;
  authMethod?: string;
  roleReadId?: number;
  roleUpdateId?: number;
  ownerName?: string | null;
}

export interface IUpsertTargetDetails {
  mdelId: number;
  insert: IUpsertTarget[] | null;
  update: IUpsertTarget[] | null;
  delete: IUpsertTarget[] | null;
}

export interface IGetDbTags {
  dbCrdlId: number;
  dbName: string | null;
  dbTag: string | null;
  dbTagLifeCyc: string | null;
  lifeCyc: string | null;
}

export interface IUpsertSingleLoV {
  lovCd: string;
  lovGrp: string;
  lovTyp: string;
  lovDesc: string;
  valueRequired: string;
  lovId: number;
  dbTag: string | null;
  sqlTxt: string | null;
  esIndex: string | null;
  esRefreshSQL: string | null;
  esRefreshIntervalHours: number | null;
  esLastRefreshDT: string | null;
  esLastRefresh_Status: string | null;
}

export interface IUpsertSingleLoVValue {
  mdelId: number;
  insert: IUpsertSingleLoV[] | null;
  update: IUpsertSingleLoV[] | null;
  delete: IUpsertSingleLoV[] | null;
}

export interface IGetEventsByModelId {
  eventId: number;
  eventCd: string;
  eventDesc: string;
  modelId: number;
  isrtdDt: string;
  isrtdByUsrNm: string;
  lstUpdtDt: string;
  lstUpdtByUsrNm: string;
  topicName: string;
  groupName: string;
  maxMessage: number;
  filterJson: string;
  activeProdReq: number;
  inactiveProdReq: number;
}

export interface IUpsertEvents {
  eventId: number;
  eventCd: string;
  eventDesc: string;
  isrtdByUsrNm: string;
  lastUpdtByUserNm: string;
  topicName: string;
  groupName: string;
  maxMessage: number;
  filterJson: object;
}

export interface IUpsertEventsDelete {
  eventId: object;
}

export interface IUpsertEventsDetails {
  mdelId: number;
  insert: IUpsertEvents[] | null;
  update: IUpsertEvents[] | null;
  delete: IUpsertEventsDelete[] | null;
}

export interface IValidateSql {
  modelId: number;
  sqlTxt: string | null;
  dbTag: string;
}
