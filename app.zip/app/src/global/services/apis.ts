import {
  IsubjectArea,
  IauthUser,
  IUserPerms,
  ICommitSubjectArea,
  IFetchPreviousCommits,
  IPromoteSubjectArea,
  IGetLoVs,
  IGetLoVDetails,
  IGetRolesByModelId,
  IUpsertLoVDetails,
  IGetTargetsByModelId,
  IGetUsersByModelId,
  IUpsertTargetDetails,
  IUpsertSingleLoVValue,
  IGetEventsByModelId,
  IGetDbTags,
  IUpsertEventsDetails,
  IValidateSql,
} from './apistypes';
import config from '../config/serviceConfig';
import { axiosInstance } from '../../index';

const authenticateUser = (input: IauthUser) =>
  axiosInstance.post<IauthUser>(config.apiEndPoints.BASEURL.API_METADATA_URL_DEV + config.apiEndPoints.METADATA.AUTHENTICATE_USER, input);

const getSubjectArea = () =>
  axiosInstance.get<IsubjectArea>(encodeURI(config.apiEndPoints.BASEURL.API_UI_URL_DEV + config.apiEndPoints.ICEUI.GET_SUBJECT_AREA));

const getPermissions = () =>
  axiosInstance.get<IUserPerms[]>(encodeURI(config.apiEndPoints.BASEURL.API_METADATA_URL_DEV + config.apiEndPoints.METADATA.PERMISSIONS));

const commitSubjectArea = (input: ICommitSubjectArea) =>
  axiosInstance.post(config.apiEndPoints.BASEURL.API_METADATA_URL_DEV + config.apiEndPoints.METADATA.COMMIT_SUBJECT_AREA, input);

const fetchPreviousCommits = (modelId: number) =>
  axiosInstance.get<IFetchPreviousCommits[]>(
    encodeURI(config.apiEndPoints.BASEURL.API_METADATA_URL_DEV + config.apiEndPoints.METADATA.FETCH_PREVIOUS_COMMITS) + modelId
  );

const promoteSubjectArea = (input: IPromoteSubjectArea) =>
  axiosInstance.post(config.apiEndPoints.BASEURL.API_METADATA_URL_DEV + config.apiEndPoints.METADATA.PROMOTE_SUBJECT_AREA, input);

const getLoVsByModelId = (modelId: number) =>
  axiosInstance.get<IGetLoVs[]>(
    encodeURI(config.apiEndPoints.BASEURL.API_METADATA_URL_DEV + config.apiEndPoints.METADATA.LOV_BY_MDEL_ID) + modelId
  );

const getLoVDetailsByLoVId = (lovId: number) =>
  axiosInstance.get<IGetLoVDetails[]>(
    encodeURI(
      `${config.apiEndPoints.BASEURL.API_METADATA_URL_DEV + config.apiEndPoints.METADATA.LOV_DETAILS_BY_LOV_ID + '?lovId=' + lovId}`
    )
  );

const upsertLoVDetails = (input: IUpsertLoVDetails) =>
  axiosInstance.post(config.apiEndPoints.BASEURL.API_METADATA_URL_DEV + config.apiEndPoints.METADATA.LOV_DETAILS_UPSERT, input);

const getRolesByModelId = (modelId: number) =>
  axiosInstance.get<IGetRolesByModelId[]>(
    encodeURI(config.apiEndPoints.BASEURL.API_METADATA_URL_DEV + config.apiEndPoints.METADATA.ROLES_BY_MODEL_ID) + modelId
  );

const getTargetsByModelId = (modelId: number) =>
  axiosInstance.get<IGetTargetsByModelId[]>(
    encodeURI(config.apiEndPoints.BASEURL.API_METADATA_URL_DEV + config.apiEndPoints.METADATA.TARGETS_BY_MODEL_ID) + modelId
  );

const getUsersByModelId = (modelId: number) =>
  axiosInstance.get<IGetUsersByModelId[]>(
    encodeURI(
      `${config.apiEndPoints.BASEURL.API_METADATA_URL_DEV + config.apiEndPoints.METADATA.USERS_BY_MODEL_UD + '?modelId=' + modelId}`
    )
  );

const upsertTargetDetails = (input: IUpsertTargetDetails) =>
  axiosInstance.post(config.apiEndPoints.BASEURL.API_METADATA_URL_DEV + config.apiEndPoints.METADATA.TARGET_UPSERT, input);

const upsertLoV = (input: IUpsertSingleLoVValue) =>
  axiosInstance.post(config.apiEndPoints.BASEURL.API_METADATA_URL_DEV + config.apiEndPoints.METADATA.LOV_UPSERT, input);

const getEventsByModelId = (modelId: number) =>
  axiosInstance.get<IGetEventsByModelId[]>(
    encodeURI(config.apiEndPoints.BASEURL.API_METADATA_URL_DEV + config.apiEndPoints.METADATA.EVENTS_BY_MODEL_ID) + modelId
  );

const upsertEventsDetails = (input: IUpsertEventsDetails) =>
  axiosInstance.post(config.apiEndPoints.BASEURL.API_METADATA_URL_DEV + config.apiEndPoints.METADATA.EVENTS_UPSERT, input);

const getDbTags = () =>
  axiosInstance.get<IGetDbTags[]>(encodeURI(config.apiEndPoints.BASEURL.API_METADATA_URL_DEV + config.apiEndPoints.METADATA.GET_DBTAGS));

const jdbcTestConnection = (data: any) =>
  axiosInstance.post(config.apiEndPoints.BASEURL.API_METADATA_URL_DEV + config.apiEndPoints.METADATA.JDBC_TEST_CONNECTION, data);

const validateSql = (data: IValidateSql) =>
  axiosInstance.post<IValidateSql>(config.apiEndPoints.BASEURL.API_METADATA_URL_DEV + config.apiEndPoints.METADATA.VALIDATE_SQL, data);

export const globalApis = {
  authenticateUser,
  getSubjectArea,
  getPermissions,
  commitSubjectArea,
  fetchPreviousCommits,
  promoteSubjectArea,
  getLoVsByModelId,
  getLoVDetailsByLoVId,
  upsertLoVDetails,
  getRolesByModelId,
  getTargetsByModelId,
  getUsersByModelId,
  upsertTargetDetails,
  upsertLoV,
  getEventsByModelId,
  upsertEventsDetails,
  getDbTags,
  jdbcTestConnection,
  validateSql,
};
