import React, { FC, createContext, useReducer } from "react";

interface MyState {
  subjectArea: any[];
}

// initialState must fulfill the `MyState` interface
const initialState: MyState = {
  subjectArea: [],
};

interface MyAction {
  type: string;
  payload: any;
}

const reducer = (state: MyState, action: MyAction) : MyState => {
  switch (action.type) {
    case "subjectArea": {
      return {
        ...state,
        subjectArea: action.payload,
      };
    }
    case "clearState": {
      return {
        ...initialState,
      };
    }
    default: {
      return state;
    }
  }
};

interface MyContext {
  state: MyState;
  dispatch: React.Dispatch<MyAction>;
}
export const Context = createContext<MyContext | null>(null);

const StateProvider: FC = ({ children }) => {
  const [state, dispatch] = useReducer(reducer, initialState);
  return (
    <Context.Provider value={{ state, dispatch }}>{children}</Context.Provider>
  );
};

export default StateProvider;
