import { FC } from "react";
import { Route, RouteProps } from "react-router-dom";

interface IPublicRouteProps extends RouteProps {
  component: any;
}

const PublicRoute: FC<IPublicRouteProps> = ({ component: C, ...rest }) => (
  <Route {...rest} render={(props) => <C {...props} {...rest} />} />
);

export default PublicRoute;