import { Typography } from "@material-ui/core";
import { FC } from "react";
// import { useSelector } from "react-redux";
import { Redirect, Route, RouteProps } from "react-router-dom";
import PublicRoute from "./PublicRoute";

interface IPrivateRouteProps extends RouteProps {
  component: any;
}

const PrivateRoute: FC<IPrivateRouteProps> = ({ component: C, ...rest }) => {

 //implement authentication here ----

    return (
      <Route
        {...rest}
        render={() => {
          return (
            <Redirect
              to={{
                pathname: "",
                state: {
                  from: "",
                  prevLocation: "",
                },
              }}
            />
          );
        }}
      />
    );

};
export default PrivateRoute;
