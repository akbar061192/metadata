import { FC } from 'react';
import { Switch, Route, Redirect } from 'react-router-dom';
// import PublicRoute from './PublicRoute';
// import PrivateRoute from './PrivateRouter';
import SubjectAreaDetails from '../../pages/subjectArea/subjectAreaDetails';
import { Home } from './../../pages/home';
import Login from '../../pages/Login/Login';

const Routes: FC = props => {
  const token = localStorage.getItem('token');
  return (
    <Switch>
      <Route
        path='/'
        exact={true}
        render={
          !token
            ? () => {
                return (
                  <Redirect
                    to={{
                      pathname: '/login',
                    }}
                  />
                );
              }
            : () => {
                return (
                  <Redirect
                    to={{
                      pathname: '/SubjectAreaCards',
                    }}
                  />
                );
              }
        }
      />

      <Route path='/login' exact={true} render={() => <Login></Login>} />
      <Route path='/SubjectAreaCards' exact={true} render={() => <Home></Home>} />
      <Route path='/SubjectAreaDetails' exact={true} render={() => <SubjectAreaDetails></SubjectAreaDetails>} />
    </Switch>
  );
};
export default Routes;
