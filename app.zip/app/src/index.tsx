import React, { useState, useEffect, Dispatch } from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import { App } from './App';
import { BrowserRouter, useHistory } from 'react-router-dom';
import reportWebVitals from './reportWebVitals';
import axios from 'axios';
import { Provider } from 'react-redux';
import store from './global/redux/store/store';
import { makeStyles, createStyles } from '@material-ui/core/styles';
import CircularProgress from '@material-ui/core/CircularProgress';
import Backdrop from '@material-ui/core/Backdrop';
import { ErrorDialog } from './global/components/error/errorDialog';
import { LoginActions } from './global/redux/actions/subjectAreaAction';
import { useDispatch } from 'react-redux';
import { subjectAreaActionTypes } from './global/redux/actions/subjectAreaAction';

//Create Axios Instance
const axiosInstance = axios.create({});

//Create global variable to handle the spinner
var globalSpinner: boolean = false;

//Custom hook to handle the Axios Interceptor
const useAxiosInterceptor = () => {
  const [counter, setCounter] = useState(0);
  const [errorState, setErrorState] = useState({});
  const history = useHistory();
  const clearStateDispatch = useDispatch<Dispatch<LoginActions>>();

  // DISPATCHING LOGIN SUCCESS ACTION AND STORING DATA IN REDUX STORE
  const clearState = () => {
    clearStateDispatch({ type: subjectAreaActionTypes.LOGOUT_CLEAR_AUTH_STATE });
  };

  useEffect(() => {
    // Add request interceptors
    const reqInterceptor = axiosInstance.interceptors.request.use(
      axiosConfig => {
        let originalRequest = axiosConfig;
        originalRequest.headers = {
          'x-ice-token': localStorage.getItem('token'),
        };
        setCounter(counter => counter + 1);
        setErrorState('');
        return originalRequest;
      },
      error => {
        setCounter(counter => counter - 1);
        setErrorState(error);
        return Promise.reject(error);
      }
    );

    // Add response interceptors
    const resInterceptor = axiosInstance.interceptors.response.use(
      response => responseHandler(response),
      error => errorHandler(error)
    );
    return () => {
      // Remove all intercepts when done
      axiosInstance.interceptors.request.eject(reqInterceptor);
      axiosInstance.interceptors.response.eject(resInterceptor);
    };
  }, []);

  // Add response interceptors
  const responseHandler = (response: any) => {
    setErrorState('');
    setCounter(counter => counter - 1);
    return response;
  };

  // Add errorHandler interceptors
  const errorHandler = (error: any) => {
    if (error.response.status === 401 || error.response.status === 500) {
      clearState();
      localStorage.setItem('token', '');
      history.push('/login');
    }
    if (error.response.status === 400 || error.response.status === 404) {
      setErrorState(error.response.data);
    }
    setCounter(counter => counter - 1);
    return Promise.reject(error);
  };
  return [counter > 0, errorState];
};

// STYLES FOR BACKDROP COMPONENT WHILE LOADING
const useStyles = makeStyles(() =>
  createStyles({
    rootBackdrop: {
      '& .MuiBackdrop-root': {
        zIndex: 9999,
        backgroundColor: 'rgba(0,0,0,0.3)',
      },
    },
  })
);

// GlobalLoader to handle loader
const GlobalLoader = () => {
  const [loading, errorState] = useAxiosInterceptor();
  const classes = useStyles();

  globalSpinner = loading ? true : false;

  // THE 'error' STATE IS AN OBJECT SO CHECKING IT FOR A BOOL AND PASSING IT TO ERROR DIALOG
  const errorHandler = typeof errorState === 'object' && Object.keys(errorState).length > 0 ? true : false;

  return (
    <>
      {globalSpinner ? (
        <div className={classes.rootBackdrop}>
          <Backdrop open={globalSpinner}>
            <CircularProgress style={{ width: '70px', height: '70px' }} />
          </Backdrop>
        </div>
      ) : (
        errorHandler && (
          <div>
            <ErrorDialog openErrorDialog={errorHandler} errorObj={errorState} />
          </div>
        )
      )}
    </>
  );
};

export { axiosInstance, useAxiosInterceptor };

ReactDOM.render(
  <React.StrictMode>
    <Provider store={store}>
      <BrowserRouter basename='/metadatauiapp'>
        <GlobalLoader />
        <App />
      </BrowserRouter>
    </Provider>
  </React.StrictMode>,
  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
